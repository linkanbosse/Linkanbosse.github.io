package com.catwarriors.apocalypse;

public class Weapon {
    public String id;
    public String name;
    public String category;
    public float damage;
    public float fireRate;
    public int magazineSize;
    public float reloadSpeed;
    public float reloadTime;
    public float dps;
    public float range;
    public float bulletSpeed;
    public int color;
    public float spread;
    public int pelletCount;
    public int penetration;
    public boolean isExplosive;
    public float explosionRadius;

    public Weapon(String id, String name, String category, float damage, float fireRate,
                  int magazineSize, float reloadTime, float range, float bulletSpeed,
                  int color, float spread, int pelletCount, int penetration,
                  boolean isExplosive, float explosionRadius) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.damage = damage;
        this.fireRate = fireRate;
        this.magazineSize = magazineSize;
        this.reloadSpeed = reloadTime;
        this.reloadTime = reloadTime;
        this.dps = damage * pelletCount * fireRate;
        this.range = range;
        this.bulletSpeed = bulletSpeed;
        this.color = color;
        this.spread = spread;
        this.pelletCount = pelletCount;
        this.penetration = penetration;
        this.isExplosive = isExplosive;
        this.explosionRadius = explosionRadius;
    }
}
