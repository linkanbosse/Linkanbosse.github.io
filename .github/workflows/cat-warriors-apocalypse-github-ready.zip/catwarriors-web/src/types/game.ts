/**
 * Cat Warriors: Apocalypse - Game Types & Definitions
 * Expanded with 26+ Adorable Kitty Heroes, 36+ Guns, Gun Merge System, Rebirth & Diverse Biomes
 */

export type GameState = 
  | 'TITLE_MENU'
  | 'MISSION_SELECT'
  | 'HERO_SELECT'
  | 'ARMORY'
  | 'MERGE_WORKSHOP'
  | 'REBIRTH_TEMPLE'
  | 'UPGRADES'
  | 'SETTINGS'
  | 'PLAYING'
  | 'PAUSED'
  | 'VICTORY'
  | 'GAME_OVER'
  | 'ANDROID_PROJECT_HUB';

export type CatBreed = 
  | 'Tabby'
  | 'Persian'
  | 'Siamese'
  | 'Calico'
  | 'Tuxedo'
  | 'Ginger'
  | 'Maine Coon'
  | 'Sphynx'
  | 'Bengal'
  | 'Scottish Fold'
  | 'Ragdoll'
  | 'Russian Blue'
  | 'Birman'
  | 'Abyssinian'
  | 'Bombay'
  | 'Burmese'
  | 'Manx'
  | 'Chartreux'
  | 'Savannah'
  | 'Devon Rex'
  | 'Norwegian Forest'
  | 'Turkish Angora'
  | 'Oriental Shorthair'
  | 'Nebelung';

export interface CatWarrior {
  id: string;
  name: string;
  codename: string;
  breed: CatBreed;
  description: string;
  personality: string;
  role: string;
  color: string;
  accentColor: string;
  furColor: string;
  suitColor: string;
  earColor?: string;
  eyeColor?: string;
  markingPattern?: 'stripes' | 'patches' | 'tuxedo' | 'spotted' | 'solid' | 'points';
  baseHp: number;
  baseArmor: number;
  baseSpeed: number;
  critChance: number;
  skillName: string;
  skillDescription: string;
  skillCooldown: number; // in seconds
  unlockLevel: number;
  unlockCost: number;
  unlocked: boolean;
  startingWeaponId: string;
  avatarIcon: string;
}

export type WeaponRarity = 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';

export interface WeaponCombatStats {
  damage: number;       // Effective damage per shot/pellet
  fireRate: number;     // Effective shots per second (Rate of Fire)
  reloadSpeed: number;  // Effective reload time in seconds (faster reload)
  magazineSize: number; // Magazine size
  range: number;        // Combat range
  dps: number;          // Sustained/burst Damage Per Second
}

export interface WeaponGrowth {
  damagePerLevel: number;
  fireRatePerLevel: number;
  reloadSpeedReductionPerLevel: number;
}

export interface Weapon {
  id: string;
  name: string;
  category: string;
  tier: number;            // 1 to 7 for Merge System
  rarity: WeaponRarity;
  description: string;
  damage: number;          // Base damage per projectile
  fireRate: number;        // Base rate of fire (rounds per second)
  reloadSpeed: number;     // Base reload speed (seconds)
  reloadTime: number;      // Alias for reloadSpeed
  magazineSize: number;
  dps: number;             // Base DPS rating = damage * pelletCount * fireRate
  growth?: WeaponGrowth;
  range: number;
  bulletSpeed: number;
  bulletColor: string;
  spread: number;          // radians
  pelletCount: number;
  penetration: number;
  isExplosive: boolean;
  explosionRadius?: number;
  isEnergy?: boolean;
  isFlamethrower?: boolean;
  isMinigun?: boolean;
  unlockCost: number;
  unlocked: boolean;
  level: number;
  icon?: string;
}

/**
 * Calculates real gameplay combat performance for a weapon based on level and modchips.
 */
export function calculateEffectiveWeaponStats(
  weapon: Weapon,
  level: number = 1,
  modchipLevel: number = 0
): WeaponCombatStats {
  const lvl = Math.max(1, level);
  const dmgGrowth = weapon.growth?.damagePerLevel ?? 0.15;
  const frGrowth = weapon.growth?.fireRatePerLevel ?? 0.04;
  const reloadReduction = weapon.growth?.reloadSpeedReductionPerLevel ?? 0.07;

  // Modchip bonus adds extra 5% damage per level
  const modchipDmgBonus = 1 + modchipLevel * 0.05;

  const effectiveDamage = Math.max(1, Math.round(weapon.damage * (1 + (lvl - 1) * dmgGrowth) * modchipDmgBonus));
  const effectiveFireRate = Math.max(0.2, parseFloat((weapon.fireRate * (1 + (lvl - 1) * frGrowth)).toFixed(2)));
  const effectiveReloadSpeed = Math.max(
    0.3,
    parseFloat((weapon.reloadSpeed - (lvl - 1) * reloadReduction).toFixed(2))
  );
  const effectiveDps = Math.round(effectiveDamage * weapon.pelletCount * effectiveFireRate);

  return {
    damage: effectiveDamage,
    fireRate: effectiveFireRate,
    reloadSpeed: effectiveReloadSpeed,
    magazineSize: weapon.magazineSize,
    range: weapon.range,
    dps: effectiveDps,
  };
}

export type EnemyType = 
  | 'mutant_rat'
  | 'zombie_cat'
  | 'armored_hound'
  | 'exploder'
  | 'acid_spitter'
  | 'flying_drone'
  | 'heavy_mech'
  | 'berserker'
  | 'shielded_elite'
  | 'lab_abomination'
  | 'frost_crawler'
  | 'desert_scorpion'
  | 'magma_golem';

export interface EnemyDef {
  type: EnemyType;
  name: string;
  hp: number;
  speed: number;
  damage: number;
  radius: number;
  color: string;
  accentColor: string;
  attackRange: number;
  attackCooldown: number;
  isRanged: boolean;
  projectileSpeed?: number;
  projectileColor?: string;
  scoreValue: number;
  coinDropChance: number;
  coinDropAmount: number;
  scrapDropChance: number;
}

export interface BossDef {
  id: string;
  name: string;
  title: string;
  maxHp: number;
  speed: number;
  radius: number;
  color: string;
  zoneId: number;
  phases: number;
  attacks: string[];
  rewardCoins: number;
  rewardScrap: number;
}

export interface Zone {
  id: number;
  name: string;
  codename: string;
  biome: 'urban' | 'industrial' | 'forest' | 'desert' | 'snow' | 'cyber' | 'volcanic';
  description: string;
  backgroundColor: string;
  gridColor: string;
  wallColor: string;
  hazardColor: string;
  ambientParticleType?: 'dust' | 'spores' | 'sand' | 'snow' | 'neon' | 'embers';
  levelsCount: number;
  boss: BossDef;
  allowedEnemies: EnemyType[];
}

export interface PlayerStats {
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  speed: number;
  x: number;
  y: number;
  angle: number;
  currentCat: string;
  currentWeapon: string;
  ammo: number;
  maxAmmo: number;
  isReloading: boolean;
  reloadProgress: number;
  skillCooldownRemaining: number;
  dodgeCooldownRemaining: number;
  isDodging: boolean;
  dodgeDuration: number;
  dodgeTimer: number;
  isShooting?: boolean;
  recoilOffset?: number;
  level: number;
  xp: number;
  nextLevelXp: number;
}

export interface Projectile {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  rangeRemaining: number;
  radius: number;
  color: string;
  fromPlayer: boolean;
  penetrationRemaining: number;
  isExplosive: boolean;
  explosionRadius?: number;
  isFlamethrower?: boolean;
  trail?: { x: number; y: number; alpha: number }[];
}

export interface EnemyInstance {
  id: number;
  type: EnemyType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  damage: number;
  isRanged: boolean;
  attackTimer: number;
  hitFlashTimer: number;
  shield?: number;
  angle: number;
}

export interface BossInstance {
  id: string;
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  speed: number;
  phase: number;
  radius: number;
  angle: number;
  attackTimer: number;
  specialTimer: number;
  isTelegraphing: boolean;
  telegraphTimer: number;
  telegraphType: string;
  hitFlashTimer: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  radius: number;
  alpha: number;
  life: number;
  maxLife: number;
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
  vy: number;
}

export interface PickupItem {
  id: number;
  type: 'coin' | 'medkit' | 'ammo' | 'scrap';
  x: number;
  y: number;
  value: number;
  radius: number;
  duration: number;
}

// Gun Merge Grid Item
export interface MergeSlot {
  slotId: number;
  weaponId: string | null;
  tier: number;
}

export interface PlayerProfile {
  coins: number;
  scrap: number;
  accountLevel: number;
  accountXp: number;
  selectedCat: string;
  selectedWeapon: string;
  unlockedCats: string[];
  unlockedWeapons: string[];
  weaponLevels: Record<string, number>;
  gearUpgrades: {
    helmet: number; // extra armor
    vest: number;   // extra hp
    boots: number;  // extra movement speed
    modchip: number;// extra crit & damage
  };
  highestZone: number;
  highestMission: number;
  starsEarned: Record<string, number>;
  totalKills: number;
  totalDamageDealt: number;
  lastDailyRewardDate?: string;
  // Rebirth System (Infinite growth)
  rebirthCount: number;
  valorMedals: number;
  rebirthMultiplier: number;
  // Merge Workshop System
  mergeSlots: MergeSlot[];
  // Idle Offline Rewards
  lastActiveTimestamp: number;
  settings: {
    soundEnabled: boolean;
    autoAim: boolean;
    joystickFixed: boolean;
    showDamageNumbers: boolean;
    screenShake: boolean;
  };
}

// Helper aliases for backwards compatibility
export type CatId = string;
export type WeaponType = string;
export type BossId = string;
