import React, { useState } from 'react';
import { PlayerProfile, CatId, WeaponType, calculateEffectiveWeaponStats } from '../types/game';
import { CAT_WARRIORS, WEAPONS, ZONES } from '../game/constants';
import { sound } from '../game/audio';
import { 
  Play, 
  Users, 
  Crosshair, 
  Wrench, 
  Settings as SettingsIcon, 
  Smartphone, 
  Gift, 
  Shield, 
  Heart, 
  Zap, 
  Footprints, 
  Lock, 
  ChevronRight, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Activity, 
  ArrowRightLeft,
  Radar,
  Radio,
  Terminal,
  Cpu,
  Sparkles,
  Award,
  Filter,
  CheckCircle2,
  TreePine,
  Snowflake,
  Sun,
  Flame,
  Building,
  Factory
} from 'lucide-react';

import { WeaponComparisonPanel } from './WeaponComparisonPanel';
import { WeaponTacticalMetrics } from './TacticalStatBar';
import { GunMergeWorkshop } from './GunMergeWorkshop';
import { RebirthWorkshop } from './RebirthWorkshop';
import { ProceduralCatSprite } from './ProceduralCatSprite';
import { ProceduralEnemySprite } from './ProceduralEnemySprite';

interface MainMenuProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => void;
  onStartMission: (zoneId: number, missionIndex: number) => void;
  onOpenAndroidHub: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  profile,
  onUpdateProfile,
  onStartMission,
  onOpenAndroidHub,
}) => {
  const [activeTab, setActiveTab] = useState<'missions' | 'heroes' | 'armory' | 'merge' | 'rebirth' | 'upgrades' | 'settings'>('missions');
  const [selectedZoneId, setSelectedZoneId] = useState<number>(profile.highestZone || 1);
  const [dailyClaimedMessage, setDailyClaimedMessage] = useState<string | null>(null);
  const [heroFilter, setHeroFilter] = useState<string>('all');
  const [weaponTierFilter, setWeaponTierFilter] = useState<number>(0); // 0 = all
  const [comparedWeaponId, setComparedWeaponId] = useState<WeaponType>(
    profile.selectedWeapon === 'shotgun' ? 'assault_rifle' : 'shotgun'
  );

  const selectedCat = CAT_WARRIORS.find((c) => c.id === profile.selectedCat) || CAT_WARRIORS[0];
  const selectedWeapon = WEAPONS.find((w) => w.id === profile.selectedWeapon) || WEAPONS[0];
  const comparedWeapon = WEAPONS.find((w) => w.id === comparedWeaponId) || (profile.selectedWeapon === 'shotgun' ? WEAPONS[1] : WEAPONS[3]);
  const selectedZone = ZONES.find((z) => z.id === selectedZoneId) || ZONES[0];

  // Daily Reward handling
  const handleClaimDailyReward = () => {
    sound.playPickup();
    const today = new Date().toISOString().slice(0, 10);
    onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins + 150,
      scrap: prev.scrap + 25,
      lastDailyRewardDate: today,
    }));
    setDailyClaimedMessage('LOGG: +150 KREDITER & +25 VAPENDELAR ALLOKERADE TILL BASEN');
    setTimeout(() => setDailyClaimedMessage(null), 3500);
  };

  const isDailyClaimed = profile.lastDailyRewardDate === new Date().toISOString().slice(0, 10);

  // Upgrade gear
  const handleUpgradeGear = (gear: 'helmet' | 'vest' | 'boots' | 'modchip') => {
    const currentGearLevel = profile?.gearUpgrades?.[gear] || 0;
    const cost = (currentGearLevel + 1) * 80;
    const scrapCost = (currentGearLevel + 1) * 10;

    if (profile.coins >= cost && profile.scrap >= scrapCost) {
      sound.playPickup();
      onUpdateProfile((prev) => ({
        ...prev,
        coins: prev.coins - cost,
        scrap: prev.scrap - scrapCost,
        gearUpgrades: {
          ...prev.gearUpgrades,
          [gear]: currentGearLevel + 1,
        },
      }));
    }
  };

  // Upgrade weapon
  const handleUpgradeWeapon = (weaponId: WeaponType) => {
    const currentLvl = profile?.weaponLevels?.[weaponId] || 1;
    const cost = currentLvl * 100;
    const scrapCost = currentLvl * 15;

    if (profile.coins >= cost && profile.scrap >= scrapCost) {
      sound.playPickup();
      onUpdateProfile((prev) => ({
        ...prev,
        coins: prev.coins - cost,
        scrap: prev.scrap - scrapCost,
        weaponLevels: {
          ...prev.weaponLevels,
          [weaponId]: currentLvl + 1,
        },
      }));
    }
  };

  // Unlock / select Cat
  const handleSelectCat = (catId: CatId) => {
    const cat = CAT_WARRIORS.find((c) => c.id === catId);
    if (!cat) return;

    if (profile.unlockedCats.includes(catId)) {
      sound.playMeow();
      onUpdateProfile((prev) => ({ ...prev, selectedCat: catId }));
    } else if (profile.coins >= cat.unlockCost) {
      sound.playPickup();
      sound.playMeow();
      onUpdateProfile((prev) => ({
        ...prev,
        coins: prev.coins - cat.unlockCost,
        unlockedCats: [...prev.unlockedCats, catId],
        selectedCat: catId,
      }));
    }
  };

  // Unlock / select Weapon
  const handleSelectWeapon = (weaponId: WeaponType) => {
    const weapon = WEAPONS.find((w) => w.id === weaponId);
    if (!weapon) return;

    if (profile.unlockedWeapons.includes(weaponId)) {
      sound.playClick();
      onUpdateProfile((prev) => ({ ...prev, selectedWeapon: weaponId }));
    } else if (profile.coins >= weapon.unlockCost) {
      sound.playPickup();
      onUpdateProfile((prev) => ({
        ...prev,
        coins: prev.coins - weapon.unlockCost,
        unlockedWeapons: [...prev.unlockedWeapons, weaponId],
        selectedWeapon: weaponId,
      }));
    }
  };

  // Filtered heroes
  const filteredCats = CAT_WARRIORS.filter((cat) => {
    if (heroFilter === 'all') return true;
    if (heroFilter === 'unlocked') return profile.unlockedCats.includes(cat.id);
    return cat.role.toLowerCase().includes(heroFilter.toLowerCase());
  });

  // Filtered weapons
  const filteredWeapons = WEAPONS.filter((w) => {
    if (weaponTierFilter === 0) return true;
    return w.tier === weaponTierFilter;
  });

  // Helper for biome icon
  const getBiomeIcon = (biome: string) => {
    switch (biome) {
      case 'forest': return <TreePine className="w-3.5 h-3.5 text-emerald-400" />;
      case 'snow': return <Snowflake className="w-3.5 h-3.5 text-cyan-400" />;
      case 'desert': return <Sun className="w-3.5 h-3.5 text-amber-400" />;
      case 'cyber': return <Zap className="w-3.5 h-3.5 text-purple-400" />;
      case 'volcanic': return <Flame className="w-3.5 h-3.5 text-rose-500" />;
      case 'industrial': return <Factory className="w-3.5 h-3.5 text-orange-400" />;
      default: return <Building className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div className="h-full w-full bg-[#040711] text-slate-100 flex flex-col select-none cyber-grid relative overflow-hidden">
      {/* Scanline Overlay - strictly clipped to prevent any scroll bounding box shifts */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="scanline-sweep" />
      </div>

      {/* TOP COMMAND HEADER */}
      <header className="shrink-0 flex items-center justify-between gap-4 px-5 py-3 border-b border-amber-500/20 bg-[#070c18]/95 backdrop-blur z-20 shadow-xl">
        {/* Unit Identity & Status */}
        <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center font-black text-slate-950 text-xl shadow-lg shadow-amber-500/20 border border-amber-300">
            🐾
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-black text-base tracking-wide text-slate-100">
                CAT WARRIORS
              </span>
              <span className="text-[10px] font-tech font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-1.5 py-0.5 rounded">
                SEC-2097
              </span>
            </div>
            <div className="text-[11px] font-tech text-slate-400 flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>SQUAD READY</span>
              <span className="text-slate-600">·</span>
              <span className="text-purple-400 font-bold">x{(profile.rebirthMultiplier || 1.0).toFixed(2)} MULTI</span>
            </div>
          </div>
        </div>

        {/* Central Tactical Segmented Control Tabs */}
        <nav className="hidden xl:flex items-center gap-1 bg-[#0b1222] p-1 rounded-lg border border-slate-800 text-xs font-tech">
          <button
            onClick={() => setActiveTab('missions')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-wide cursor-pointer ${
              activeTab === 'missions'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Radar className="w-3.5 h-3.5" />
            <span>Uppdrag ({ZONES.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('heroes')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-wide cursor-pointer ${
              activeTab === 'heroes'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Kattkrigare ({CAT_WARRIORS.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('armory')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-wide cursor-pointer ${
              activeTab === 'armory'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Crosshair className="w-3.5 h-3.5" />
            <span>Arsenal ({WEAPONS.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('merge')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-wide cursor-pointer ${
              activeTab === 'merge'
                ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-white font-bold shadow-md'
                : 'text-rose-400 hover:text-rose-300 hover:bg-rose-950/30'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Vapen-Merge</span>
          </button>
          <button
            onClick={() => setActiveTab('rebirth')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-wide cursor-pointer ${
              activeTab === 'rebirth'
                ? 'bg-purple-600 text-white font-bold shadow-md'
                : 'text-purple-400 hover:text-purple-300 hover:bg-purple-950/30'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-purple-300" />
            <span>Rebirth & Idle</span>
          </button>
          <button
            onClick={() => setActiveTab('upgrades')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-wide cursor-pointer ${
              activeTab === 'upgrades'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>Verkstad</span>
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-wide cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <SettingsIcon className="w-3.5 h-3.5" />
            <span>System</span>
          </button>
        </nav>

        {/* Resources & Android Export */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="flex items-center gap-3 bg-[#0a101f] border border-slate-800 px-3.5 py-1.5 rounded-lg font-tech text-xs">
            <span className="text-amber-400 font-bold flex items-center gap-1.5">
              <span>🪙</span>
              <span>{profile.coins}</span>
            </span>
            <span className="text-slate-700">|</span>
            <span className="text-cyan-400 font-bold flex items-center gap-1.5">
              <span>⚙️</span>
              <span>{profile.scrap}</span>
            </span>
          </div>

          <button
            onClick={onOpenAndroidHub}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-tech font-bold rounded-lg text-xs tracking-wider uppercase shadow-md shadow-blue-500/20 transition-all whitespace-nowrap cursor-pointer active:scale-95"
          >
            <Smartphone className="w-3.5 h-3.5 text-blue-200" />
            <span className="hidden sm:inline">Android</span>
          </button>
        </div>
      </header>

      {/* Sub-Navigation Bar for Mobile / Smaller Displays */}
      <div className="shrink-0 flex xl:hidden items-center justify-around bg-[#070c18] border-b border-slate-800/80 p-1.5 text-[11px] font-tech overflow-x-auto">
        <button
          onClick={() => setActiveTab('missions')}
          className={`px-2 py-1 rounded uppercase font-bold whitespace-nowrap ${activeTab === 'missions' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400'}`}
        >
          Uppdrag
        </button>
        <button
          onClick={() => setActiveTab('heroes')}
          className={`px-2 py-1 rounded uppercase font-bold whitespace-nowrap ${activeTab === 'heroes' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400'}`}
        >
          Krigare (26)
        </button>
        <button
          onClick={() => setActiveTab('armory')}
          className={`px-2 py-1 rounded uppercase font-bold whitespace-nowrap ${activeTab === 'armory' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400'}`}
        >
          Arsenal (36)
        </button>
        <button
          onClick={() => setActiveTab('merge')}
          className={`px-2 py-1 rounded uppercase font-bold whitespace-nowrap text-rose-400 ${activeTab === 'merge' ? 'bg-rose-500/20' : ''}`}
        >
          Merge 💥
        </button>
        <button
          onClick={() => setActiveTab('rebirth')}
          className={`px-2 py-1 rounded uppercase font-bold whitespace-nowrap text-purple-400 ${activeTab === 'rebirth' ? 'bg-purple-500/20' : ''}`}
        >
          Rebirth 👑
        </button>
        <button
          onClick={() => setActiveTab('upgrades')}
          className={`px-2 py-1 rounded uppercase font-bold whitespace-nowrap ${activeTab === 'upgrades' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400'}`}
        >
          Verkstad
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`px-2 py-1 rounded uppercase font-bold whitespace-nowrap ${activeTab === 'settings' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400'}`}
        >
          System
        </button>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 max-w-6xl mx-auto w-full z-10 overscroll-contain">
        {/* Daily Reward Notification */}
        <div className="mb-5 flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-xl bg-[#090e1c] border border-amber-500/30 tactical-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <Gift className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-xs text-slate-100">
                  DAGLIG LOGISTIKFÖRSÄRJNING
                </span>
                <span className="text-[10px] font-tech text-amber-400 font-bold uppercase">
                  DROP 24H
                </span>
              </div>
              <div className="text-[11px] font-tech text-slate-400">
                {dailyClaimedMessage ? (
                  <span className="text-emerald-400 font-semibold">{dailyClaimedMessage}</span>
                ) : (
                  'Kvittera ut dagens leverans av stridskrediter och metallskrot.'
                )}
              </div>
            </div>
          </div>

          <button
            onClick={handleClaimDailyReward}
            disabled={isDailyClaimed}
            className={`px-4 py-2 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
              isDailyClaimed
                ? 'bg-slate-800/60 text-slate-500 border border-slate-700/60 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md shadow-amber-500/20 active:scale-95'
            }`}
          >
            {isDailyClaimed ? 'KVITTERAT FÖR IDAG' : 'KVITTERA (+150 🪙 / +25 ⚙️)'}
          </button>
        </div>

        {/* TAB 1: MISSIONS (DIVERSE MAPS FROM FORESTS TO SNOWY PEAKS) */}
        {activeTab === 'missions' && (
          <div className="space-y-6">
            {/* 7 Diverse Maps Ribbon */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {ZONES.map((zone) => {
                const isSelected = zone.id === selectedZoneId;
                const isLocked = zone.id > profile.highestZone;

                return (
                  <button
                    key={zone.id}
                    onClick={() => {
                      if (!isLocked) {
                        sound.playClick();
                        setSelectedZoneId(zone.id);
                      }
                    }}
                    disabled={isLocked}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-tech font-bold uppercase tracking-wider whitespace-nowrap border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20'
                        : isLocked
                        ? 'bg-[#060a14]/60 border-slate-800 text-slate-600 cursor-not-allowed'
                        : 'bg-[#090e1c] border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {isLocked ? (
                      <Lock className="w-3.5 h-3.5 text-slate-600" />
                    ) : (
                      getBiomeIcon(zone.biome)
                    )}
                    <span>{zone.name}</span>
                  </button>
                );
              })}
            </div>

            {/* War Room Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Zone Intel & Operation Roster */}
              <div className="lg:col-span-2 bg-[#090e1c] border border-amber-500/20 rounded-xl p-5 tactical-border flex flex-col justify-between">
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                    <div>
                      <div className="text-[11px] font-tech text-amber-500 font-bold uppercase tracking-widest flex items-center gap-1.5">
                        {getBiomeIcon(selectedZone.biome)}
                        <span>{selectedZone.codename}</span>
                      </div>
                      <h2 className="text-2xl font-black text-slate-100 font-display">
                        {selectedZone.name}
                      </h2>
                    </div>
                    <div className="px-3 py-1 bg-rose-950/40 border border-rose-500/40 rounded text-xs font-tech font-bold text-rose-400 uppercase tracking-wide self-start sm:self-auto">
                      HOTNIVÅ: {selectedZone.boss.name}
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 mb-5 leading-relaxed font-tech">
                    {selectedZone.description}
                  </p>

                  {/* 3 Operations */}
                  <div className="space-y-3">
                    {[1, 2, 3].map((missionNum) => {
                      const isBossMission = missionNum === 3;
                      return (
                        <div
                          key={missionNum}
                          className="flex items-center justify-between p-3.5 rounded-lg bg-[#050914] border border-slate-800 hover:border-slate-700 transition-colors"
                        >
                          <div className="flex items-center gap-3.5">
                            <div className="shrink-0">
                              {isBossMission ? (
                                <ProceduralEnemySprite
                                  type={selectedZone.boss?.id || 'boss_rat_king'}
                                  isBoss={true}
                                  size={38}
                                />
                              ) : (
                                <ProceduralEnemySprite
                                  type={selectedZone.allowedEnemies[missionNum - 1] || selectedZone.allowedEnemies[0] || 'mutant_rat'}
                                  size={34}
                                />
                              )}
                            </div>
                            <div>
                              <div className="text-xs font-bold text-slate-100 font-display flex items-center gap-2">
                                <span>
                                  {isBossMission
                                    ? `BOSS-STRID: ${selectedZone.boss.name}`
                                    : `Rensningsoperation ${selectedZone.id}-0${missionNum}`}
                                </span>
                                {isBossMission && (
                                  <span className="text-[9px] font-tech text-rose-400 font-bold uppercase bg-rose-950/60 px-1.5 py-0.2 rounded border border-rose-800">
                                    APOKALYPS
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] font-tech text-slate-400 flex items-center gap-2">
                                <span>
                                  {isBossMission
                                    ? 'Eliminera mutantkärnan för fullständig sektorövertagande'
                                    : '3 intensiva vågor · Taktiskt kattstöd tillgängligt'}
                                </span>
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => onStartMission(selectedZone.id, missionNum)}
                            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all shadow-md cursor-pointer active:scale-95 ${
                              isBossMission
                                ? 'bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white shadow-rose-500/20'
                                : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                            }`}
                          >
                            <span>Gruppera</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Ready Status & Active Battle Loadout */}
              <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 tactical-border-cyan flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-slate-200 font-display flex items-center gap-2">
                      <Shield className="w-4 h-4 text-cyan-400" />
                      <span>Fältredo Trupp</span>
                    </h3>
                    <span className="text-[10px] font-tech text-emerald-400 font-bold">REDO</span>
                  </div>

                  {/* Active Cat Warrior Profile */}
                  <div className="p-3 bg-[#050914] rounded-lg border border-slate-800 mb-3 flex items-center gap-3">
                    <div className="shrink-0">
                      <ProceduralCatSprite cat={selectedCat} size={54} />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-100 font-display">
                        {selectedCat.name}
                      </div>
                      <div className="text-[11px] font-tech text-amber-400 font-semibold">
                        {selectedCat.breed} // {selectedCat.role}
                      </div>
                      <div className="text-[10px] font-tech text-purple-400">
                        ⚡ {selectedCat.skillName}
                      </div>
                    </div>
                  </div>

                  {/* Active Weapon Profile */}
                  {(() => {
                    const activeWeaponStats = calculateEffectiveWeaponStats(
                      selectedWeapon,
                      profile?.weaponLevels?.[selectedWeapon.id] || 1,
                      profile?.gearUpgrades?.modchip || 0
                    );
                    return (
                      <div className="p-3 bg-[#050914] rounded-lg border border-slate-800 mb-4 flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center justify-center text-xl text-amber-400 shrink-0">
                          {selectedWeapon.icon || '🔫'}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-slate-100 font-display">
                              {selectedWeapon.name}
                            </span>
                            <span className="text-[10px] font-tech text-purple-400 font-bold">
                              {activeWeaponStats.dps} DPS
                            </span>
                          </div>
                          <div className="text-[11px] font-tech text-cyan-400">
                            Tier {selectedWeapon.tier} {selectedWeapon.category}
                          </div>
                          <div className="text-[10px] font-tech text-slate-400 mt-0.5 flex items-center gap-2">
                            <span>{activeWeaponStats.damage} Skada</span>
                            <span>·</span>
                            <span>{activeWeaponStats.fireRate}/s</span>
                            <span>·</span>
                            <span>{activeWeaponStats.reloadSpeed}s</span>
                          </div>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Protective Gear Status */}
                  <div className="grid grid-cols-2 gap-2 text-[11px] font-tech text-slate-300">
                    <div className="bg-[#050914] p-2 rounded border border-slate-800/80 flex items-center justify-between">
                      <span className="text-slate-500 uppercase text-[10px]">Hjälm</span>
                      <span className="text-amber-400 font-bold">Lvl {profile?.gearUpgrades?.helmet || 0}</span>
                    </div>
                    <div className="bg-[#050914] p-2 rounded border border-slate-800/80 flex items-center justify-between">
                      <span className="text-slate-500 uppercase text-[10px]">Väst</span>
                      <span className="text-emerald-400 font-bold">Lvl {profile?.gearUpgrades?.vest || 0}</span>
                    </div>
                    <div className="bg-[#050914] p-2 rounded border border-slate-800/80 flex items-center justify-between">
                      <span className="text-slate-500 uppercase text-[10px]">Stövlar</span>
                      <span className="text-cyan-400 font-bold">Lvl {profile?.gearUpgrades?.boots || 0}</span>
                    </div>
                    <div className="bg-[#050914] p-2 rounded border border-slate-800/80 flex items-center justify-between">
                      <span className="text-slate-500 uppercase text-[10px]">Modchip</span>
                      <span className="text-purple-400 font-bold">Lvl {profile?.gearUpgrades?.modchip || 0}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onStartMission(selectedZone.id, 1)}
                  className="w-full mt-5 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-lg text-xs font-tech tracking-wider uppercase transition-all shadow-xl shadow-amber-500/20 active:scale-95 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>Starta Uppdrag ({selectedZone.name})</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: 25+ ADORABLE KITTY HEROES */}
        {activeTab === 'heroes' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl bg-[#090e1c] border border-amber-500/20 tactical-border">
              <div>
                <h2 className="text-base font-bold text-slate-100 font-display flex items-center gap-2">
                  <Users className="w-5 h-5 text-amber-500" />
                  <span>30 Kattkrigare att Samla ({CAT_WARRIORS.length} Unika Raser)</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5 font-tech">
                  Från fluffiga prickskyttar till hagelgevärsviftande tabbies – varje katt har sin egen personlighet och unika förmåga!
                </p>
              </div>

              {/* Filter controls */}
              <div className="flex items-center gap-1.5 bg-[#050914] p-1 rounded-lg border border-slate-800 font-tech text-xs">
                {['all', 'unlocked', 'Assault', 'Sniper', 'Juggernaut'].map((filt) => (
                  <button
                    key={filt}
                    onClick={() => setHeroFilter(filt)}
                    className={`px-2.5 py-1 rounded capitalize transition-all cursor-pointer ${
                      heroFilter === filt ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {filt === 'all' ? 'Alla' : filt === 'unlocked' ? 'Upplåsta' : filt}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCats.map((cat) => {
                const isSelected = profile.selectedCat === cat.id;
                const isUnlocked = profile.unlockedCats.includes(cat.id);

                return (
                  <div
                    key={cat.id}
                    className={`bg-[#090e1c] rounded-xl border p-4.5 flex flex-col justify-between transition-all ${
                      isSelected
                        ? 'border-amber-400 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400/40 tactical-border'
                        : isUnlocked
                        ? 'border-slate-800 hover:border-slate-700'
                        : 'border-slate-800/60 opacity-80'
                    }`}
                  >
                    <div>
                      {/* Cat Header */}
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="shrink-0 p-1 rounded-xl bg-[#050914] border border-slate-800 shadow-md">
                            <ProceduralCatSprite cat={cat} size={56} />
                          </div>
                          <div>
                            <div className="text-sm font-bold text-slate-100 font-display flex items-center gap-1.5">
                              <span>{cat.name}</span>
                            </div>
                            <div className="text-xs font-tech font-bold text-amber-400">
                              {cat.breed} · {cat.codename}
                            </div>
                            <div className="text-[10px] font-tech text-slate-500 uppercase">{cat.role}</div>
                          </div>
                        </div>

                        {isSelected && (
                          <span className="px-2 py-0.5 bg-amber-500 text-slate-950 font-tech font-bold text-[10px] rounded uppercase">
                            AKTIV
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-400 leading-relaxed mb-3 font-tech">{cat.description}</p>
                      <p className="text-[11px] text-amber-300/80 italic mb-3 font-tech">"{cat.personality}"</p>

                      {/* Stat Bars */}
                      <div className="space-y-1 font-tech text-[11px] mb-3 bg-[#050914] p-2.5 rounded-lg border border-slate-800/80">
                        <div className="flex justify-between text-slate-300">
                          <span className="flex items-center gap-1.5 text-slate-400">
                            <Heart className="w-3.5 h-3.5 text-emerald-400" /> Hälsa
                          </span>
                          <span className="text-emerald-400 font-bold">{cat.baseHp} HP</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span className="flex items-center gap-1.5 text-slate-400">
                            <Shield className="w-3.5 h-3.5 text-blue-400" /> Rustning
                          </span>
                          <span className="text-blue-400 font-bold">{cat.baseArmor} ARM</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span className="flex items-center gap-1.5 text-slate-400">
                            <Footprints className="w-3.5 h-3.5 text-cyan-400" /> Rörlighet
                          </span>
                          <span className="text-cyan-400 font-bold">{cat.baseSpeed} SPD</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span className="flex items-center gap-1.5 text-slate-400">
                            <Zap className="w-3.5 h-3.5 text-amber-400" /> Kritiskt
                          </span>
                          <span className="text-amber-400 font-bold">{Math.round(cat.critChance * 100)}%</span>
                        </div>
                      </div>

                      {/* Special Ability Box */}
                      <div className="p-2.5 rounded-lg bg-[#050914] border border-slate-800 text-xs mb-3 font-tech">
                        <div className="font-bold text-purple-400 flex items-center justify-between">
                          <span>⚡ {cat.skillName}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{cat.skillCooldown}s CD</span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1 leading-snug">{cat.skillDescription}</div>
                      </div>
                    </div>

                    {/* Action Button */}
                    {isSelected ? (
                      <div className="w-full py-2 bg-emerald-950/40 border border-emerald-800/60 text-emerald-400 font-tech text-xs font-bold rounded-lg text-center uppercase tracking-wider flex items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Aktiv Operatör</span>
                      </div>
                    ) : isUnlocked ? (
                      <button
                        onClick={() => handleSelectCat(cat.id)}
                        className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-tech text-xs font-bold rounded-lg transition-all cursor-pointer uppercase tracking-wider"
                      >
                        Välj Katten
                      </button>
                    ) : (
                      <button
                        onClick={() => handleSelectCat(cat.id)}
                        disabled={profile.coins < cat.unlockCost}
                        className={`w-full py-2 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          profile.coins >= cat.unlockCost
                            ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md'
                            : 'bg-slate-800/60 text-slate-500 border border-slate-700/60 cursor-not-allowed'
                        }`}
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>Rekrytera ({cat.unlockCost} 🪙)</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: 35+ GUNS TO MASTER */}
        {activeTab === 'armory' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#090e1c] border border-amber-500/20 tactical-border">
              <div>
                <h2 className="text-base font-bold text-slate-100 font-display flex items-center gap-2">
                  <Crosshair className="w-5 h-5 text-amber-500" />
                  <span>35+ Vapen att Bemästra ({WEAPONS.length} Skjutvapen)</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5 font-tech">
                  Pistoler, hagelbrakare, automatkarbiner, tunga miniguns och apokalypsvapen!
                </p>
              </div>

              {/* Tier Filter */}
              <div className="flex items-center gap-1 bg-[#050914] p-1 rounded-lg border border-slate-800 font-tech text-xs overflow-x-auto">
                {[0, 1, 2, 3, 4, 5, 6, 7].map((t) => (
                  <button
                    key={t}
                    onClick={() => setWeaponTierFilter(t)}
                    className={`px-2.5 py-1 rounded uppercase font-bold transition-all cursor-pointer ${
                      weaponTierFilter === t ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {t === 0 ? 'Alla Tiers' : `T${t}`}
                  </button>
                ))}
              </div>
            </div>

            {/* Weapon Comparison Panel */}
            <WeaponComparisonPanel
              currentWeapon={selectedWeapon}
              currentStats={calculateEffectiveWeaponStats(
                selectedWeapon,
                profile?.weaponLevels?.[selectedWeapon.id] || 1,
                profile?.gearUpgrades?.modchip || 0
              )}
              currentLevel={profile?.weaponLevels?.[selectedWeapon.id] || 1}
              comparedWeapon={comparedWeapon}
              comparedStats={calculateEffectiveWeaponStats(
                comparedWeapon,
                profile?.weaponLevels?.[comparedWeapon.id] || 1,
                profile?.gearUpgrades?.modchip || 0
              )}
              comparedLevel={profile?.weaponLevels?.[comparedWeapon.id] || 1}
              isEquipped={comparedWeapon.id === selectedWeapon.id}
              onSelectCompared={() => handleSelectWeapon(comparedWeapon.id)}
            />

            {/* Weapons Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredWeapons.map((weapon) => {
                const isSelected = profile.selectedWeapon === weapon.id;
                const isCompared = comparedWeaponId === weapon.id;
                const isUnlocked = profile.unlockedWeapons.includes(weapon.id);
                const currentLvl = profile?.weaponLevels?.[weapon.id] || 1;
                const upgradeCost = currentLvl * 100;
                const upgradeScrap = currentLvl * 15;
                const canUpgrade = profile.coins >= upgradeCost && profile.scrap >= upgradeScrap;

                const currentStats = calculateEffectiveWeaponStats(
                  weapon,
                  currentLvl,
                  profile?.gearUpgrades?.modchip || 0
                );
                const nextStats = calculateEffectiveWeaponStats(
                  weapon,
                  currentLvl + 1,
                  profile?.gearUpgrades?.modchip || 0
                );

                const damageDiff = nextStats.damage - currentStats.damage;
                const fireRateDiff = parseFloat((nextStats.fireRate - currentStats.fireRate).toFixed(2));
                const reloadDiff = parseFloat((currentStats.reloadSpeed - nextStats.reloadSpeed).toFixed(2));

                return (
                  <div
                    key={weapon.id}
                    className={`bg-[#090e1c] rounded-xl border p-4.5 flex flex-col justify-between transition-all ${
                      isCompared
                        ? 'border-amber-400 ring-1 ring-amber-400/40 shadow-xl shadow-amber-500/10 tactical-border'
                        : isSelected
                        ? 'border-amber-500/80 shadow-lg shadow-amber-500/10'
                        : isUnlocked
                        ? 'border-slate-800 hover:border-slate-700'
                        : 'border-slate-800/60 opacity-75'
                    }`}
                  >
                    <div>
                      {/* Weapon Header */}
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-slate-100 font-display">{weapon.name}</span>
                            <span className="text-[9px] font-tech font-bold px-1.5 py-0.2 rounded uppercase bg-amber-500/20 text-amber-400 border border-amber-500/30">
                              T{weapon.tier}
                            </span>
                          </div>
                          <div className="text-[11px] font-tech text-slate-400">
                            {weapon.category} {isUnlocked && `· Lvl ${currentLvl}`}
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {isSelected && (
                            <span className="px-1.5 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-400 font-tech font-bold text-[9px] rounded uppercase">
                              UTRUSTAD
                            </span>
                          )}
                          <button
                            onClick={() => {
                              sound.playClick();
                              setComparedWeaponId(weapon.id);
                            }}
                            className={`px-2 py-0.5 rounded text-[10px] font-tech font-bold uppercase transition-colors cursor-pointer ${
                              isCompared
                                ? 'bg-amber-500 text-slate-950'
                                : 'bg-[#050914] border border-slate-700 text-slate-300 hover:border-amber-400 hover:text-amber-400'
                            }`}
                          >
                            Jämför
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-slate-400 leading-relaxed mb-3 font-tech">{weapon.description}</p>

                      {/* Performance Stats using Stylized Tactical Progress Bars */}
                      <WeaponTacticalMetrics
                        stats={currentStats}
                        diffs={
                          isUnlocked
                            ? {
                                damage: damageDiff,
                                fireRate: fireRateDiff,
                                reloadSpeed: reloadDiff,
                              }
                            : undefined
                        }
                      />
                    </div>

                    {/* Weapon Actions */}
                    <div className="mt-4 pt-3 border-t border-slate-800/80">
                      {isUnlocked ? (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleSelectWeapon(weapon.id)}
                            disabled={isSelected}
                            className={`flex-1 py-2 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-950/40 border border-emerald-800 text-emerald-400 cursor-default'
                                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                            }`}
                          >
                            {isSelected ? 'Utrustad' : 'Utrusta'}
                          </button>

                          <button
                            onClick={() => handleUpgradeWeapon(weapon.id)}
                            disabled={!canUpgrade}
                            className={`px-3 py-2 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                              canUpgrade
                                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                                : 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                            }`}
                          >
                            +Lvl ({upgradeCost}🪙)
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleSelectWeapon(weapon.id)}
                          disabled={profile.coins < weapon.unlockCost}
                          className={`w-full py-2 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            profile.coins >= weapon.unlockCost
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                              : 'bg-slate-800/60 text-slate-500 border border-slate-700/60 cursor-not-allowed'
                          }`}
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Lås upp ({weapon.unlockCost} 🪙)</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: GUN MERGE SYSTEM (THE ADDICTIVE WORKSHOP) */}
        {activeTab === 'merge' && (
          <GunMergeWorkshop
            profile={profile}
            onUpdateProfile={onUpdateProfile}
            onEquipWeapon={handleSelectWeapon}
          />
        )}

        {/* TAB 5: REBIRTH & OFFLINE IDLE REWARDS */}
        {activeTab === 'rebirth' && (
          <RebirthWorkshop
            profile={profile}
            onUpdateProfile={onUpdateProfile}
          />
        )}

        {/* TAB 6: GEAR WORKSHOP / UPGRADES */}
        {activeTab === 'upgrades' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="p-4 rounded-xl bg-[#090e1c] border border-amber-500/20 tactical-border">
              <h2 className="text-base font-bold text-slate-100 font-display flex items-center gap-2">
                <Wrench className="w-5 h-5 text-amber-500" />
                <span>Teknisk Fältverkstad // Rustningssystem</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5 font-tech">
                Permanenta tekniska uppgraderingar som stärker hela kattkrigardivisionen.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Helmet */}
              <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 flex flex-col justify-between tactical-border">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                        <Shield className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-100 font-display">Taktisk Hjälm</div>
                        <div className="text-xs text-blue-400 font-tech font-semibold">
                          Nivå {profile?.gearUpgrades?.helmet || 0}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-tech text-emerald-400 font-bold">
                      +{(profile?.gearUpgrades?.helmet || 0) * 15} Rustning
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4 font-tech">
                    Förstärkt kolfiber och integrerat HUD-visir minskar inkommande kinetisk skada.
                  </p>
                </div>
                <button
                  onClick={() => handleUpgradeGear('helmet')}
                  disabled={
                    profile.coins < ((profile?.gearUpgrades?.helmet || 0) + 1) * 80 ||
                    profile.scrap < ((profile?.gearUpgrades?.helmet || 0) + 1) * 10
                  }
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800/60 disabled:text-slate-500 text-slate-950 font-tech font-bold text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer"
                >
                  Uppgradera ({((profile?.gearUpgrades?.helmet || 0) + 1) * 80} 🪙 / {((profile?.gearUpgrades?.helmet || 0) + 1) * 10} ⚙️)
                </button>
              </div>

              {/* Vest */}
              <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 flex flex-col justify-between tactical-border">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <Heart className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-100 font-display">Kevlarväst</div>
                        <div className="text-xs text-emerald-400 font-tech font-semibold">
                          Nivå {profile?.gearUpgrades?.vest || 0}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-tech text-emerald-400 font-bold">
                      +{(profile?.gearUpgrades?.vest || 0) * 25} HP
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4 font-tech">
                    Nanovävd kroppsrustning som ökar kattens maximala livskraft och uthållighet.
                  </p>
                </div>
                <button
                  onClick={() => handleUpgradeGear('vest')}
                  disabled={
                    profile.coins < ((profile?.gearUpgrades?.vest || 0) + 1) * 80 ||
                    profile.scrap < ((profile?.gearUpgrades?.vest || 0) + 1) * 10
                  }
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800/60 disabled:text-slate-500 text-slate-950 font-tech font-bold text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer"
                >
                  Uppgradera ({((profile?.gearUpgrades?.vest || 0) + 1) * 80} 🪙 / {((profile?.gearUpgrades?.vest || 0) + 1) * 10} ⚙️)
                </button>
              </div>

              {/* Boots */}
              <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 flex flex-col justify-between tactical-border">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                        <Footprints className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-100 font-display">Taktiska Tass-Stövlar</div>
                        <div className="text-xs text-cyan-400 font-tech font-semibold">
                          Nivå {profile?.gearUpgrades?.boots || 0}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-tech text-cyan-400 font-bold">
                      +{(profile?.gearUpgrades?.boots || 0) * 12} Snabbhet
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4 font-tech">
                    Maglev-dämpade kuddar som ökar förflyttningshastighet och räckvidd vid undvikning.
                  </p>
                </div>
                <button
                  onClick={() => handleUpgradeGear('boots')}
                  disabled={
                    profile.coins < ((profile?.gearUpgrades?.boots || 0) + 1) * 80 ||
                    profile.scrap < ((profile?.gearUpgrades?.boots || 0) + 1) * 10
                  }
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800/60 disabled:text-slate-500 text-slate-950 font-tech font-bold text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer"
                >
                  Uppgradera ({((profile?.gearUpgrades?.boots || 0) + 1) * 80} 🪙 / {((profile?.gearUpgrades?.boots || 0) + 1) * 10} ⚙️)
                </button>
              </div>

              {/* Modchip */}
              <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 flex flex-col justify-between tactical-border">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                        <Zap className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-100 font-display">Målsöknings-Modchip</div>
                        <div className="text-xs text-purple-400 font-tech font-semibold">
                          Nivå {profile?.gearUpgrades?.modchip || 0}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-tech text-purple-400 font-bold">
                      +{(profile?.gearUpgrades?.modchip || 0) * 5}% Skada
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4 font-tech">
                    Kvantprocessor som ökar alla vapens grundskada och kritiska skadepotential.
                  </p>
                </div>
                <button
                  onClick={() => handleUpgradeGear('modchip')}
                  disabled={
                    profile.coins < ((profile?.gearUpgrades?.modchip || 0) + 1) * 80 ||
                    profile.scrap < ((profile?.gearUpgrades?.modchip || 0) + 1) * 10
                  }
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800/60 disabled:text-slate-500 text-slate-950 font-tech font-bold text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer"
                >
                  Uppgradera ({((profile?.gearUpgrades?.modchip || 0) + 1) * 80} 🪙 / {((profile?.gearUpgrades?.modchip || 0) + 1) * 10} ⚙️)
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: SYSTEM SETTINGS */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-xl mx-auto">
            <div className="p-4 rounded-xl bg-[#090e1c] border border-amber-500/20 tactical-border">
              <h2 className="text-base font-bold text-slate-100 font-display">Systemkonfiguration</h2>
              <p className="text-xs text-slate-400 mt-0.5 font-tech">
                Kalibrera telemetri, skärmskakning, auto-målsökning och audio.
              </p>
            </div>

            <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 space-y-4 tactical-border">
              {/* Sound Toggle */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <div className="text-xs font-bold text-slate-200 font-display">Syntetiserade Ljudeffekter</div>
                  <div className="text-[11px] font-tech text-slate-400">Skott, explosioner och träffeffekter</div>
                </div>
                <button
                  onClick={() => {
                    const next = !(profile?.settings?.soundEnabled ?? true);
                    onUpdateProfile((prev) => ({
                      ...prev,
                      settings: { ...prev.settings, soundEnabled: next },
                    }));
                    sound.setMuted(!next);
                  }}
                  className={`px-3 py-1.5 rounded text-xs font-tech font-bold cursor-pointer uppercase ${
                    (profile?.settings?.soundEnabled ?? true)
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {(profile?.settings?.soundEnabled ?? true) ? 'PÅ' : 'AV'}
                </button>
              </div>

              {/* Auto Aim Toggle */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <div className="text-xs font-bold text-slate-200 font-display">Automatisk Målsökning</div>
                  <div className="text-[11px] font-tech text-slate-400">Siktar automatiskt mot närmaste fientliga enhet</div>
                </div>
                <button
                  onClick={() => {
                    const next = !(profile?.settings?.autoAim ?? true);
                    onUpdateProfile((prev) => ({
                      ...prev,
                      settings: { ...prev.settings, autoAim: next },
                    }));
                  }}
                  className={`px-3 py-1.5 rounded text-xs font-tech font-bold cursor-pointer uppercase ${
                    (profile?.settings?.autoAim ?? true)
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {(profile?.settings?.autoAim ?? true) ? 'PÅ' : 'AV'}
                </button>
              </div>

              {/* Screen Shake Toggle */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <div className="text-xs font-bold text-slate-200 font-display">Skärmskakning vid explosioner</div>
                  <div className="text-[11px] font-tech text-slate-400">Taktil skärmrekyl vid tunga artilleriträffar</div>
                </div>
                <button
                  onClick={() => {
                    const next = !(profile?.settings?.screenShake ?? true);
                    onUpdateProfile((prev) => ({
                      ...prev,
                      settings: { ...prev.settings, screenShake: next },
                    }));
                  }}
                  className={`px-3 py-1.5 rounded text-xs font-tech font-bold cursor-pointer uppercase ${
                    (profile?.settings?.screenShake ?? true)
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {(profile?.settings?.screenShake ?? true) ? 'PÅ' : 'AV'}
                </button>
              </div>

              {/* Damage Numbers Toggle */}
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-200 font-display">Flytande Skadesiffror</div>
                  <div className="text-[11px] font-tech text-slate-400">Visar skada och kritiska träffar i strid</div>
                </div>
                <button
                  onClick={() => {
                    const next = !(profile?.settings?.showDamageNumbers ?? true);
                    onUpdateProfile((prev) => ({
                      ...prev,
                      settings: { ...prev.settings, showDamageNumbers: next },
                    }));
                  }}
                  className={`px-3 py-1.5 rounded text-xs font-tech font-bold cursor-pointer uppercase ${
                    (profile?.settings?.showDamageNumbers ?? true)
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {(profile?.settings?.showDamageNumbers ?? true) ? 'PÅ' : 'AV'}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
