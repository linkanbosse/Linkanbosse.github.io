# Cat Warriors: Apocalypse

A mobile-friendly top-down cat action game project with a React/Vite web build and an Android Java project.

## Run locally

Requirements: Node.js 22 or newer.

```bash
npm install
npm run dev
```

## Build for web

```bash
npm run build
```

The static site is generated in `dist/`.

## Deploy to GitHub Pages

The workflow at `.github/workflows/deploy.yml` builds the Vite project and publishes `dist/` to GitHub Pages whenever a commit is pushed to `main`.

In the repository, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**. The workflow then handles deployments.

## Android project

The `android/` folder contains the native Android Java project files. It can be imported into a compatible Android IDE such as CodeAssist, subject to the IDE's Gradle support.
