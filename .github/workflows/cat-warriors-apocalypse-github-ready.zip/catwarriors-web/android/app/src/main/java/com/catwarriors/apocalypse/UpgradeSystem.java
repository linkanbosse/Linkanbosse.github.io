package com.catwarriors.apocalypse;

public class UpgradeSystem {
    public int helmetLevel = 0;
    public int vestLevel = 0;
    public int bootsLevel = 0;
    public int modchipLevel = 0;

    public void applyUpgrades(Player player) {
        player.maxArmor += helmetLevel * 15;
        player.armor = player.maxArmor;
        player.maxHp += vestLevel * 25;
        player.hp = player.maxHp;
        player.speed += bootsLevel * 12;
        player.critChance += modchipLevel * 0.03f;
    }
}
