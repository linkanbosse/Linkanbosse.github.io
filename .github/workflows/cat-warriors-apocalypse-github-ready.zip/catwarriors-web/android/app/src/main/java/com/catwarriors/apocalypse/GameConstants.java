package com.catwarriors.apocalypse;

public class GameConstants {
    public static final int TARGET_FPS = 60;
    public static final long OPTIMAL_TIME = 1000000000 / TARGET_FPS;
    public static final float ARENA_SIZE = 1400f;

    // Cat Warrior IDs
    public static final String CAT_ASSAULT = "assault";
    public static final String CAT_TANK = "tank";
    public static final String CAT_SNIPER = "sniper";
    public static final String CAT_MEDIC = "medic";
    public static final String CAT_ENGINEER = "engineer";
    public static final String CAT_SHADOW = "shadow";

    // Weapon IDs
    public static final String WEAPON_PISTOL = "pistol";
    public static final String WEAPON_ASSAULT_RIFLE = "assault_rifle";
    public static final String WEAPON_SMG = "smg";
    public static final String WEAPON_SHOTGUN = "shotgun";
    public static final String WEAPON_SNIPER = "sniper_rifle";
    public static final String WEAPON_LMG = "lmg";
    public static final String WEAPON_ROCKET = "rocket_launcher";
    public static final String WEAPON_FLAMETHROWER = "flamethrower";
    public static final String WEAPON_ENERGY_CARBINE = "energy_carbine";
    public static final String WEAPON_PLASMA = "plasma_cannon";
    public static final String WEAPON_GRENADE_LAUNCHER = "grenade_launcher";
    public static final String WEAPON_OBLITERATOR = "experimental_obliterator";

    // Enemy Types
    public static final String ENEMY_MUTANT_RAT = "mutant_rat";
    public static final String ENEMY_ZOMBIE_CAT = "zombie_cat";
    public static final String ENEMY_ARMORED_HOUND = "armored_hound";
    public static final String ENEMY_EXPLODER = "exploder";
    public static final String ENEMY_ACID_SPITTER = "acid_spitter";
    public static final String ENEMY_FLYING_DRONE = "flying_drone";
    public static final String ENEMY_HEAVY_MECH = "heavy_mech";
    public static final String ENEMY_BERSERKER = "berserker";
    public static final String ENEMY_SHIELDED_ELITE = "shielded_elite";
    public static final String ENEMY_LAB_ABOMINATION = "lab_abomination";
}
