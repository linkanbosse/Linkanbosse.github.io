import React, { useState } from 'react';
import { ANDROID_PROJECT_FILES, AndroidFile } from '../android-project/files';
import JSZip from 'jszip';
import { Download, Copy, Check, FileCode, Folder, Smartphone, ArrowLeft, Terminal, Cpu, FileText } from 'lucide-react';

interface AndroidProjectHubProps {
  onBack: () => void;
}

export const AndroidProjectHub: React.FC<AndroidProjectHubProps> = ({ onBack }) => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(
    ANDROID_PROJECT_FILES.find((f) => f.name === 'MainActivity.java') || ANDROID_PROJECT_FILES[0]
  );
  const [copied, setCopied] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'files' | 'guide'>('files');

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      const zip = new JSZip();

      for (const file of ANDROID_PROJECT_FILES) {
        zip.file(file.path, file.content);
      }

      // Add a quick README for CodeAssist
      zip.file(
        'README.txt',
        `CAT WARRIORS: APOCALYPSE - ANDROID CODEASSIST PROJEKT
Paketnamn: com.catwarriors.apocalypse
Version: 1.0.0
Spelmotor: Android SurfaceView + 2D Canvas Engine

HUR DU KÖR DETTA PROJEKT I CODEASSIST:
1. Extrahera denna zip-fil till telefonens lagring:
   t.ex. /storage/emulated/0/CodeAssist/projects/CatWarriorsApocalypse
2. Öppna CodeAssist-appen på din Android-enhet.
3. Välj 'Open Project' och navigera till mappen.
4. Tryck på Run/Build-knappen (Spela-ikonen) för att kompilera och installera APK:n direkt på din telefon!
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'CatWarriorsApocalypse_Android_Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate zip', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const javaFiles = ANDROID_PROJECT_FILES.filter((f) => f.category === 'java');
  const gradleFiles = ANDROID_PROJECT_FILES.filter((f) => f.category === 'gradle');
  const xmlFiles = ANDROID_PROJECT_FILES.filter((f) => f.category === 'xml');

  return (
    <div className="min-h-screen bg-[#040711] text-slate-100 flex flex-col select-none cyber-grid">
      {/* Top Header */}
      <header className="flex items-center justify-between px-6 py-3.5 border-b border-amber-500/20 bg-[#070c18]/95 backdrop-blur z-20 shadow-xl">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-tech font-bold uppercase tracking-wider bg-[#0b1222] hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg border border-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Tillbaka till Spelet</span>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-base text-slate-100">
                Android CodeAssist Källkodsprojekt
              </span>
              <span className="text-[10px] font-tech text-amber-400 bg-amber-500/10 border border-amber-500/30 px-1.5 py-0.5 rounded">
                NATIVE JAVA
              </span>
            </div>
            <p className="text-[11px] font-tech text-slate-400">
              Paket: <code className="text-amber-400 font-mono">com.catwarriors.apocalypse</code> · 30 filer · 100% Offline
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center bg-[#0b1222] p-1 rounded-lg border border-slate-800 text-xs font-tech">
            <button
              onClick={() => setActiveTab('files')}
              className={`px-3 py-1.5 rounded uppercase font-bold transition-all cursor-pointer ${
                activeTab === 'files' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Källkod
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-1.5 rounded uppercase font-bold transition-all cursor-pointer ${
                activeTab === 'guide' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              CodeAssist Guide
            </button>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={isDownloading}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-tech font-bold uppercase tracking-wider rounded-lg text-xs shadow-lg shadow-amber-500/20 transition-all cursor-pointer active:scale-95 disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isDownloading ? 'Packar ZIP...' : 'Ladda ner projekt (.ZIP)'}</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      {activeTab === 'files' ? (
        <div className="flex-1 flex overflow-hidden">
          {/* Left File Tree Sidebar */}
          <aside className="w-80 bg-[#070c18] border-r border-slate-800/80 flex flex-col overflow-y-auto p-4 shrink-0 font-tech">
            <div className="text-xs uppercase tracking-wider font-bold text-amber-400 mb-3 flex items-center gap-1.5 font-display">
              <Folder className="w-4 h-4 text-amber-500" />
              <span>Paketstruktur (Android)</span>
            </div>

            {/* Java Source Files */}
            <div className="mb-4">
              <div className="text-xs font-semibold text-slate-400 mb-1.5 px-2 uppercase tracking-wide">
                Java Motorklasser ({javaFiles.length})
              </div>
              <div className="space-y-0.5">
                {javaFiles.map((file) => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs font-tech flex items-center gap-2 transition-colors cursor-pointer ${
                      selectedFile.path === file.path
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <FileCode className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span className="truncate">{file.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Gradle Configs */}
            <div className="mb-4">
              <div className="text-xs font-semibold text-slate-400 mb-1.5 px-2 uppercase tracking-wide">
                Gradle Byggsystem ({gradleFiles.length})
              </div>
              <div className="space-y-0.5">
                {gradleFiles.map((file) => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs font-tech flex items-center gap-2 transition-colors cursor-pointer ${
                      selectedFile.path === file.path
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <Cpu className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">{file.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Android XML */}
            <div>
              <div className="text-xs font-semibold text-slate-400 mb-1.5 px-2 uppercase tracking-wide">
                Manifest & Resurser ({xmlFiles.length})
              </div>
              <div className="space-y-0.5">
                {xmlFiles.map((file) => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs font-tech flex items-center gap-2 transition-colors cursor-pointer ${
                      selectedFile.path === file.path
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span className="truncate">{file.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Right Code Viewer Area */}
          <section className="flex-1 flex flex-col bg-[#050812] overflow-hidden">
            {/* File Path & Copy Toolbar */}
            <div className="flex items-center justify-between px-6 py-3 border-b border-slate-800/80 bg-[#070c18] font-tech text-xs">
              <div className="flex items-center gap-2 text-slate-300 truncate">
                <span className="text-slate-500 uppercase">Fil:</span>
                <span className="text-amber-400 font-bold">{selectedFile.path}</span>
              </div>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0b1222] hover:bg-slate-800 text-slate-200 border border-slate-700 rounded transition-all cursor-pointer active:scale-95 text-xs font-tech"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>{copied ? 'Kopierad!' : 'Kopiera kod'}</span>
              </button>
            </div>

            {/* Code Content */}
            <div className="flex-1 overflow-auto p-6 bg-[#040711]">
              <pre className="font-tech text-xs text-slate-200 leading-relaxed font-mono select-text">
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </section>
        </div>
      ) : (
        /* CodeAssist Guide Tab */
        <div className="flex-1 overflow-y-auto p-8 max-w-4xl mx-auto w-full font-tech">
          <div className="bg-[#090e1c] border border-amber-500/30 rounded-xl p-8 tactical-border space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-display flex items-center gap-2">
                <Smartphone className="w-6 h-6 text-amber-500" />
                <span>Kompilering & Körning i CodeAssist på Android</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Det här projektet är strukturerat speciellt för CodeAssist IDE på Android-telefoner och surfplattor.
              </p>
            </div>

            <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
              <div className="p-4 bg-[#050914] rounded-lg border border-slate-800">
                <h3 className="font-bold text-amber-400 uppercase tracking-wide mb-1">
                  1. Ladda ner projektfilen
                </h3>
                <p>
                  Klicka på knappen <strong>"Ladda ner projekt (.ZIP)"</strong> längst upp till höger. Du får då filen{' '}
                  <code className="text-cyan-400">CatWarriorsApocalypse_Android_Project.zip</code>.
                </p>
              </div>

              <div className="p-4 bg-[#050914] rounded-lg border border-slate-800">
                <h3 className="font-bold text-amber-400 uppercase tracking-wide mb-1">
                  2. Extrahera på Android-enheten
                </h3>
                <p>
                  Extrahera mappen till din enhets interna lagring, förslagsvis under din CodeAssist-projektmapp:
                  <br />
                  <code className="text-emerald-400">
                    /storage/emulated/0/CodeAssist/projects/CatWarriorsApocalypse
                  </code>
                </p>
              </div>

              <div className="p-4 bg-[#050914] rounded-lg border border-slate-800">
                <h3 className="font-bold text-amber-400 uppercase tracking-wide mb-1">
                  3. Öppna och Bygg i CodeAssist
                </h3>
                <p>
                  Starta CodeAssist, tryck på <em>Open Project</em>, markera projektmappen och tryck på <strong>Run/Spela</strong>-knappen.
                  CodeAssist kompilerar då Java-koden via Gradle och genererar en körbar APK som installeras direkt på din enhet!
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
