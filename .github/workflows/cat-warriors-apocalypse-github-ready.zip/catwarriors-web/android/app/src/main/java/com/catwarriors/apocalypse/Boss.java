package com.catwarriors.apocalypse;

import java.util.List;

public class Boss {
    public String id;
    public String name;
    public float x;
    public float y;
    public float hp;
    public float maxHp;
    public float radius;
    public float speed;
    public float angle;
    public int phase = 1;
    public float attackTimer = 2.0f;
    public float specialTimer = 5.0f;
    public boolean isTelegraphing = false;
    public float hitFlashTimer = 0;
    public boolean active = true;

    public Boss(String id, String name, float maxHp, float speed, float radius) {
        this.id = id;
        this.name = name;
        this.hp = maxHp;
        this.maxHp = maxHp;
        this.speed = speed;
        this.radius = radius;
        this.x = 350;
        this.y = -200;
    }

    public void update(Player player, float dt, List<Projectile> projectiles) {
        if (hitFlashTimer > 0) hitFlashTimer -= dt;

        float dx = player.x - x;
        float dy = player.y - y;
        float dist = (float) Math.hypot(dx, dy);

        angle = (float) Math.atan2(dy, dx);

        if (dist > 150) {
            x += (dx / dist) * speed * dt;
            y += (dy / dist) * speed * dt;
        }

        attackTimer -= dt;
        specialTimer -= dt;

        // Spread shot
        if (attackTimer <= 0) {
            attackTimer = 1.8f;
            for (int s = -1; s <= 1; s++) {
                float shotAngle = angle + s * 0.25f;
                projectiles.add(new Projectile(
                        x, y,
                        (float) Math.cos(shotAngle) * 320,
                        (float) Math.sin(shotAngle) * 320,
                        28, 600, 7, 0xFFF97316, false, 1, false, 0
                ));
            }
        }

        // Radial nova burst
        if (specialTimer <= 0) {
            specialTimer = 5.5f;
            for (int a = 0; a < 12; a++) {
                float ang = (float) ((a * Math.PI * 2) / 12);
                projectiles.add(new Projectile(
                        x, y,
                        (float) Math.cos(ang) * 280,
                        (float) Math.sin(ang) * 280,
                        32, 550, 8, 0xFFDC2626, false, 1, true, 60
                ));
            }
        }
    }

    public void takeDamage(float dmg) {
        hp -= dmg;
        hitFlashTimer = 0.08f;
        if (hp <= 0) {
            active = false;
        }
    }
}
