package com.catwarriors.apocalypse;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private GameLoop gameLoop;
    private GameEngine gameEngine;

    // Touch controls tracking
    private int joystickPointerId = -1;
    private float joystickStartX = 0;
    private float joystickStartY = 0;
    private float joystickCurX = 0;
    private float joystickCurY = 0;

    public GameView(Context context) {
        super(context);
        getHolder().addCallback(this);
        setFocusable(true);

        this.gameEngine = new GameEngine(context);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        resumeGame();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        gameEngine.setViewportSize(width, height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        pauseGame();
    }

    public void resumeGame() {
        if (gameLoop == null || !gameLoop.isAlive()) {
            gameLoop = new GameLoop(getHolder(), this);
            gameLoop.setRunning(true);
            gameLoop.start();
        }
    }

    public void pauseGame() {
        if (gameLoop != null) {
            gameLoop.setRunning(false);
            boolean retry = true;
            while (retry) {
                try {
                    gameLoop.join();
                    retry = false;
                } catch (InterruptedException ignored) {}
            }
            gameLoop = null;
        }
    }

    public void cleanup() {
        pauseGame();
        if (gameEngine != null) {
            gameEngine.cleanup();
        }
    }

    public void update(float dt) {
        if (gameEngine != null) {
            gameEngine.update(dt);
        }
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (gameEngine != null) {
            gameEngine.render(canvas);
            drawTouchControls(canvas);
        }
    }

    private void drawTouchControls(Canvas canvas) {
        if (joystickPointerId != -1) {
            android.graphics.Paint p = new android.graphics.Paint();
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setColor(0x66FFFFFF);
            p.setStrokeWidth(4);
            canvas.drawCircle(joystickStartX, joystickStartY, 100, p);

            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(0xAA3B82F6);
            canvas.drawCircle(joystickCurX, joystickCurY, 45, p);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();
        int pointerId = event.getPointerId(index);

        float x = event.getX(index);
        float y = event.getY(index);
        int screenWidth = getWidth();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (x < screenWidth * 0.45f) {
                    // Left screen = movement joystick
                    joystickPointerId = pointerId;
                    joystickStartX = x;
                    joystickStartY = y;
                    joystickCurX = x;
                    joystickCurY = y;
                } else {
                    // Right screen buttons: Skill, Dodge, Fire
                    if (y > getHeight() * 0.7f && x > screenWidth * 0.8f) {
                        gameEngine.onFirePressed();
                    } else if (x > screenWidth * 0.85f && y < getHeight() * 0.65f) {
                        gameEngine.onDodgePressed();
                    } else if (x > screenWidth * 0.7f && y > getHeight() * 0.75f) {
                        gameEngine.onSkillPressed();
                    }
                }
                break;

            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int pId = event.getPointerId(i);
                    if (pId == joystickPointerId) {
                        float px = event.getX(i);
                        float py = event.getY(i);
                        float dx = px - joystickStartX;
                        float dy = py - joystickStartY;
                        float dist = (float) Math.hypot(dx, dy);
                        float maxRadius = 100f;

                        if (dist > maxRadius) {
                            dx = (dx / dist) * maxRadius;
                            dy = (dy / dist) * maxRadius;
                        }

                        joystickCurX = joystickStartX + dx;
                        joystickCurY = joystickStartY + dy;

                        gameEngine.setMoveInput(dx / maxRadius, dy / maxRadius);
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if (pointerId == joystickPointerId) {
                    joystickPointerId = -1;
                    gameEngine.setMoveInput(0, 0);
                } else {
                    gameEngine.onFireReleased();
                }
                break;
        }

        return true;
    }
}
