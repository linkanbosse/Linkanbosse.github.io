import React, { useState } from 'react';
import { Zone, BossInstance, PlayerStats } from '../types/game';
import { Target, CheckCircle2, Circle, AlertTriangle, ShieldCheck, Zap, Coins, ChevronDown, ChevronUp } from 'lucide-react';

interface MissionObjectivesHUDProps {
  zone: Zone;
  missionIndex: number;
  currentWave: number;
  maxWaves: number;
  waveEnemiesRemaining: number;
  boss: BossInstance | null;
  playerStats: PlayerStats | null;
  comboCount: number;
  coinsEarned: number;
  forceCompact?: boolean;
}

export const MissionObjectivesHUD: React.FC<MissionObjectivesHUDProps> = ({
  zone,
  missionIndex,
  currentWave,
  maxWaves,
  waveEnemiesRemaining,
  boss,
  playerStats,
  comboCount,
  coinsEarned,
  forceCompact = false,
}) => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(true);

  const collapsed = isCollapsed || forceCompact;

  // Bonus objectives evaluation
  const hpAboveHalf = playerStats ? playerStats.hp >= playerStats.maxHp * 0.5 : true;
  const comboTargetAchieved = comboCount >= 5;
  const lootTargetAchieved = coinsEarned >= 15;

  const isBossWave = missionIndex === 3 && currentWave === maxWaves;

  return (
    <div
      className={`bg-[#090e1c]/75 backdrop-blur-md border border-amber-500/30 rounded-xl shadow-2xl font-tech pointer-events-auto transition-all duration-200 select-none ${
        collapsed
          ? 'p-2 w-auto max-w-[230px] tactical-border-amber'
          : 'p-3 w-64 sm:w-72 tactical-border'
      }`}
    >
      {/* Collapsed Minimal Tracker Pill */}
      {collapsed ? (
        <div className="flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 truncate">
            <Target className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="font-bold text-amber-400 font-mono text-[11px] truncate">
              {isBossWave ? '⚠️ APEX BOSS' : `VÅG ${currentWave}/${maxWaves}`}
            </span>
            <span className="text-slate-400 text-[10px] font-mono shrink-0">
              {isBossWave
                ? `${Math.round(((boss?.hp || 0) / (boss?.maxHp || 1)) * 100)}%`
                : `(${waveEnemiesRemaining} kvar)`}
            </span>
          </div>
          <button
            onClick={() => setIsCollapsed(false)}
            className="p-1 hover:text-amber-300 text-slate-400 rounded hover:bg-slate-800/60 transition-colors cursor-pointer shrink-0"
            title="Expandera uppdragsmål"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div>
          {/* Header with expand/collapse */}
          <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold uppercase tracking-wider">
              <Target className="w-3.5 h-3.5 text-amber-500" />
              <span>UPPDRAG // ZON 0{zone.id}-0{missionIndex}</span>
            </div>
            <button
              onClick={() => setIsCollapsed(true)}
              className="p-1 hover:text-amber-300 text-slate-400 rounded hover:bg-slate-800 transition-colors cursor-pointer"
              title="Minimera uppdragsmål"
            >
              <ChevronUp className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5 pt-2 text-xs">
          {/* 1. Primary Objective */}
          <div>
            <div className="flex items-center justify-between text-[11px] mb-1">
              <span className="text-slate-400 font-medium uppercase tracking-wide">
                Huvudmål:
              </span>
              <span className="text-amber-400 font-bold font-mono">
                {isBossWave ? 'APEX-STRID' : `VÅG ${currentWave}/${maxWaves}`}
              </span>
            </div>

            {isBossWave && boss ? (
              <div className="bg-rose-950/40 border border-rose-600/40 rounded-lg p-2 space-y-1.5">
                <div className="flex items-center justify-between text-rose-300 font-bold text-[11px]">
                  <span className="flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    <span>ELIMINERA {boss.name.toUpperCase()}</span>
                  </span>
                  <span className="font-mono text-xs">{Math.round((boss.hp / boss.maxHp) * 100)}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-rose-900">
                  <div
                    className="h-full bg-gradient-to-r from-rose-600 to-amber-500 transition-all duration-75"
                    style={{ width: `${Math.max(0, (boss.hp / boss.maxHp) * 100)}%` }}
                  />
                </div>
              </div>
            ) : (
              <div className="bg-[#050914] border border-slate-800 rounded-lg p-2 space-y-1.5">
                <div className="flex items-center justify-between text-slate-200 text-[11px]">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>Rensa mutanthorder</span>
                  </span>
                  <span className="text-slate-400 font-mono text-[10px]">
                    {waveEnemiesRemaining} kvar
                  </span>
                </div>
                {/* Wave step pips */}
                <div className="grid grid-cols-3 gap-1.5 pt-0.5">
                  {[1, 2, 3].map((w) => (
                    <div
                      key={w}
                      className={`h-1.5 rounded-full transition-all ${
                        w < currentWave
                          ? 'bg-emerald-500'
                          : w === currentWave
                          ? 'bg-amber-400 animate-pulse'
                          : 'bg-slate-800'
                      }`}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 2. Tactical Bonus Bounties */}
          <div className="space-y-1.5">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold flex items-center justify-between">
              <span>Sekundära Bonuskontrakt</span>
              <span className="text-amber-500 font-mono text-[9px]">+BELÖNING</span>
            </div>

            {/* Bounty 1: HP Maintenance */}
            <div className="flex items-center justify-between p-1.5 bg-[#050914]/80 rounded border border-slate-800/80 text-[11px]">
              <div className="flex items-center gap-1.5 text-slate-300">
                <ShieldCheck className={`w-3.5 h-3.5 ${hpAboveHalf ? 'text-emerald-400' : 'text-slate-500'}`} />
                <span>Håll HP &gt; 50%</span>
              </div>
              <span className={`text-[10px] font-bold ${hpAboveHalf ? 'text-emerald-400' : 'text-rose-400'}`}>
                {hpAboveHalf ? 'AKTIV' : 'BRUTEN'}
              </span>
            </div>

            {/* Bounty 2: Combo Streak */}
            <div className="flex items-center justify-between p-1.5 bg-[#050914]/80 rounded border border-slate-800/80 text-[11px]">
              <div className="flex items-center gap-1.5 text-slate-300">
                <Zap className={`w-3.5 h-3.5 ${comboTargetAchieved ? 'text-amber-400' : 'text-slate-500'}`} />
                <span>5x Kombo-streak</span>
              </div>
              <span className={`text-[10px] font-bold ${comboTargetAchieved ? 'text-emerald-400' : 'text-amber-400 font-mono'}`}>
                {comboTargetAchieved ? '✓ KLAR' : `${Math.min(5, comboCount)}/5`}
              </span>
            </div>

            {/* Bounty 3: Coin Looting */}
            <div className="flex items-center justify-between p-1.5 bg-[#050914]/80 rounded border border-slate-800/80 text-[11px]">
              <div className="flex items-center gap-1.5 text-slate-300">
                <Coins className={`w-3.5 h-3.5 ${lootTargetAchieved ? 'text-amber-400' : 'text-slate-500'}`} />
                <span>Bärga 15+ Krediter</span>
              </div>
              <span className={`text-[10px] font-bold ${lootTargetAchieved ? 'text-emerald-400' : 'text-slate-400 font-mono'}`}>
                {lootTargetAchieved ? '✓ KLAR' : `${Math.min(15, coinsEarned)}/15`}
              </span>
            </div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
};
