import React, { useState, useEffect } from 'react';
import { PlayerProfile } from './types/game';
import { INITIAL_PLAYER_PROFILE } from './game/constants';
import { MainMenu } from './components/MainMenu';
import { GameCanvas } from './components/GameCanvas';
import { AndroidProjectHub } from './components/AndroidProjectHub';

const STORAGE_KEY = 'cat_warriors_apocalypse_profile_v2';

function safeMergeProfile(savedStr: string | null): PlayerProfile {
  if (!savedStr) return INITIAL_PLAYER_PROFILE;
  try {
    const saved = JSON.parse(savedStr);
    return {
      ...INITIAL_PLAYER_PROFILE,
      ...saved,
      weaponLevels: { ...INITIAL_PLAYER_PROFILE.weaponLevels, ...(saved.weaponLevels || {}) },
      gearUpgrades: { ...INITIAL_PLAYER_PROFILE.gearUpgrades, ...(saved.gearUpgrades || {}) },
      settings: { ...INITIAL_PLAYER_PROFILE.settings, ...(saved.settings || {}) },
      mergeSlots: saved.mergeSlots || INITIAL_PLAYER_PROFILE.mergeSlots,
      unlockedCats: Array.isArray(saved.unlockedCats) && saved.unlockedCats.length > 0 ? saved.unlockedCats : INITIAL_PLAYER_PROFILE.unlockedCats,
      unlockedWeapons: Array.isArray(saved.unlockedWeapons) && saved.unlockedWeapons.length > 0 ? saved.unlockedWeapons : INITIAL_PLAYER_PROFILE.unlockedWeapons,
      rebirthCount: saved.rebirthCount || 0,
      valorMedals: saved.valorMedals || 0,
      rebirthMultiplier: saved.rebirthMultiplier || 1.0,
      lastActiveTimestamp: saved.lastActiveTimestamp || Date.now(),
    };
  } catch (err) {
    console.warn('Failed to parse saved profile, using defaults:', err);
    return INITIAL_PLAYER_PROFILE;
  }
}

export default function App() {
  const [profile, setProfile] = useState<PlayerProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('cat_warriors_apocalypse_profile_v1');
      return safeMergeProfile(saved);
    } catch (e) {
      console.warn('Storage read failed:', e);
      return INITIAL_PLAYER_PROFILE;
    }
  });

  const [currentView, setCurrentView] = useState<'MENU' | 'PLAY' | 'ANDROID_HUB'>('MENU');
  const [activeZoneId, setActiveZoneId] = useState<number>(1);
  const [activeMissionIndex, setActiveMissionIndex] = useState<number>(1);

  // Save profile to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.warn('Failed to save profile to localStorage', e);
    }
  }, [profile]);

  const handleStartMission = (zoneId: number, missionIndex: number) => {
    setActiveZoneId(zoneId);
    setActiveMissionIndex(missionIndex);
    setCurrentView('PLAY');
  };

  const [playSessionKey, setPlaySessionKey] = useState<number>(1);

  const handleExitGame = (
    reward?: { coins: number; scrap: number; score: number; won: boolean },
    action: 'MENU' | 'RETRY' | 'NEXT' = 'MENU'
  ) => {
    let targetZone = activeZoneId;
    let targetMission = activeMissionIndex;

    if (reward) {
      setProfile((prev) => {
        let nextZone = prev.highestZone;
        let nextMission = prev.highestMission;

        if (reward.won) {
          if (activeMissionIndex === 3) {
            // Boss defeated, unlock next zone across all 7 diverse maps!
            nextZone = Math.min(7, Math.max(prev.highestZone, activeZoneId + 1));
            nextMission = 1;
            targetZone = Math.min(7, activeZoneId + 1);
            targetMission = 1;
          } else {
            nextMission = Math.min(3, Math.max(prev.highestMission, activeMissionIndex + 1));
            targetMission = activeMissionIndex + 1;
          }
        }

        return {
          ...prev,
          coins: prev.coins + reward.coins,
          scrap: prev.scrap + reward.scrap,
          totalKills: prev.totalKills + (reward.won ? 15 : 5),
          totalDamageDealt: prev.totalDamageDealt + reward.score * 10,
          highestZone: nextZone,
          highestMission: nextMission,
          lastActiveTimestamp: Date.now(),
        };
      });
    }

    if (action === 'RETRY') {
      setPlaySessionKey((k) => k + 1);
      setCurrentView('PLAY');
    } else if (action === 'NEXT') {
      setActiveZoneId(targetZone);
      setActiveMissionIndex(targetMission);
      setPlaySessionKey((k) => k + 1);
      setCurrentView('PLAY');
    } else {
      setCurrentView('MENU');
    }
  };

  return (
    <div className="w-screen h-screen overflow-hidden bg-slate-950 font-sans text-slate-100">
      {currentView === 'MENU' && (
        <MainMenu
          profile={profile}
          onUpdateProfile={setProfile}
          onStartMission={handleStartMission}
          onOpenAndroidHub={() => setCurrentView('ANDROID_HUB')}
        />
      )}

      {currentView === 'PLAY' && (
        <GameCanvas
          key={playSessionKey}
          profile={profile}
          zoneId={activeZoneId}
          missionIndex={activeMissionIndex}
          onExit={handleExitGame}
        />
      )}

      {currentView === 'ANDROID_HUB' && (
        <AndroidProjectHub onBack={() => setCurrentView('MENU')} />
      )}
    </div>
  );
}
