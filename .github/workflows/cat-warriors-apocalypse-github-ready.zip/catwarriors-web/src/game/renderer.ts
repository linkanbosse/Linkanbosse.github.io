import {
  PlayerStats,
  Projectile,
  EnemyInstance,
  BossInstance,
  Particle,
  FloatingText,
  PickupItem,
  Zone,
} from '../types/game';
import { CAT_WARRIORS, WEAPONS } from './constants';
import { ProceduralSpriteRenderer } from './sprites';
import { ProceduralTerrain } from './terrain';

export class GameRenderer {
  private terrain: ProceduralTerrain | null = null;

  public draw(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    cameraX: number,
    cameraY: number,
    zone: Zone,
    player: PlayerStats,
    projectiles: Projectile[],
    enemies: EnemyInstance[],
    boss: BossInstance | null,
    particles: Particle[],
    floatingTexts: FloatingText[],
    pickups: PickupItem[],
    drones: { x: number; y: number; angle: number }[],
    gameTime: number
  ) {
    // 1. Clear background
    ctx.fillStyle = zone.backgroundColor;
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    // Center camera on viewport with smooth positioning
    ctx.translate(width / 2 - cameraX, height / 2 - cameraY);

    // 2. Draw ground terrain, biome details & ambient particles
    this.drawEnvironment(ctx, zone, cameraX, cameraY, width, height, gameTime);

    // 3. Draw pickups
    this.drawPickups(ctx, pickups, gameTime);

    // 4. Draw enemies with expressive walk cycles
    for (const enemy of enemies) {
      this.drawEnemy(ctx, enemy, gameTime);
    }

    // 5. Draw boss
    if (boss) {
      this.drawBoss(ctx, boss, gameTime);
    }

    // 6. Draw drones
    for (const drone of drones) {
      this.drawDrone(ctx, drone, gameTime);
    }

    // 7. Draw adorable, highly-animated cat warrior
    this.drawPlayer(ctx, player, gameTime);

    // 8. Draw projectiles with laser streaks & glow
    this.drawProjectiles(ctx, projectiles, gameTime);

    // 9. Draw particles
    this.drawParticles(ctx, particles);

    // 10. Draw floating damage / XP text
    this.drawFloatingText(ctx, floatingTexts);

    ctx.restore();
  }

  private drawEnvironment(
    ctx: CanvasRenderingContext2D,
    zone: Zone,
    cx: number,
    cy: number,
    vw: number,
    vh: number,
    gameTime: number
  ) {
    const gridSize = 80;
    const startX = Math.floor((cx - vw) / gridSize) * gridSize;
    const endX = Math.ceil((cx + vw) / gridSize) * gridSize;
    const startY = Math.floor((cy - vh) / gridSize) * gridSize;
    const endY = Math.ceil((cy + vh) / gridSize) * gridSize;

    // 1. Ambient subtle ground coordinate grid
    ctx.strokeStyle = zone.gridColor;
    ctx.lineWidth = 1;
    ctx.globalAlpha = 0.65;
    ctx.beginPath();
    for (let x = startX; x <= endX; x += gridSize) {
      ctx.moveTo(x, startY);
      ctx.lineTo(x, endY);
    }
    for (let y = startY; y <= endY; y += gridSize) {
      ctx.moveTo(startX, y);
      ctx.lineTo(endX, y);
    }
    ctx.stroke();
    ctx.globalAlpha = 1.0;

    // 2. Rich Procedural Terrain: Biome ground decals, pools, boulders, cover & perimeter barricade
    if (!this.terrain) {
      this.terrain = new ProceduralTerrain(zone);
    }
    this.terrain.draw(ctx, zone, cx, cy, vw, vh, gameTime);

    // 3. Floating ambient weather particles
    const seed = zone.id * 137;
    const particleType = zone.ambientParticleType || 'dust';
    const numAmbient = 32;
    for (let p = 0; p < numAmbient; p++) {
      const px = ((seed * 17 + p * 133 + gameTime * (particleType === 'snow' ? 20 : 40)) % 2400) - 1200;
      const py = ((seed * 31 + p * 187 + gameTime * (particleType === 'snow' ? 55 : 25)) % 2400) - 1200;

      if (Math.abs(px - cx) < vw && Math.abs(py - cy) < vh) {
        if (particleType === 'snow') {
          ctx.fillStyle = '#ffffff';
          ctx.globalAlpha = 0.55;
          ctx.beginPath();
          ctx.arc(px, py, 2.5, 0, Math.PI * 2);
          ctx.fill();
        } else if (particleType === 'spores') {
          ctx.fillStyle = '#4ade80';
          ctx.globalAlpha = 0.45;
          ctx.beginPath();
          ctx.arc(px, py, 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (particleType === 'embers') {
          ctx.fillStyle = '#f97316';
          ctx.globalAlpha = 0.6;
          ctx.beginPath();
          ctx.arc(px, py, 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (particleType === 'sand') {
          ctx.fillStyle = '#fbbf24';
          ctx.globalAlpha = 0.4;
          ctx.beginPath();
          ctx.arc(px, py, 2.2, 0, Math.PI * 2);
          ctx.fill();
        } else if (particleType === 'neon') {
          ctx.fillStyle = '#c084fc';
          ctx.globalAlpha = 0.5;
          ctx.beginPath();
          ctx.arc(px, py, 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    ctx.globalAlpha = 1.0;
  }

  private drawPlayer(ctx: CanvasRenderingContext2D, player: PlayerStats, gameTime: number) {
    const cat = CAT_WARRIORS.find((c) => c.id === player.currentCat) || CAT_WARRIORS[0];

    ctx.save();
    ctx.translate(player.x, player.y);

    // 1. Soft Ambient Ground Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.beginPath();
    ctx.ellipse(0, 18, 25, 13, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.rotate(player.angle);

    // 2. High-Fidelity Procedural Cat Warrior Sprite
    ProceduralSpriteRenderer.drawCat(
      ctx,
      cat,
      player.currentWeapon,
      player.isDodging,
      Boolean(player.isShooting),
      player.recoilOffset || 0,
      gameTime
    );

    // 3. Hero Energy Shield (e.g. Tank / high-armor heroes)
    if (player.armor > 80) {
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.5;
      ctx.globalAlpha = 0.55 + Math.sin(gameTime * 8) * 0.25;
      ctx.beginPath();
      ctx.arc(0, 0, 36, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();
  }

  private drawEnemy(ctx: CanvasRenderingContext2D, enemy: EnemyInstance, gameTime: number) {
    ctx.save();
    ctx.translate(enemy.x, enemy.y);

    // 1. Soft Dynamic Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, enemy.radius * 0.8, enemy.radius * 1.1, enemy.radius * 0.55, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Hit Flash State
    const isFlashing = enemy.hitFlashTimer > 0;
    ctx.rotate(enemy.angle);

    // 3. High-Fidelity Procedural Enemy Sprite
    ProceduralSpriteRenderer.drawEnemy(ctx, enemy, gameTime, isFlashing);

    ctx.restore();

    // 4. Tactical Health Bar
    if (enemy.hp < enemy.maxHp) {
      const barW = Math.max(32, enemy.radius * 2);
      const barH = 4;
      const hpRatio = Math.max(0, enemy.hp / enemy.maxHp);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(enemy.x - barW / 2, enemy.y - enemy.radius - 10, barW, barH);
      ctx.fillStyle = hpRatio > 0.4 ? '#22c55e' : '#ef4444';
      ctx.fillRect(enemy.x - barW / 2, enemy.y - enemy.radius - 10, barW * hpRatio, barH);
    }
  }

  private drawBoss(ctx: CanvasRenderingContext2D, boss: BossInstance, gameTime: number) {
    ctx.save();
    ctx.translate(boss.x, boss.y);

    // 1. Enormous Radial Boss Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
    ctx.beginPath();
    ctx.ellipse(0, boss.radius * 0.9, boss.radius * 1.3, boss.radius * 0.65, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. High-Threat Attack Telegraph Danger Zone
    if (boss.isTelegraphing) {
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 3.5;
      ctx.setLineDash([10, 8]);
      ctx.beginPath();
      ctx.arc(0, 0, boss.radius * 2.4, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
      ctx.fill();
    }

    const isFlashing = boss.hitFlashTimer > 0;
    ctx.rotate(boss.angle);

    // 3. High-Fidelity Procedural Boss Sprite
    ProceduralSpriteRenderer.drawBoss(ctx, boss, gameTime, isFlashing);

    ctx.restore();
  }

  private drawDrone(
    ctx: CanvasRenderingContext2D,
    drone: { x: number; y: number; angle: number },
    gameTime: number
  ) {
    ctx.save();
    ctx.translate(drone.x, drone.y);

    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.beginPath();
    ctx.ellipse(0, 12, 10, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.rotate(drone.angle);

    // Shell
    ctx.fillStyle = '#f97316';
    ctx.beginPath();
    ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fill();

    // Barrel
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(5, -2, 10, 4);

    // Core
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(0, 0, 4.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawProjectiles(ctx: CanvasRenderingContext2D, projectiles: Projectile[], gameTime: number) {
    for (const p of projectiles) {
      ctx.save();
      ctx.translate(p.x, p.y);

      if (p.isFlamethrower) {
        const flamePulse = 1 + Math.sin(gameTime * 20 + p.id) * 0.2;
        ctx.fillStyle = p.color;
        ctx.globalAlpha = 0.7;
        ctx.beginPath();
        ctx.arc(0, 0, p.radius * 1.6 * flamePulse, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.isExplosive) {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(-3, 0, p.radius * 0.6, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, p.radius * 0.45, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }
  }

  private drawPickups(ctx: CanvasRenderingContext2D, pickups: PickupItem[], gameTime: number) {
    for (const item of pickups) {
      const bob = Math.sin(gameTime * 6 + item.id) * 4;
      ctx.save();
      ctx.translate(item.x, item.y + bob);

      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.beginPath();
      ctx.ellipse(0, 12 - bob, 9, 4.5, 0, 0, Math.PI * 2);
      ctx.fill();

      if (item.type === 'coin') {
        ctx.fillStyle = '#eab308';
        ctx.beginPath();
        ctx.arc(0, 0, item.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(0, 0, item.radius * 0.6, 0, Math.PI * 2);
        ctx.fill();
      } else if (item.type === 'medkit') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-8, -8, 16, 16);
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(-2, -6, 4, 12);
        ctx.fillRect(-6, -2, 12, 4);
      } else if (item.type === 'scrap') {
        ctx.fillStyle = '#94a3b8';
        ctx.beginPath();
        ctx.rect(-7, -7, 14, 14);
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.strokeRect(-7, -7, 14, 14);
      } else {
        ctx.fillStyle = '#15803d';
        ctx.fillRect(-9, -6, 18, 12);
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(-5, -2, 10, 4);
      }

      ctx.restore();
    }
  }

  private drawParticles(ctx: CanvasRenderingContext2D, particles: Particle[]) {
    for (const pt of particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, pt.alpha);
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawFloatingText(ctx: CanvasRenderingContext2D, texts: FloatingText[]) {
    for (const t of texts) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, t.alpha);
      ctx.fillStyle = t.color;
      ctx.font = `bold ${Math.round(14 * t.scale)}px 'JetBrains Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.shadowColor = 'rgba(0,0,0,0.85)';
      ctx.shadowBlur = 4;
      ctx.fillText(t.text, t.x, t.y);
      ctx.restore();
    }
  }
}
