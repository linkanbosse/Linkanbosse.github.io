package com.catwarriors.apocalypse;

import android.content.Context;
import android.content.SharedPreferences;

public class SaveManager {
    private static final String PREF_NAME = "cat_warriors_save";
    private final SharedPreferences prefs;

    public SaveManager(Context context) {
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveProgress(int coins, int scrap, int zone, int mission) {
        prefs.edit()
             .putInt("coins", coins)
             .putInt("scrap", scrap)
             .putInt("highest_zone", zone)
             .putInt("highest_mission", mission)
             .apply();
    }

    public int getCoins() { return prefs.getInt("coins", 150); }
    public int getScrap() { return prefs.getInt("scrap", 25); }
    public int getHighestZone() { return prefs.getInt("highest_zone", 1); }
    public int getHighestMission() { return prefs.getInt("highest_mission", 1); }
}
