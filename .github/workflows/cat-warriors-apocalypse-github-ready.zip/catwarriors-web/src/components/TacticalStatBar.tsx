import React from 'react';
import { WeaponCombatStats } from '../types/game';
import { Zap, Activity, RotateCcw } from 'lucide-react';

export interface TacticalStatBarProps {
  label: string;
  value: number;
  unit: string;
  currentPct: number;
  comparedPct?: number;
  icon: 'damage' | 'fireRate' | 'reloadSpeed';
  diffText?: string;
  diffType?: 'positive' | 'negative' | 'neutral';
  colorGradient: string;
  showSegments?: boolean;
}

// Fixed benchmark constants for weapon metrics
export const WEAPON_METRIC_BENCHMARKS = {
  damage: 250,      // Max damage ceiling (Explosives reach ~240)
  fireRate: 20.0,   // Max shots per second (Flamethrower is 20.0)
  reloadSpeed: 3.5, // Max reload seconds (LMG is 3.2s)
  dps: 1100,        // Max sustained DPS (Obliterator is ~1050)
};

export const TacticalStatBar: React.FC<TacticalStatBarProps> = ({
  label,
  value,
  unit,
  currentPct,
  comparedPct,
  icon,
  diffText,
  diffType = 'neutral',
  colorGradient,
  showSegments = true,
}) => {
  const renderIcon = () => {
    switch (icon) {
      case 'damage':
        return <Zap className="w-3.5 h-3.5 text-amber-400" />;
      case 'fireRate':
        return <Activity className="w-3.5 h-3.5 text-cyan-400" />;
      case 'reloadSpeed':
        return <RotateCcw className="w-3.5 h-3.5 text-blue-400" />;
    }
  };

  const clampedCurrent = Math.max(0, Math.min(100, currentPct));
  const hasCompared = comparedPct !== undefined;
  const clampedCompared = hasCompared ? Math.max(0, Math.min(100, comparedPct!)) : 0;

  return (
    <div className="space-y-1 font-tech">
      <div className="flex justify-between items-center text-xs">
        <span className="text-slate-400 flex items-center gap-1.5 font-medium">
          {renderIcon()}
          <span>{label}</span>
        </span>
        <div className="flex items-center gap-1.5 font-bold">
          <span className="text-slate-100 font-tech">
            {value} <span className="text-[10px] text-slate-500 font-normal">{unit}</span>
          </span>
          {diffText && (
            <span
              className={`text-[10px] font-semibold ${
                diffType === 'positive'
                  ? 'text-emerald-400'
                  : diffType === 'negative'
                  ? 'text-rose-400'
                  : 'text-slate-400'
              }`}
            >
              ({diffText})
            </span>
          )}
        </div>
      </div>

      {/* Stylized Segmented Progress Track */}
      <div className="relative w-full h-2 bg-[#050914] rounded overflow-hidden border border-slate-800/80 shadow-inner">
        {/* Background calibration hash marks (10 tactical segments) */}
        {showSegments && (
          <div className="absolute inset-0 grid grid-cols-10 pointer-events-none z-10 opacity-30">
            {Array.from({ length: 10 }).map((_, i) => (
              <div
                key={i}
                className={`h-full border-r border-slate-700/60 ${i === 9 ? 'border-r-0' : ''}`}
              />
            ))}
          </div>
        )}

        {/* Compared Weapon Ghost Bar (if active comparison mode) */}
        {hasCompared && (
          <div
            className="absolute top-0 bottom-0 bg-slate-600/40 transition-all duration-300"
            style={{ width: `${clampedCompared}%` }}
          />
        )}

        {/* Primary Metric Fill Bar */}
        <div
          className={`h-full transition-all duration-300 shadow-sm ${colorGradient}`}
          style={{ width: `${clampedCurrent}%` }}
        />
      </div>
    </div>
  );
};

export interface WeaponTacticalMetricsProps {
  stats: WeaponCombatStats;
  nextStats?: WeaponCombatStats;
  diffs?: {
    damage?: number;
    fireRate?: number;
    reloadSpeed?: number;
  };
  isUnlocked?: boolean;
  showDividers?: boolean;
}

export const WeaponTacticalMetrics: React.FC<WeaponTacticalMetricsProps> = ({
  stats,
  nextStats,
  diffs,
  isUnlocked = true,
  showDividers = true,
}) => {
  const damageDiff = diffs?.damage !== undefined ? diffs.damage : nextStats ? nextStats.damage - stats.damage : 0;
  const fireRateDiff = diffs?.fireRate !== undefined ? diffs.fireRate : nextStats ? parseFloat((nextStats.fireRate - stats.fireRate).toFixed(2)) : 0;
  const reloadDiff = diffs?.reloadSpeed !== undefined ? diffs.reloadSpeed : nextStats ? parseFloat((stats.reloadSpeed - nextStats.reloadSpeed).toFixed(2)) : 0;

  // Percentage calculations
  const damagePct = (stats.damage / WEAPON_METRIC_BENCHMARKS.damage) * 100;
  const fireRatePct = (stats.fireRate / WEAPON_METRIC_BENCHMARKS.fireRate) * 100;
  // Reload agility: lower seconds = higher agility bar
  const reloadAgilityPct = ((WEAPON_METRIC_BENCHMARKS.reloadSpeed - stats.reloadSpeed) / (WEAPON_METRIC_BENCHMARKS.reloadSpeed - 0.4)) * 100;

  return (
    <div className="space-y-2.5 bg-[#050914] p-3.5 rounded-lg border border-slate-800 font-tech">
      {/* 1. DAMAGE */}
      <TacticalStatBar
        label="Skada (Damage)"
        value={stats.damage}
        unit="dmg"
        currentPct={damagePct}
        icon="damage"
        diffText={isUnlocked && nextStats ? `+${damageDiff}` : undefined}
        diffType={damageDiff > 0 ? 'positive' : 'neutral'}
        colorGradient="bg-gradient-to-r from-amber-500 to-orange-400"
      />

      {/* 2. RATE OF FIRE */}
      <TacticalStatBar
        label="Eldtakt (Fire Rate)"
        value={stats.fireRate}
        unit="skott/s"
        currentPct={fireRatePct}
        icon="fireRate"
        diffText={isUnlocked && nextStats ? `+${fireRateDiff}/s` : undefined}
        diffType={fireRateDiff > 0 ? 'positive' : 'neutral'}
        colorGradient="bg-gradient-to-r from-cyan-500 to-blue-400"
      />

      {/* 3. RELOAD SPEED */}
      <TacticalStatBar
        label="Omladdning (Reload)"
        value={stats.reloadSpeed}
        unit="sek"
        currentPct={reloadAgilityPct}
        icon="reloadSpeed"
        diffText={isUnlocked && nextStats ? `-${reloadDiff}s` : undefined}
        diffType={reloadDiff > 0 ? 'positive' : 'neutral'}
        colorGradient="bg-gradient-to-r from-blue-500 to-indigo-400"
      />

      {/* Tactical DPS & Capacity Footer */}
      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-1.5 text-slate-400">
          <span>Mag:</span>
          <span className="text-slate-200 font-bold">{stats.magazineSize}</span>
          <span className="text-slate-700">·</span>
          <span>Räckvidd:</span>
          <span className="text-slate-200 font-bold">{stats.range}px</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-slate-500 uppercase text-[10px]">Effektiv DPS:</span>
          <span className="text-amber-400 font-bold">{stats.dps}</span>
        </div>
      </div>
    </div>
  );
};
