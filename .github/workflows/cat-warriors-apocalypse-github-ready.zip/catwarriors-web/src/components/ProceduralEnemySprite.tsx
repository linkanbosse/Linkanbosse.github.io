import React from 'react';
import { EnemyType } from '../types/game';

interface ProceduralEnemySpriteProps {
  type: EnemyType | string;
  size?: number | string;
  className?: string;
  isBoss?: boolean;
}

/**
 * ProceduralEnemySprite
 * Renders stylized procedural SVG vector sprites for apocalyptic enemies and bosses.
 */
export const ProceduralEnemySprite: React.FC<ProceduralEnemySpriteProps> = ({
  type,
  size = 48,
  className = '',
  isBoss = false,
}) => {
  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 80 80"
        className="w-full h-full overflow-visible"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Soft shadow */}
        <ellipse cx="40" cy="72" rx="24" ry="5" fill="rgba(0,0,0,0.45)" />

        {/* Boss Crown / Threat Glow */}
        {isBoss && (
          <circle cx="40" cy="40" r="36" fill="rgba(239,68,68,0.2)" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="4 2" />
        )}

        {/* Render Enemy Variant */}
        {type === 'mutant_rat' && (
          <g>
            {/* Body */}
            <ellipse cx="40" cy="42" rx="22" ry="16" fill="#52525b" />
            {/* Toxic Spine Quills */}
            <path d="M 24 32 L 28 20 L 34 30 Z" fill="#22c55e" />
            <path d="M 34 30 L 40 18 L 46 28 Z" fill="#22c55e" />
            <path d="M 46 28 L 52 22 L 56 32 Z" fill="#22c55e" />
            {/* Snout with Fangs */}
            <path d="M 50 36 L 68 42 L 50 48 Z" fill="#71717a" />
            <rect x="62" y="41" width="3" height="3" fill="#ffffff" />
            {/* Red Rabies Eyes */}
            <circle cx="52" cy="37" r="3" fill="#ef4444" />
            <circle cx="53" cy="36" r="1" fill="#ffffff" />
            {/* Writhing Tail */}
            <path d="M 18 42 C 8 40 6 56 12 60" stroke="#fda4af" strokeWidth="2.5" strokeLinecap="round" />
          </g>
        )}

        {type === 'zombie_cat' && (
          <g>
            {/* Necrotic Head */}
            <circle cx="40" cy="40" r="20" fill="#3f6212" />
            {/* Exposed Cyber Bone */}
            <circle cx="48" cy="36" r="7" fill="#94a3b8" />
            {/* Torn Ears */}
            <polygon points="26,28 20,12 36,22" fill="#365314" />
            <polygon points="54,28 58,16 46,24" fill="#365314" />
            {/* Glowing Toxic Eyes */}
            <circle cx="34" cy="38" r="3.5" fill="#facc15" />
            <circle cx="48" cy="38" r="3.5" fill="#facc15" />
            {/* Fissures */}
            <path d="M 32 46 L 40 50 L 48 45" stroke="#84cc16" strokeWidth="2" fill="none" />
          </g>
        )}

        {type === 'armored_hound' && (
          <g>
            {/* Heavy Hound Head */}
            <ellipse cx="40" cy="40" rx="20" ry="16" fill="#292524" />
            {/* Spiked Titanium Collar */}
            <rect x="22" y="32" width="6" height="20" fill="#78716c" rx="1" />
            <circle cx="25" cy="34" r="2.5" fill="#f97316" />
            <circle cx="25" cy="48" r="2.5" fill="#f97316" />
            {/* Hydraulic Jaw with Metal Fangs */}
            <rect x="44" y="36" width="16" height="12" fill="#1c1917" rx="2" />
            <polygon points="46,48 50,42 54,48" fill="#ffffff" />
            {/* Red Multi-Optic Visor */}
            <circle cx="46" cy="32" r="2.5" fill="#ef4444" />
            <circle cx="52" cy="32" r="2.5" fill="#ef4444" />
          </g>
        )}

        {type === 'exploder' && (
          <g>
            {/* Plasma Sphere */}
            <circle cx="40" cy="40" r="20" fill="#dc2626" />
            <ellipse cx="40" cy="40" rx="24" ry="10" stroke="#fde047" strokeWidth="2.5" fill="none" transform="rotate(-20 40 40)" />
            <circle cx="40" cy="40" r="10" fill="#fbbf24" />
            <circle cx="40" cy="40" r="5" fill="#ffffff" />
            {/* Hazard Triangles */}
            <polygon points="40,24 43,30 37,30" fill="#000000" />
            <polygon points="40,56 43,50 37,50" fill="#000000" />
          </g>
        )}

        {type === 'acid_spitter' && (
          <g>
            {/* Toxic Base */}
            <circle cx="40" cy="40" r="20" fill="#059669" />
            {/* Glass Venom Sac */}
            <ellipse cx="32" cy="40" rx="12" ry="14" fill="#a3e635" stroke="#65a30d" strokeWidth="2" opacity="0.9" />
            {/* Twin Launcher Nozzles */}
            <rect x="46" y="32" width="14" height="6" fill="#064e3b" rx="1" />
            <rect x="46" y="42" width="14" height="6" fill="#064e3b" rx="1" />
            <circle cx="56" cy="35" r="2" fill="#22c55e" />
            <circle cx="56" cy="45" r="2" fill="#22c55e" />
          </g>
        )}

        {type === 'flying_drone' && (
          <g>
            {/* Chassis */}
            <rect x="28" y="32" width="24" height="16" fill="#0284c7" rx="4" />
            {/* Rotors */}
            <circle cx="22" cy="24" r="8" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 2" fill="none" />
            <circle cx="58" cy="24" r="8" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 2" fill="none" />
            <circle cx="22" cy="56" r="8" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 2" fill="none" />
            <circle cx="58" cy="56" r="8" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 2" fill="none" />
            {/* Scanner Eye */}
            <circle cx="40" cy="40" r="4.5" fill="#ef4444" />
            <circle cx="40" cy="40" r="2" fill="#ffffff" />
          </g>
        )}

        {type === 'heavy_mech' && (
          <g>
            {/* Titan Armor Box */}
            <rect x="24" y="24" width="32" height="32" fill="#0f172a" stroke="#f59e0b" strokeWidth="2" rx="3" />
            {/* Cockpit Window */}
            <rect x="30" y="30" width="20" height="10" fill="#334155" />
            <rect x="36" y="33" width="8" height="4" fill="#ef4444" />
            {/* Twin Heavy Barrels */}
            <rect x="52" y="26" width="16" height="7" fill="#475569" />
            <rect x="52" y="46" width="16" height="7" fill="#475569" />
            {/* Hazard Stripes */}
            <line x1="28" y1="52" x2="34" y2="46" stroke="#f59e0b" strokeWidth="2" />
            <line x1="36" y1="52" x2="42" y2="46" stroke="#f59e0b" strokeWidth="2" />
          </g>
        )}

        {type === 'frost_crawler' && (
          <g>
            {/* Glacial Shell */}
            <polygon points="40,20 54,34 50,56 30,56 26,34" fill="#0284c7" stroke="#bae6fd" strokeWidth="1.5" />
            {/* Diamond Crystal Core */}
            <polygon points="40,28 46,38 40,48 34,38" fill="#e0f2fe" />
            {/* Cyan Eyes */}
            <circle cx="36" cy="34" r="2" fill="#38bdf8" />
            <circle cx="44" cy="34" r="2" fill="#38bdf8" />
          </g>
        )}

        {type === 'desert_scorpion' && (
          <g>
            {/* Scorpion Body */}
            <ellipse cx="40" cy="42" rx="16" ry="12" fill="#78350f" />
            {/* Pincers */}
            <circle cx="56" cy="32" r="6" fill="#d97706" />
            <circle cx="56" cy="52" r="6" fill="#d97706" />
            {/* Arched Sting Tail */}
            <path d="M 24 42 C 14 36 12 18 24 16" stroke="#b45309" strokeWidth="3" fill="none" strokeLinecap="round" />
            <circle cx="24" cy="16" r="3" fill="#22c55e" />
          </g>
        )}

        {/* Fallback Boss / Elite icon */}
        {!['mutant_rat', 'zombie_cat', 'armored_hound', 'exploder', 'acid_spitter', 'flying_drone', 'heavy_mech', 'frost_crawler', 'desert_scorpion'].includes(type) && (
          <g>
            <circle cx="40" cy="40" r="22" fill="#581c87" stroke="#c084fc" strokeWidth="2" />
            <polygon points="40,24 52,48 28,48" fill="#a855f7" />
            <circle cx="40" cy="40" r="5" fill="#facc15" />
          </g>
        )}
      </svg>
    </div>
  );
};
