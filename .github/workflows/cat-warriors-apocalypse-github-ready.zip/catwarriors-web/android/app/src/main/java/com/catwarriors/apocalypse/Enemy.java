package com.catwarriors.apocalypse;

public class Enemy {
    public String type;
    public float x;
    public float y;
    public float hp;
    public float maxHp;
    public float speed;
    public float radius;
    public float damage;
    public boolean isRanged;
    public float attackTimer;
    public float attackCooldown;
    public float angle;
    public float hitFlashTimer = 0;
    public boolean active = true;

    public Enemy(String type, float x, float y, float hp, float speed,
                 float radius, float damage, boolean isRanged, float attackCooldown) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.hp = hp;
        this.maxHp = hp;
        this.speed = speed;
        this.radius = radius;
        this.damage = damage;
        this.isRanged = isRanged;
        this.attackCooldown = attackCooldown;
        this.attackTimer = (float) (Math.random() * attackCooldown);
    }

    public void takeDamage(float dmg) {
        hp -= dmg;
        hitFlashTimer = 0.08f;
        if (hp <= 0) {
            active = false;
        }
    }
}
