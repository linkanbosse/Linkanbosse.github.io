import React, { useState } from 'react';
import { Weapon, WeaponCombatStats, PlayerStats } from '../types/game';
import { TacticalStatBar, WEAPON_METRIC_BENCHMARKS } from './TacticalStatBar';
import { Crosshair, RotateCcw, Zap, Activity, Flame, ChevronDown, ChevronUp, ShieldAlert } from 'lucide-react';

interface ActiveWeaponStatsHUDProps {
  weapon: Weapon;
  effectiveStats: WeaponCombatStats;
  playerStats: PlayerStats | null;
  forceCompact?: boolean;
}

export const ActiveWeaponStatsHUD: React.FC<ActiveWeaponStatsHUDProps> = ({
  weapon,
  effectiveStats,
  playerStats,
  forceCompact = false,
}) => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(true);

  // If forceCompact is true, remain collapsed
  const collapsed = isCollapsed || forceCompact;

  const ammo = playerStats ? playerStats.ammo : effectiveStats.magazineSize;
  const maxAmmo = playerStats ? playerStats.maxAmmo : effectiveStats.magazineSize;
  const isReloading = playerStats?.isReloading ?? false;

  // Percentage calculations
  const damagePct = (effectiveStats.damage / WEAPON_METRIC_BENCHMARKS.damage) * 100;
  const fireRatePct = (effectiveStats.fireRate / WEAPON_METRIC_BENCHMARKS.fireRate) * 100;
  const reloadAgilityPct =
    ((WEAPON_METRIC_BENCHMARKS.reloadSpeed - effectiveStats.reloadSpeed) /
      (WEAPON_METRIC_BENCHMARKS.reloadSpeed - 0.4)) *
    100;

  // Rarity color mappings
  const getTierBadge = (tier: number) => {
    switch (tier) {
      case 1:
        return { name: 'T1', border: 'border-slate-600', text: 'text-slate-300', bg: 'bg-slate-800/80' };
      case 2:
        return { name: 'T2', border: 'border-emerald-600', text: 'text-emerald-300', bg: 'bg-emerald-950/80' };
      case 3:
        return { name: 'T3', border: 'border-blue-600', text: 'text-blue-300', bg: 'bg-blue-950/80' };
      case 4:
        return { name: 'T4', border: 'border-purple-600', text: 'text-purple-300', bg: 'bg-purple-950/80' };
      case 5:
        return { name: 'T5', border: 'border-amber-600', text: 'text-amber-300', bg: 'bg-amber-950/80' };
      case 6:
        return { name: 'T6', border: 'border-rose-600', text: 'text-rose-300', bg: 'bg-rose-950/80' };
      default:
        return { name: 'T7', border: 'border-amber-400', text: 'text-amber-200', bg: 'bg-amber-900/80' };
    }
  };

  const tierBadge = getTierBadge(weapon.tier);

  // Dynamic Bullet Magazine visualization (up to 20 pips)
  const maxVisualPips = Math.min(20, maxAmmo);
  const ammoRatio = maxAmmo > 0 ? ammo / maxAmmo : 0;
  const activePips = Math.round(ammoRatio * maxVisualPips);

  return (
    <div
      className={`bg-[#090e1c]/75 backdrop-blur-md border border-amber-500/30 rounded-xl shadow-2xl font-tech pointer-events-auto transition-all duration-200 select-none ${
        collapsed ? 'p-2 w-auto max-w-[210px] tactical-border-amber' : 'p-3 w-64 sm:w-72 tactical-border'
      }`}
    >
      {/* Compact / Sleek Combat Pill */}
      {collapsed ? (
        <div className="flex items-center gap-2">
          <div className="text-base shrink-0">{weapon.icon || '🔫'}</div>
          <div className="flex flex-col flex-1 min-w-0">
            <div className="flex items-center justify-between gap-1 text-[11px] leading-tight">
              <span className="font-bold text-slate-200 truncate font-display">{weapon.name}</span>
              <span className={`px-1 py-0.2 rounded text-[8px] font-bold ${tierBadge.bg} ${tierBadge.text} border ${tierBadge.border}`}>
                {tierBadge.name}
              </span>
            </div>
            {/* Ammo progress mini bar & numbers */}
            <div className="flex items-center justify-between gap-1.5 mt-0.5">
              <div className="flex-1 h-1.5 bg-[#050914] rounded overflow-hidden border border-slate-800">
                <div
                  className={`h-full transition-all duration-75 ${
                    isReloading
                      ? 'bg-amber-400 animate-pulse w-full'
                      : ammoRatio < 0.25
                      ? 'bg-rose-500'
                      : 'bg-gradient-to-r from-amber-500 to-yellow-400'
                  }`}
                  style={{ width: isReloading ? '100%' : `${ammoRatio * 100}%` }}
                />
              </div>
              <span className="text-[10px] font-mono font-bold tabular-nums">
                {isReloading ? (
                  <span className="text-amber-400 text-[9px] animate-pulse">Laddar...</span>
                ) : (
                  <span>
                    <span className="text-amber-400">{ammo}</span>
                    <span className="text-slate-500">/{maxAmmo}</span>
                  </span>
                )}
              </span>
            </div>
          </div>
          <button
            onClick={() => setIsCollapsed(false)}
            className="p-1 text-slate-400 hover:text-amber-300 rounded hover:bg-slate-800/60 transition-colors cursor-pointer shrink-0"
            title="Expandera vapenstatus"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        /* Full Telemetry Expanded View */
        <div>
          <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-lg">{weapon.icon || '🔫'}</span>
              <div>
                <div className="text-xs font-bold text-slate-100 font-display flex items-center gap-1.5">
                  <span>{weapon.name}</span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px]">
                  <span className={`px-1 rounded text-[9px] font-bold ${tierBadge.bg} ${tierBadge.text} border ${tierBadge.border}`}>
                    {tierBadge.name}
                  </span>
                  <span className="text-slate-500">·</span>
                  <span className="text-amber-400 font-bold">{effectiveStats.dps} DPS</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsCollapsed(true)}
              className="p-1 hover:text-amber-300 text-slate-400 rounded hover:bg-slate-800 transition-colors cursor-pointer"
              title="Minimera till stridspill"
            >
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2 pt-2 text-xs">
            {/* Tactical Bullet Ammo Gauge */}
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-slate-400 flex items-center gap-1">
                  <RotateCcw className={`w-3 h-3 ${isReloading ? 'animate-spin text-amber-400' : 'text-slate-500'}`} />
                  <span>MAGASIN</span>
                </span>
                <span className="font-mono font-bold text-slate-100">
                  {isReloading ? (
                    <span className="text-amber-400 animate-pulse">LADDAR OM...</span>
                  ) : (
                    <span>
                      <span className="text-amber-400">{ammo}</span>
                      <span className="text-slate-500">/{maxAmmo}</span>
                    </span>
                  )}
                </span>
              </div>

              {/* Bullet Segments */}
              <div className="flex gap-0.5 h-1.5 bg-[#050914] p-0.5 rounded border border-slate-800 overflow-hidden">
                {Array.from({ length: maxVisualPips }).map((_, i) => (
                  <div
                    key={i}
                    className={`flex-1 rounded-[1px] transition-colors duration-75 ${
                      isReloading
                        ? 'bg-amber-500/40 animate-pulse'
                        : i < activePips
                        ? i < 4
                          ? 'bg-rose-500 shadow-sm shadow-rose-500/50'
                          : 'bg-amber-400'
                        : 'bg-slate-800/60'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Calibrated Tactical Progress Bars */}
            <div className="space-y-1.5 bg-[#050914]/80 p-2 rounded-lg border border-slate-800/80">
              <TacticalStatBar
                label="Skada"
                value={effectiveStats.damage}
                unit="dmg"
                currentPct={damagePct}
                icon="damage"
                colorGradient="bg-gradient-to-r from-amber-500 to-orange-400"
                showSegments={false}
              />
              <TacticalStatBar
                label="Eldtakt"
                value={effectiveStats.fireRate}
                unit="skott/s"
                currentPct={fireRatePct}
                icon="fireRate"
                colorGradient="bg-gradient-to-r from-cyan-500 to-blue-400"
                showSegments={false}
              />
              <TacticalStatBar
                label="Omladdning"
                value={effectiveStats.reloadSpeed}
                unit="s"
                currentPct={reloadAgilityPct}
                icon="reloadSpeed"
                colorGradient="bg-gradient-to-r from-blue-500 to-indigo-400"
                showSegments={false}
              />
            </div>

            {/* Weapon Combat Perks Footer */}
            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5 font-mono">
              <span>Räckvidd: <span className="text-slate-200 font-bold">{effectiveStats.range}px</span></span>
              {weapon.penetration > 1 && (
                <span className="text-cyan-400 font-bold">Pen: x{weapon.penetration}</span>
              )}
              {weapon.isExplosive && (
                <span className="text-rose-400 font-bold flex items-center gap-0.5">
                  <Flame className="w-3 h-3 inline" /> Sprängämne
                </span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
