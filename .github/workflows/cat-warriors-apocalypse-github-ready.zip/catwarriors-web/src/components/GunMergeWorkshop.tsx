import React, { useState } from 'react';
import { PlayerProfile, MergeSlot, Weapon } from '../types/game';
import { WEAPONS, CAT_WARRIORS } from '../game/constants';
import { sound } from '../game/audio';
import { Sparkles, ArrowRight, Zap, RefreshCw, Box, Trash2, CheckCircle2, ChevronRight, ShieldCheck } from 'lucide-react';
import { WeaponTacticalMetrics } from './TacticalStatBar';
import { ProceduralCatSprite } from './ProceduralCatSprite';

interface GunMergeWorkshopProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => void;
  onEquipWeapon: (weaponId: string) => void;
}

export const GunMergeWorkshop: React.FC<GunMergeWorkshopProps> = ({
  profile,
  onUpdateProfile,
  onEquipWeapon,
}) => {
  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number | null>(null);
  const [recentMergedWeapon, setRecentMergedWeapon] = useState<Weapon | null>(null);
  const [mergeCelebration, setMergeCelebration] = useState<string | null>(null);

  const activeCat = CAT_WARRIORS.find((c) => c.id === profile.selectedCat) || CAT_WARRIORS[0];

  const mergeSlots: MergeSlot[] = profile.mergeSlots || [
    { slotId: 0, weaponId: 'pistol', tier: 1 },
    { slotId: 1, weaponId: 'pistol', tier: 1 },
    { slotId: 2, weaponId: 'prowler_pistol', tier: 1 },
    { slotId: 3, weaponId: null, tier: 0 },
    { slotId: 4, weaponId: null, tier: 0 },
    { slotId: 5, weaponId: null, tier: 0 },
    { slotId: 6, weaponId: null, tier: 0 },
    { slotId: 7, weaponId: null, tier: 0 },
    { slotId: 8, weaponId: null, tier: 0 },
    { slotId: 9, weaponId: null, tier: 0 },
    { slotId: 10, weaponId: null, tier: 0 },
    { slotId: 11, weaponId: null, tier: 0 },
  ];

  // Buy new Tier 1 Gun Crate
  const boxCost = 50 + (profile.mergeSlots?.filter((s) => s.weaponId !== null).length || 0) * 10;
  const canBuyBox = profile.coins >= boxCost;

  const handleBuyBox = () => {
    const emptyIndex = mergeSlots.findIndex((s) => s.weaponId === null);
    if (emptyIndex === -1) {
      setMergeCelebration('⚠️ Vapengallret är fullt! Slå samman eller sälj vapen först.');
      setTimeout(() => setMergeCelebration(null), 3000);
      return;
    }
    if (!canBuyBox) return;

    sound.playPickup();
    const tier1Weapons = WEAPONS.filter((w) => w.tier === 1);
    const randomT1 = tier1Weapons[Math.floor(Math.random() * tier1Weapons.length)];

    const updatedSlots = [...mergeSlots];
    updatedSlots[emptyIndex] = {
      slotId: emptyIndex,
      weaponId: randomT1.id,
      tier: 1,
    };

    onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins - boxCost,
      mergeSlots: updatedSlots,
    }));
  };

  // Click on slot to merge or select
  const handleSlotClick = (index: number) => {
    const slot = mergeSlots[index];
    if (selectedSlotIndex === null) {
      if (slot.weaponId) {
        sound.playClick();
        setSelectedSlotIndex(index);
      }
      return;
    }

    if (selectedSlotIndex === index) {
      setSelectedSlotIndex(null);
      return;
    }

    const sourceSlot = mergeSlots[selectedSlotIndex];
    const targetSlot = mergeSlots[index];

    // Check if both have weapons of the same tier to merge!
    if (sourceSlot.weaponId && targetSlot.weaponId && sourceSlot.tier === targetSlot.tier) {
      const currentTier = sourceSlot.tier;
      const nextTier = currentTier + 1;

      // Find higher-tier weapons
      const nextTierWeapons = WEAPONS.filter((w) => w.tier === nextTier);
      const forgedWeapon =
        nextTierWeapons.length > 0
          ? nextTierWeapons[Math.floor(Math.random() * nextTierWeapons.length)]
          : WEAPONS.find((w) => w.tier >= currentTier) || WEAPONS[WEAPONS.length - 1];

      sound.playMerge();
      setRecentMergedWeapon(forgedWeapon);
      setMergeCelebration(`FÖRENING LYCKADES! TIER ${nextTier} SKAPAD: ${forgedWeapon.name}`);

      const updatedSlots = [...mergeSlots];
      updatedSlots[selectedSlotIndex] = { slotId: selectedSlotIndex, weaponId: null, tier: 0 };
      updatedSlots[index] = {
        slotId: index,
        weaponId: forgedWeapon.id,
        tier: nextTier,
      };

      // Also ensure weapon is added to player's unlocked arsenal
      const unlocked = profile.unlockedWeapons.includes(forgedWeapon.id)
        ? profile.unlockedWeapons
        : [...profile.unlockedWeapons, forgedWeapon.id];

      onUpdateProfile((prev) => ({
        ...prev,
        unlockedWeapons: unlocked,
        mergeSlots: updatedSlots,
      }));

      setSelectedSlotIndex(null);
      setTimeout(() => setMergeCelebration(null), 4000);
      return;
    }

    // Move weapon to empty slot
    if (sourceSlot.weaponId && targetSlot.weaponId === null) {
      sound.playClick();
      const updatedSlots = [...mergeSlots];
      updatedSlots[index] = { ...sourceSlot, slotId: index };
      updatedSlots[selectedSlotIndex] = { slotId: selectedSlotIndex, weaponId: null, tier: 0 };
      onUpdateProfile((prev) => ({
        ...prev,
        mergeSlots: updatedSlots,
      }));
      setSelectedSlotIndex(null);
      return;
    }

    // Switch selection
    setSelectedSlotIndex(index);
  };

  // Auto-Merge all matching pairs in one click!
  const handleAutoMerge = () => {
    let mergedAny = false;
    const updated = [...mergeSlots];

    for (let i = 0; i < updated.length; i++) {
      if (!updated[i].weaponId) continue;
      for (let j = i + 1; j < updated.length; j++) {
        if (!updated[j].weaponId) continue;
        if (updated[i].tier === updated[j].tier) {
          const nextTier = updated[i].tier + 1;
          const nextTierWeapons = WEAPONS.filter((w) => w.tier === nextTier);
          const forged =
            nextTierWeapons.length > 0
              ? nextTierWeapons[Math.floor(Math.random() * nextTierWeapons.length)]
              : WEAPONS[WEAPONS.length - 1];

          updated[i] = { slotId: i, weaponId: forged.id, tier: nextTier };
          updated[j] = { slotId: j, weaponId: null, tier: 0 };
          mergedAny = true;
          setRecentMergedWeapon(forged);
          break;
        }
      }
    }

    if (mergedAny) {
      sound.playMerge();
      setMergeCelebration('AUTO-FÖRENING SLUTFÖRD! NYA TIER-VAPEN SMIDDA!');
      setTimeout(() => setMergeCelebration(null), 3000);
      onUpdateProfile((prev) => ({
        ...prev,
        mergeSlots: updated,
      }));
    } else {
      sound.playClick();
    }
  };

  // Discard / sell selected weapon for scrap
  const handleSellSelected = () => {
    if (selectedSlotIndex === null) return;
    const slot = mergeSlots[selectedSlotIndex];
    if (!slot.weaponId) return;

    sound.playPickup();
    const scrapRefund = slot.tier * 8;
    const updated = [...mergeSlots];
    updated[selectedSlotIndex] = { slotId: selectedSlotIndex, weaponId: null, tier: 0 };

    onUpdateProfile((prev) => ({
      ...prev,
      scrap: prev.scrap + scrapRefund,
      mergeSlots: updated,
    }));
    setSelectedSlotIndex(null);
  };

  const selectedSlot = selectedSlotIndex !== null ? mergeSlots[selectedSlotIndex] : null;
  const selectedWeapon = selectedSlot?.weaponId ? WEAPONS.find((w) => w.id === selectedSlot.weaponId) : null;
  const currentEquippedWeapon = WEAPONS.find((w) => w.id === profile.selectedWeapon) || WEAPONS[0];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#090e1c] border border-amber-500/30 tactical-border">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-tech text-amber-500 font-bold uppercase tracking-widest">
              VAPEN-SMEDJAN // VAPEN-MERGE SYSTEM
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-tech font-black bg-rose-500/20 text-rose-400 border border-rose-500/30">
              MEOW-DICTIVE
            </span>
          </div>
          <h2 className="text-2xl font-black text-slate-100 font-display">
            Förena Vapen för Ännu Större Eldkraft
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl font-tech leading-relaxed">
            Slå samman två vapen av samma Tier för att smida nästa nivå. Ju större bössa kattkrigaren håller,
            desto sötare blir den och desto mer förödande blir skadan!
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 font-tech">
          <button
            onClick={handleBuyBox}
            disabled={!canBuyBox}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-lg cursor-pointer ${
              canBuyBox
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/20'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Box className="w-4 h-4" />
            <span>Köp Vapenlåda ({boxCost} 🪙)</span>
          </button>

          <button
            onClick={handleAutoMerge}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#0f172a] hover:bg-slate-800 border border-cyan-500/40 text-cyan-400 font-bold rounded-lg text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
            title="Slå samman alla matchande par automatiskt"
          >
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Auto-Förena</span>
          </button>
        </div>
      </div>

      {/* Merge Success Alert */}
      {mergeCelebration && (
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/80 to-[#050914] border border-emerald-500/60 flex items-center justify-between gap-4 text-emerald-400 font-tech text-xs animate-bounce shadow-xl">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-bold tracking-wide">{mergeCelebration}</span>
          </div>
          {recentMergedWeapon && (
            <button
              onClick={() => onEquipWeapon(recentMergedWeapon.id)}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded text-xs uppercase tracking-wider cursor-pointer"
            >
              Utrusta Nu
            </button>
          )}
        </div>
      )}

      {/* Main Workbench Grid + Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* The 12-Slot Merge Grid */}
        <div className="lg:col-span-2 bg-[#070c18] border border-slate-800 rounded-xl p-5 tactical-border-cyan shadow-xl">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2.5">
            <div className="text-xs font-tech font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-cyan-400" />
              <span>Smedjans Föreningsgaller (12 Platser)</span>
            </div>
            <div className="text-[11px] font-tech text-slate-400">
              Klicka två vapen av samma Tier för att slå ihop!
            </div>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 gap-3.5">
            {mergeSlots.map((slot, idx) => {
              const weapon = slot.weaponId ? WEAPONS.find((w) => w.id === slot.weaponId) : null;
              const isSelected = selectedSlotIndex === idx;

              // Border color based on Tier
              const tierColors = [
                'border-slate-800 text-slate-600',
                'border-amber-500/40 bg-amber-950/10 text-amber-400',
                'border-blue-500/50 bg-blue-950/20 text-blue-400',
                'border-purple-500/50 bg-purple-950/20 text-purple-400',
                'border-rose-500/60 bg-rose-950/20 text-rose-400',
                'border-yellow-400/70 bg-yellow-950/30 text-yellow-300',
                'border-cyan-400/80 bg-cyan-950/30 text-cyan-300',
                'border-fuchsia-400 bg-fuchsia-950/40 text-fuchsia-300',
              ];

              return (
                <div
                  key={idx}
                  onClick={() => handleSlotClick(idx)}
                  className={`h-28 rounded-xl border-2 p-2.5 flex flex-col justify-between items-center transition-all cursor-pointer relative select-none ${
                    isSelected
                      ? 'border-amber-400 bg-amber-500/20 shadow-xl shadow-amber-500/30 scale-105'
                      : slot.weaponId
                      ? `${tierColors[slot.tier]} hover:border-slate-600 hover:scale-102`
                      : 'border-dashed border-slate-800/80 bg-[#050914] hover:border-slate-700'
                  }`}
                >
                  {weapon ? (
                    <>
                      <div className="w-full flex justify-between items-center text-[10px] font-tech font-bold">
                        <span className="px-1.5 py-0.5 rounded bg-black/60 border border-white/10 uppercase">
                          T{slot.tier}
                        </span>
                        <span className="text-[11px]">{weapon.icon || '🔫'}</span>
                      </div>

                      <div className="text-center my-auto">
                        <div className="text-2xl mb-1">{weapon.icon || '🔫'}</div>
                        <div className="text-[11px] font-bold text-slate-100 font-display line-clamp-1">
                          {weapon.name}
                        </div>
                      </div>

                      <div className="text-[10px] font-tech text-slate-400 font-semibold tabular-nums">
                        {weapon.dps} DPS
                      </div>
                    </>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-slate-700 font-tech text-xs">
                      <Box className="w-6 h-6 mb-1 text-slate-800" />
                      <span className="text-[10px]">TOM PLATS</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Sell / Discard Selected Weapon */}
          {selectedSlot && selectedWeapon && (
            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between font-tech text-xs">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Markerat:</span>
                <span className="text-amber-400 font-bold">{selectedWeapon.name} (Tier {selectedSlot.tier})</span>
              </div>
              <button
                onClick={handleSellSelected}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 font-bold transition-all cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Skrota för +{selectedSlot.tier * 8} ⚙️</span>
              </button>
            </div>
          )}
        </div>

        {/* Selected Weapon Detail & Immediate Equip */}
        <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 tactical-border flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4">
              <h3 className="text-xs uppercase font-bold text-slate-200 font-display flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Ballistisk Vapenanalys</span>
              </h3>
              <span className="text-[10px] font-tech text-cyan-400 font-bold">SMEDJE-MODUL</span>
            </div>

            {selectedWeapon ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-3 bg-[#050914] p-3 rounded-lg border border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-2xl shrink-0">
                      {selectedWeapon.icon || '🔫'}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-100 font-display">
                        {selectedWeapon.name}
                      </div>
                      <div className="text-[11px] font-tech text-amber-400">
                        Tier {selectedSlot?.tier} // {selectedWeapon.category}
                      </div>
                    </div>
                  </div>
                  {/* Active Kitty Hero Holding this Weapon */}
                  <div className="flex flex-col items-center shrink-0 pl-2.5 border-l border-slate-800">
                    <ProceduralCatSprite cat={activeCat} size={42} />
                    <span className="text-[9px] font-tech text-slate-400 mt-0.5">{activeCat.codename}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-400 font-tech leading-relaxed">
                  {selectedWeapon.description}
                </p>

                {/* Real Combat Metrics Bar */}
                <WeaponTacticalMetrics
                  stats={{
                    damage: selectedWeapon.damage,
                    fireRate: selectedWeapon.fireRate,
                    reloadSpeed: selectedWeapon.reloadSpeed,
                    magazineSize: selectedWeapon.magazineSize,
                    range: selectedWeapon.range,
                    dps: selectedWeapon.dps,
                  }}
                  showDividers={false}
                />

                <button
                  onClick={() => onEquipWeapon(selectedWeapon.id)}
                  disabled={profile.selectedWeapon === selectedWeapon.id}
                  className={`w-full py-2.5 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer ${
                    profile.selectedWeapon === selectedWeapon.id
                      ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-400'
                      : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                  }`}
                >
                  {profile.selectedWeapon === selectedWeapon.id ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Redan Utrustad på Katt</span>
                    </>
                  ) : (
                    <>
                      <ChevronRight className="w-4 h-4" />
                      <span>Utrusta till Aktiv Krigare</span>
                    </>
                  )}
                </button>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-center text-slate-500 font-tech p-4">
                <Box className="w-10 h-10 mb-2 text-slate-700" />
                <p className="text-xs">Klicka på ett vapen i smedjans rutnät för att se dess eldkraft eller utrusta det direkt.</p>
              </div>
            )}
          </div>

          {/* Active Equipped Weapon Reminder */}
          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] font-tech flex items-center justify-between text-slate-400">
            <span>Aktivt fältvapen:</span>
            <span className="text-amber-400 font-bold">{currentEquippedWeapon.name}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
