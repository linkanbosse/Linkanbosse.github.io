package com.catwarriors.apocalypse;

import java.util.List;

public class CollisionSystem {
    public static void checkCollisions(Player player, List<Projectile> projectiles,
                                        List<Enemy> enemies, Boss boss,
                                        ParticleSystem particles) {
        for (Projectile p : projectiles) {
            if (!p.active) continue;

            if (p.fromPlayer) {
                // Check against boss
                if (boss != null && boss.active) {
                    float d = (float) Math.hypot(p.x - boss.x, p.y - boss.y);
                    if (d < boss.radius + p.radius) {
                        boss.takeDamage(p.damage);
                        p.penetrationRemaining--;
                        particles.emitSparks(p.x, p.y, 6);
                        if (p.penetrationRemaining <= 0) {
                            p.active = false;
                        }
                    }
                }

                // Check against enemies
                for (Enemy e : enemies) {
                    if (!e.active) continue;
                    float d = (float) Math.hypot(p.x - e.x, p.y - e.y);
                    if (d < e.radius + p.radius) {
                        e.takeDamage(p.damage);
                        p.penetrationRemaining--;
                        particles.emitSparks(p.x, p.y, 4);
                        if (p.penetrationRemaining <= 0) {
                            p.active = false;
                            break;
                        }
                    }
                }
            } else {
                // Check enemy projectile against player
                if (!player.isDodging) {
                    float d = (float) Math.hypot(p.x - player.x, p.y - player.y);
                    if (d < 18 + p.radius) {
                        player.takeDamage(p.damage);
                        particles.emitSparks(player.x, player.y, 6);
                        p.active = false;
                    }
                }
            }
        }
    }
}
