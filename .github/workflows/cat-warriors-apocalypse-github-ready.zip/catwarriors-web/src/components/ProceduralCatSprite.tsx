import React from 'react';
import { CatWarrior } from '../types/game';

interface ProceduralCatSpriteProps {
  cat: CatWarrior;
  size?: number | string;
  className?: string;
  animated?: boolean;
  showBadge?: boolean;
}

/**
 * ProceduralCatSprite
 * Renders an adorable, high-fidelity procedural SVG vector sprite for any Cat Warrior hero.
 * Features animated ear twitches, breathing, swishing fluffy tail, and kawaii feline eyes.
 */
export const ProceduralCatSprite: React.FC<ProceduralCatSpriteProps> = ({
  cat,
  size = 56,
  className = '',
  animated = true,
  showBadge = false,
}) => {
  const fur = cat.furColor || '#f97316';
  const suit = cat.suitColor || '#1e293b';
  const accent = cat.accentColor || '#f59e0b';
  const earInner = cat.earColor || '#f472b6';
  const eye = cat.eyeColor || '#10b981';
  const marking = cat.markingPattern || 'stripes';
  const role = cat.role.toLowerCase();

  const isSniper = role.includes('sniper');
  const isTank = role.includes('tank') || role.includes('heavy');
  const isMedic = role.includes('medic');
  const isNinja = role.includes('ninja') || role.includes('infiltrator');

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full overflow-visible"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Subtle Ambient Radial Glow */}
          <radialGradient id={`glow-${cat.id}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={accent} stopOpacity="0.25" />
            <stop offset="100%" stopColor={accent} stopOpacity="0" />
          </radialGradient>

          {/* Armor Shading */}
          <linearGradient id={`suit-grad-${cat.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={suit} />
            <stop offset="100%" stopColor="#090d16" />
          </linearGradient>

          {/* Eye Iris Depth Gradient */}
          <linearGradient id={`eye-grad-${cat.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={eye} />
            <stop offset="100%" stopColor="#064e3b" />
          </linearGradient>
        </defs>

        {/* 1. Backdrop Glow Ring */}
        <circle cx="50" cy="50" r="46" fill={`url(#glow-${cat.id})`} />

        {/* 2. Soft Ground Shadow */}
        <ellipse cx="50" cy="88" rx="28" ry="7" fill="rgba(0,0,0,0.4)" />

        {/* 3. Swishing Fluffy Tail */}
        <g className={animated ? 'origin-[30px_70px] animate-[tailSwish_3s_ease-in-out_infinite]' : ''}>
          <path
            d="M 28 68 C 12 70 8 50 18 42 C 22 38 28 42 24 48 C 20 54 22 62 30 66 Z"
            fill={fur}
          />
          {/* Fluffy white tail tip */}
          <path
            d="M 18 42 C 14 44 12 40 16 36 C 20 32 24 38 22 42 Z"
            fill="#ffffff"
          />
        </g>

        {/* 4. Rear Paws with Cute Toe Beans */}
        <g>
          {/* Left rear paw */}
          <ellipse cx="28" cy="80" rx="9" ry="6" fill={fur} />
          <circle cx="28" cy="81" r="2.8" fill="#f472b6" />
          <circle cx="23" cy="78" r="1.5" fill="#f472b6" />
          <circle cx="28" cy="76" r="1.5" fill="#f472b6" />
          <circle cx="33" cy="78" r="1.5" fill="#f472b6" />

          {/* Right rear paw */}
          <ellipse cx="72" cy="80" rx="9" ry="6" fill={fur} />
          <circle cx="72" cy="81" r="2.8" fill="#f472b6" />
          <circle cx="67" cy="78" r="1.5" fill="#f472b6" />
          <circle cx="72" cy="76" r="1.5" fill="#f472b6" />
          <circle cx="77" cy="78" r="1.5" fill="#f472b6" />
        </g>

        {/* 5. Main Cat Body with Purr / Breathing Animation */}
        <g className={animated ? 'origin-bottom animate-[catBreathe_3.2s_ease-in-out_infinite]' : ''}>
          {/* Fur Base Body */}
          <ellipse cx="50" cy="62" rx="25" ry="22" fill={fur} />

          {/* Tactical Ballistic Vest */}
          <path
            d="M 32 50 C 32 44 68 44 68 50 C 70 66 64 74 50 74 C 36 74 30 66 32 50 Z"
            fill={`url(#suit-grad-${cat.id})`}
            stroke={accent}
            strokeWidth="1.6"
          />

          {/* Chest Rig Plate & Rank Medallion */}
          <ellipse cx="50" cy="58" rx="11" ry="8" fill={cat.color} stroke={accent} strokeWidth="1" />
          <path d="M 50 54 L 53 58 L 50 62 L 47 58 Z" fill="#f59e0b" />

          {/* Tactical Webbing Straps */}
          <line x1="36" y1="52" x2="64" y2="64" stroke="rgba(255,255,255,0.15)" strokeWidth="1.8" />
          <line x1="36" y1="64" x2="64" y2="52" stroke="rgba(255,255,255,0.15)" strokeWidth="1.8" />

          {/* Medic Cross Insignia */}
          {isMedic && (
            <g transform="translate(45, 64) scale(0.7)">
              <rect x="0" y="4" width="14" height="6" rx="1" fill="#ef4444" />
              <rect x="4" y="0" width="6" height="14" rx="1" fill="#ef4444" />
            </g>
          )}

          {/* Front Paws Resting on Rig */}
          <ellipse cx="38" cy="70" rx="6" ry="5" fill={fur} />
          <ellipse cx="62" cy="70" rx="6" ry="5" fill={fur} />
        </g>

        {/* 6. Fluffy Feline Head */}
        <g>
          {/* Main Head Base */}
          <ellipse cx="50" cy="38" rx="23" ry="19" fill={fur} />

          {/* Fluffy Cheeks */}
          <path d="M 27 38 L 19 44 L 29 46 Z" fill={fur} />
          <path d="M 73 38 L 81 44 L 71 46 Z" fill={fur} />

          {/* Breed Specific Face Patterns */}
          {marking === 'stripes' && (
            <g fill="rgba(0,0,0,0.25)">
              <path d="M 44 23 L 50 25 L 44 26 Z" />
              <path d="M 56 23 L 50 25 L 56 26 Z" />
              <path d="M 46 29 L 50 30 L 46 31 Z" />
              <path d="M 54 29 L 50 30 L 54 31 Z" />
            </g>
          )}

          {marking === 'tuxedo' && (
            <ellipse cx="50" cy="43" rx="10" ry="8" fill="#ffffff" />
          )}

          {marking === 'points' && (
            <ellipse cx="50" cy="41" rx="12" ry="9" fill="rgba(44, 26, 18, 0.7)" />
          )}

          {marking === 'patches' && (
            <>
              <circle cx="38" cy="31" r="7" fill="#ea580c" />
              <circle cx="61" cy="34" r="6" fill="#1e293b" />
            </>
          )}

          {/* 7. Pointy Cat Ears with Twitch Animation */}
          {/* Left Ear */}
          <g className={animated ? 'origin-[32px_24px] animate-[earTwitchL_4s_ease-in-out_infinite]' : ''}>
            <polygon points="28,26 21,8 41,20" fill={fur} />
            <polygon points="29,24 24,12 38,20" fill={earInner} />
          </g>

          {/* Right Ear */}
          <g className={animated ? 'origin-[68px_24px] animate-[earTwitchR_4s_ease-in-out_infinite]' : ''}>
            <polygon points="72,26 79,8 59,20" fill={fur} />
            <polygon points="71,24 76,12 62,20" fill={earInner} />
          </g>

          {/* Headband / Sniper / Ninja / Tank Helmet details */}
          {isSniper && (
            <g>
              {/* Tactical Foliage Headband */}
              <rect x="27" y="24" width="46" height="5" rx="2" fill="#166534" />
              {/* Cyber Monocular on Left Eye */}
              <circle cx="39" cy="36" r="8" fill="#0f172a" stroke="#06b6d4" strokeWidth="1.5" />
              <circle cx="39" cy="36" r="3" fill="#06b6d4" />
            </g>
          )}

          {isNinja && (
            <path
              d="M 28 32 C 34 26 66 26 72 32 L 72 37 C 66 31 34 31 28 37 Z"
              fill="#090d16"
              stroke="#a855f7"
              strokeWidth="1"
            />
          )}

          {isTank && (
            <g>
              <path d="M 30 22 C 38 18 62 18 70 22 L 72 28 L 28 28 Z" fill="#334155" />
              <rect x="34" y="25" width="32" height="3" fill="#38bdf8" />
            </g>
          )}

          {/* 8. Kawaii Anime Cat Eyes with Blinking Cycle */}
          <g className={animated ? 'origin-[50px_36px] animate-[catBlink_4.5s_infinite]' : ''}>
            {/* Left Eye */}
            {!(isSniper) && (
              <g>
                <ellipse cx="38" cy="36" rx="5.5" ry="6" fill="#ffffff" />
                <ellipse cx="38.5" cy="36" rx="4.2" ry="5.2" fill={`url(#eye-grad-${cat.id})`} />
                <ellipse cx="38.8" cy="36" rx="2" ry="4.2" fill="#090d16" />
                {/* Shiny reflections */}
                <circle cx="37" cy="33.5" r="1.8" fill="#ffffff" />
                <circle cx="40.5" cy="38" r="0.9" fill="#ffffff" />
              </g>
            )}

            {/* Right Eye */}
            <g>
              <ellipse cx="62" cy="36" rx="5.5" ry="6" fill="#ffffff" />
              <ellipse cx="61.5" cy="36" rx="4.2" ry="5.2" fill={`url(#eye-grad-${cat.id})`} />
              <ellipse cx="61.2" cy="36" rx="2" ry="4.2" fill="#090d16" />
              {/* Shiny reflections */}
              <circle cx="60" cy="33.5" r="1.8" fill="#ffffff" />
              <circle cx="63.5" cy="38" r="0.9" fill="#ffffff" />
            </g>
          </g>

          {/* 9. Cute Pink Nose & Mouth */}
          <ellipse cx="50" cy="42" rx="2.5" ry="1.8" fill="#f472b6" />
          <path d="M 50 43.8 L 50 46" stroke="#475569" strokeWidth="1" strokeLinecap="round" />
          <path
            d="M 46 46 C 48 48 50 47 50 46 C 50 47 52 48 54 46"
            stroke="#475569"
            strokeWidth="1"
            fill="none"
            strokeLinecap="round"
          />

          {/* 10. Whiskers */}
          <g stroke="rgba(255,255,255,0.75)" strokeWidth="1.2" strokeLinecap="round">
            {/* Left */}
            <line x1="32" y1="42" x2="16" y2="39" />
            <line x1="32" y1="44" x2="14" y2="44" />
            <line x1="32" y1="46" x2="17" y2="49" />
            {/* Right */}
            <line x1="68" y1="42" x2="84" y2="39" />
            <line x1="68" y1="44" x2="86" y2="44" />
            <line x1="68" y1="46" x2="83" y2="49" />
          </g>
        </g>
      </svg>

      {/* Role Pill Badge Overlay if requested */}
      {showBadge && (
        <span
          className="absolute -bottom-1 text-[9px] font-tech font-bold uppercase tracking-wider px-1.5 py-0.2 rounded shadow-md border"
          style={{
            backgroundColor: `${cat.accentColor}25`,
            borderColor: cat.accentColor,
            color: cat.accentColor,
          }}
        >
          {cat.role}
        </span>
      )}
    </div>
  );
};
