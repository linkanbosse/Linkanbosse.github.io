package com.catwarriors.apocalypse;

public class Player {
    public float x = 0;
    public float y = 0;
    public float angle = 0;
    public float hp;
    public float maxHp;
    public float armor;
    public float maxArmor;
    public float speed;
    public float critChance;

    public CatCharacter currentCat;
    public Weapon currentWeapon;

    public int ammo;
    public boolean isReloading = false;
    public float reloadTimer = 0;
    public float skillCooldownRemaining = 0;
    public float dodgeCooldownRemaining = 0;
    public boolean isDodging = false;
    public float dodgeTimer = 0;

    public Player(CatCharacter cat, Weapon weapon) {
        this.currentCat = cat;
        this.currentWeapon = weapon;
        this.maxHp = cat.baseHp;
        this.hp = cat.baseHp;
        this.maxArmor = cat.baseArmor;
        this.armor = cat.baseArmor;
        this.speed = cat.baseSpeed;
        this.critChance = cat.critChance;
        this.ammo = weapon.magazineSize;
    }

    public void update(float dt) {
        if (skillCooldownRemaining > 0) {
            skillCooldownRemaining = Math.max(0, skillCooldownRemaining - dt);
        }
        if (dodgeCooldownRemaining > 0) {
            dodgeCooldownRemaining = Math.max(0, dodgeCooldownRemaining - dt);
        }
        if (isDodging) {
            dodgeTimer -= dt;
            if (dodgeTimer <= 0) {
                isDodging = false;
            }
        }
        if (isReloading) {
            reloadTimer -= dt;
            if (reloadTimer <= 0) {
                isReloading = false;
                ammo = currentWeapon.magazineSize;
            }
        }
    }

    public void triggerDodge() {
        if (dodgeCooldownRemaining <= 0 && !isDodging) {
            isDodging = true;
            dodgeTimer = 0.25f;
            dodgeCooldownRemaining = 1.6f;
        }
    }

    public void reload() {
        if (!isReloading && ammo < currentWeapon.magazineSize) {
            isReloading = true;
            reloadTimer = currentWeapon.reloadTime;
        }
    }

    public void takeDamage(float rawDamage) {
        float finalDamage = rawDamage;
        if (armor > 0) {
            float absorbed = Math.min(armor, rawDamage * 0.6f);
            armor -= absorbed;
            finalDamage = rawDamage - absorbed;
        }
        hp = Math.max(0, hp - finalDamage);
    }
}
