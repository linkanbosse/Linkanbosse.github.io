package com.catwarriors.apocalypse;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    public int coins = 100;
    public int scrap = 20;
    public List<String> unlockedCats = new ArrayList<>();
    public List<String> unlockedWeapons = new ArrayList<>();

    public Inventory() {
        unlockedCats.add(GameConstants.CAT_ASSAULT);
        unlockedWeapons.add(GameConstants.WEAPON_ASSAULT_RIFLE);
        unlockedWeapons.add(GameConstants.WEAPON_PISTOL);
    }
}
