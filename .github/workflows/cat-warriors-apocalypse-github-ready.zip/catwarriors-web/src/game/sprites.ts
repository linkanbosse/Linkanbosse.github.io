import { CatWarrior, EnemyInstance, BossInstance, EnemyType } from '../types/game';
import { CAT_WARRIORS, WEAPONS } from './constants';

/**
 * Procedural Vector Sprite Renderer
 * Transitions characters, enemies, and bosses from basic geometric shapes into
 * high-fidelity, multi-layered tactical sprite assets with fluid animations.
 */
export class ProceduralSpriteRenderer {
  /**
   * Draws a highly-detailed procedural Cat Warrior hero sprite
   */
  public static drawCat(
    ctx: CanvasRenderingContext2D,
    cat: CatWarrior,
    weaponId: string,
    isDodging: boolean,
    isFiring: boolean,
    recoilOffset: number,
    gameTime: number
  ) {
    const weapon = WEAPONS.find((w) => w.id === weaponId) || WEAPONS[0];

    // 1. Purr / Idle breathe bounce & stride motion
    const breathe = Math.sin(gameTime * 4.5) * 0.8;
    const stride = Math.sin(gameTime * 14);
    const strideCos = Math.cos(gameTime * 14);
    const pawL = stride * 5;
    const pawR = -stride * 5;

    // 2. High-speed Dodge Ghosting & After-burn
    if (isDodging) {
      ctx.save();
      ctx.fillStyle = cat.accentColor;
      ctx.globalAlpha = 0.4;
      ctx.beginPath();
      ctx.arc(0, 0, 36, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 3. Fluffy Swishing Tail (Multi-segment physics curve)
    ctx.save();
    const tailWave = Math.sin(gameTime * 6.5) * 8.5;
    const tailTipWave = Math.sin(gameTime * 6.5 + 0.8) * 12;

    // Tail shadow
    ctx.strokeStyle = 'rgba(0,0,0,0.25)';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-16, 2);
    ctx.bezierCurveTo(-26, tailWave * 0.7 + 2, -34, tailTipWave * 0.8 + 2, -40, tailTipWave + 2);
    ctx.stroke();

    // Main tail fur
    ctx.strokeStyle = cat.furColor;
    ctx.lineWidth = 5.5;
    ctx.beginPath();
    ctx.moveTo(-16, 0);
    ctx.bezierCurveTo(-26, tailWave * 0.7, -34, tailTipWave * 0.8, -40, tailTipWave);
    ctx.stroke();

    // Tail tip (white fluffy dipped tip or accent)
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(-33, tailTipWave * 0.8);
    ctx.lineTo(-40, tailTipWave);
    ctx.stroke();
    ctx.restore();

    // 4. Rear Paws with Cute Pink Toe Beans
    ctx.save();
    // Left rear paw
    ctx.fillStyle = cat.furColor;
    ctx.beginPath();
    ctx.ellipse(-13, -15 + pawL, 7, 5, 0.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.15)';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Right rear paw
    ctx.beginPath();
    ctx.ellipse(-13, 15 + pawR, 7, 5, -0.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Cute pink pads
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.arc(-14, -15 + pawL, 2.2, 0, Math.PI * 2);
    ctx.arc(-14, 15 + pawR, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // 5. Front Paws (tactical steady grip)
    ctx.save();
    ctx.fillStyle = cat.furColor;
    ctx.beginPath();
    ctx.ellipse(11 - recoilOffset * 0.5, -12 + pawR * 0.3, 6, 4.5, 0, 0, Math.PI * 2);
    ctx.ellipse(15 - recoilOffset * 0.5, 12 + pawL * 0.3, 6, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // 6. Tactical Ballistic Armor Rig & Backpack
    ctx.save();
    // Heavy Backpack / Battery Module
    ctx.fillStyle = '#090d16';
    ctx.strokeStyle = cat.accentColor;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.roundRect(-19, -10, 9, 20, 2);
    ctx.fill();
    ctx.stroke();

    // Blinking status comms LED
    const ledBlink = Math.sin(gameTime * 5) > 0;
    ctx.fillStyle = ledBlink ? '#22c55e' : '#14532d';
    ctx.beginPath();
    ctx.arc(-15, -6, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // Antenna wire with radio knob
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(-16, -10);
    ctx.lineTo(-21, -19);
    ctx.stroke();
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(-21, -19, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // Main Torso Armor Vest (Combat Rig)
    ctx.fillStyle = cat.suitColor;
    ctx.beginPath();
    ctx.ellipse(0, 0, 21 + breathe * 0.5, 19 + breathe * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Armor Chestplate with Unit Accent
    ctx.fillStyle = cat.color;
    ctx.beginPath();
    ctx.ellipse(2, 0, 15, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = cat.accentColor;
    ctx.lineWidth = 1.6;
    ctx.stroke();

    // Tactical Webbing Straps across chest
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.7)';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(-6, -12);
    ctx.lineTo(8, 12);
    ctx.moveTo(-6, 12);
    ctx.lineTo(8, -12);
    ctx.stroke();

    // Unit Rank Insignia
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.moveTo(3, -3);
    ctx.lineTo(6, 0);
    ctx.lineTo(3, 3);
    ctx.lineTo(1, 0);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // 7. Fluffy Feline Head & Cheeks
    ctx.save();
    ctx.fillStyle = cat.furColor;
    ctx.beginPath();
    ctx.ellipse(10, 0, 15, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    // Fluffy cheek tufts
    ctx.beginPath();
    ctx.moveTo(10, -13);
    ctx.lineTo(6, -19);
    ctx.lineTo(14, -15);
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(10, 13);
    ctx.lineTo(6, 19);
    ctx.lineTo(14, 15);
    ctx.fill();

    // Breed specific markings
    if (cat.markingPattern === 'stripes') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.28)';
      ctx.beginPath();
      ctx.moveTo(11, -6);
      ctx.lineTo(16, -5);
      ctx.lineTo(11, -4);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(11, 4);
      ctx.lineTo(16, 5);
      ctx.lineTo(11, 6);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(9, -2);
      ctx.lineTo(15, 0);
      ctx.lineTo(9, 2);
      ctx.fill();
    } else if (cat.markingPattern === 'tuxedo') {
      // White tuxedo bib & muzzle
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(7, 0, 9, 8, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (cat.markingPattern === 'points') {
      // Siamese dark seal points muzzle
      ctx.fillStyle = 'rgba(44, 26, 18, 0.65)';
      ctx.beginPath();
      ctx.ellipse(15, 0, 7, 6, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (cat.markingPattern === 'patches') {
      // Calico orange/black dual patches
      ctx.fillStyle = '#ea580c';
      ctx.beginPath();
      ctx.arc(8, -8, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.arc(12, 7, 5, 0, Math.PI * 2);
      ctx.fill();
    }

    // 8. Animated Twitching Pointy Ears
    const earTwitch = Math.sin(gameTime * 2.8) * 1.8;
    const earColor = cat.earColor || '#f472b6';

    // Left Ear
    ctx.fillStyle = cat.furColor;
    ctx.beginPath();
    ctx.moveTo(8, -11);
    ctx.lineTo(19 + earTwitch, -20);
    ctx.lineTo(3, -15);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = earColor;
    ctx.beginPath();
    ctx.moveTo(9, -11);
    ctx.lineTo(17 + earTwitch, -18);
    ctx.lineTo(5, -14);
    ctx.closePath();
    ctx.fill();

    // Right Ear
    ctx.fillStyle = cat.furColor;
    ctx.beginPath();
    ctx.moveTo(8, 11);
    ctx.lineTo(19 - earTwitch, 20);
    ctx.lineTo(3, 15);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = earColor;
    ctx.beginPath();
    ctx.moveTo(9, 11);
    ctx.lineTo(17 - earTwitch, 18);
    ctx.lineTo(5, 14);
    ctx.closePath();
    ctx.fill();

    // Headgear / Role accessory
    if (cat.role.toLowerCase().includes('sniper')) {
      // Camo band & optical monocular
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(10, 0, 14, -Math.PI * 0.45, Math.PI * 0.45);
      ctx.stroke();

      // Tactical Monocular on right eye
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(14, 3, 5, 5);
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.arc(19, 5.5, 2.2, 0, Math.PI * 2);
      ctx.fill();
    } else if (cat.role.toLowerCase().includes('tank') || cat.role.toLowerCase().includes('heavy')) {
      // Heavy Ballistic Visor Plate
      ctx.fillStyle = '#334155';
      ctx.fillRect(7, -8, 5, 16);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1;
      ctx.strokeRect(7, -8, 5, 16);
    }

    // 9. Kawaii Large Expressive Anime Eyes with Blinking Cycle
    const blinkCycle = Math.sin(gameTime * 0.8);
    const isBlinking = blinkCycle > 0.95;

    if (isBlinking) {
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(14, -7);
      ctx.lineTo(18, -4);
      ctx.moveTo(14, 7);
      ctx.lineTo(18, 4);
      ctx.stroke();
    } else {
      const eyeHue = cat.eyeColor || '#10b981';

      // Eye White/Base Sclera
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(16, -4.5, 3.6, 3.3, 0.1, 0, Math.PI * 2);
      ctx.ellipse(16, 4.5, 3.6, 3.3, -0.1, 0, Math.PI * 2);
      ctx.fill();

      // Vibrant Iris
      ctx.fillStyle = eyeHue;
      ctx.beginPath();
      ctx.ellipse(16.2, -4.5, 2.8, 2.8, 0, 0, Math.PI * 2);
      ctx.ellipse(16.2, 4.5, 2.8, 2.8, 0, 0, Math.PI * 2);
      ctx.fill();

      // Feline Slit / Pupil
      ctx.fillStyle = '#090d16';
      ctx.beginPath();
      ctx.ellipse(16.5, -4.5, 1.4, 2.4, 0, 0, Math.PI * 2);
      ctx.ellipse(16.5, 4.5, 1.4, 2.4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Shiny Kawaii Highlights
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(15.2, -5.8, 1.3, 0, Math.PI * 2);
      ctx.arc(15.2, 3.2, 1.3, 0, Math.PI * 2);
      ctx.arc(17.2, -3.5, 0.7, 0, Math.PI * 2);
      ctx.arc(17.2, 5.5, 0.7, 0, Math.PI * 2);
      ctx.fill();
    }

    // 10. Cute Snout, Nose & Whiskers
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.ellipse(19, 0, 2.3, 1.7, 0, 0, Math.PI * 2);
    ctx.fill();

    // Whiskers that twitch on recoil and walking
    const whiskerWiggle = Math.sin(gameTime * 9) * 0.7;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    // Left side whiskers
    ctx.moveTo(19, -2);
    ctx.lineTo(29, -8 + whiskerWiggle);
    ctx.moveTo(19, -1);
    ctx.lineTo(31, -2 + whiskerWiggle);
    ctx.moveTo(19, 0);
    ctx.lineTo(29, 3 + whiskerWiggle);
    // Right side whiskers
    ctx.moveTo(19, 0);
    ctx.lineTo(29, -3 - whiskerWiggle);
    ctx.moveTo(19, 1);
    ctx.lineTo(31, 2 - whiskerWiggle);
    ctx.moveTo(19, 2);
    ctx.lineTo(29, 8 - whiskerWiggle);
    ctx.stroke();

    ctx.restore();

    // 11. Held Firearm with Realistic Recoil and Laser Sight
    this.drawHeldFirearm(ctx, weapon, recoilOffset, isFiring, gameTime);
  }

  /**
   * Renders the equipped weapon with recoil physics and dynamic attachments
   */
  private static drawHeldFirearm(
    ctx: CanvasRenderingContext2D,
    weapon: { id: string; category: string; bulletColor: string; tier?: number },
    recoil: number,
    isFiring: boolean,
    gameTime: number
  ) {
    ctx.save();
    ctx.translate(16 - recoil, 9);

    const isHandgun = weapon.category.includes('Handgun');
    const isShotgun = weapon.category.includes('Shotgun');
    const isSniper = weapon.category.includes('Sniper');
    const isLauncher = weapon.category.includes('Launcher');
    const isFlamethrower = weapon.category.includes('Flamethrower');
    const isMinigun = weapon.category.includes('Minigun');

    if (isHandgun) {
      // Tactical Pistol
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, -2, 13, 5);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(4, -3, 9, 3);
      // Slide ejection port
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(6, -2, 3, 2);
    } else if (isShotgun) {
      // Heavy Shotgun with Wooden/Composite Stock & Dual Barrels
      ctx.fillStyle = '#78350f';
      ctx.fillRect(-3, -3, 18, 7);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(6, -2, 17, 5);
      // Dual barrel muzzle
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(23, -3, 3, 6);
      ctx.fillStyle = '#000000';
      ctx.fillRect(25, -2, 2, 2);
      ctx.fillRect(25, 1, 2, 2);
    } else if (isSniper) {
      // Long-Barreled Anti-Materiel Rifle
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-8, -2, 38, 4);
      // Muzzle Brake
      ctx.fillStyle = '#475569';
      ctx.fillRect(30, -3, 4, 6);
      // Optical Scope with Lens Glow
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(0, -7, 14, 5);
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(11, -6, 3, 3);
    } else if (isLauncher) {
      // Heavy Rocket Tube
      ctx.fillStyle = '#14532d';
      ctx.fillRect(-6, -6, 28, 12);
      ctx.fillStyle = '#ea580c';
      ctx.beginPath();
      ctx.arc(22, 0, 6, 0, Math.PI * 2);
      ctx.fill();
    } else if (isFlamethrower) {
      // Napalm Fuel Tank & Barrel
      ctx.fillStyle = '#c2410c';
      ctx.fillRect(-5, -5, 24, 10);
      // Pilot Igniter Flame
      const flameFlicker = Math.sin(gameTime * 22) * 1.5;
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(21, 0, 3 + flameFlicker, 0, Math.PI * 2);
      ctx.fill();
    } else if (isMinigun) {
      // Rotating Six-Barrel Gatling
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-6, -5, 16, 10);
      ctx.fillStyle = '#475569';
      ctx.fillRect(10, -5, 16, 10);
      // Barrels
      ctx.fillStyle = '#020617';
      ctx.fillRect(26, -5, 3, 10);
    } else {
      // Assault Rifle / SMG / Energy Carbine
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-3, -3, 23, 6);
      ctx.fillStyle = '#475569';
      ctx.fillRect(3, -4, 16, 3);
      // Curved Magazine
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(4, 3, 5, 7);
      // Holographic Sight
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(6, -6, 4, 2);
      // Laser Designator Beam
      ctx.strokeStyle = weapon.bulletColor;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(20, 0);
      ctx.lineTo(28, 0);
      ctx.stroke();
    }

    // Dynamic Muzzle Flash when firing
    if (isFiring || recoil > 2) {
      ctx.save();
      ctx.translate(26, 0);
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(0, 0, 6 + recoil * 0.8, 0, Math.PI * 2);
      ctx.fill();

      // Flash Starburst rays
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-4, -6);
      ctx.lineTo(8, 0);
      ctx.lineTo(-4, 6);
      ctx.moveTo(0, -8);
      ctx.lineTo(0, 8);
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }

  /**
   * Draws a procedurally-styled enemy with dynamic animated traits
   */
  public static drawEnemy(
    ctx: CanvasRenderingContext2D,
    enemy: EnemyInstance,
    gameTime: number,
    isFlashing: boolean
  ) {
    const r = enemy.radius;
    const type: EnemyType = enemy.type;

    switch (type) {
      case 'mutant_rat': {
        // Radioactive Sewer Rodent
        const waddle = Math.sin(gameTime * 15 + enemy.id) * 3;
        ctx.fillStyle = isFlashing ? '#ffffff' : '#52525b';
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 1.05, r * 0.72 + waddle * 0.2, 0, 0, Math.PI * 2);
        ctx.fill();

        // Spine Toxic Quills
        ctx.fillStyle = isFlashing ? '#ffffff' : '#22c55e';
        ctx.beginPath();
        ctx.moveTo(-r * 0.6, -r * 0.6);
        ctx.lineTo(-r * 0.2, -r * 1.15);
        ctx.lineTo(r * 0.1, -r * 0.6);
        ctx.moveTo(-r * 0.1, -r * 0.6);
        ctx.lineTo(r * 0.3, -r * 1.1);
        ctx.lineTo(r * 0.6, -r * 0.6);
        ctx.fill();

        // Rodent Snout with Fangs
        ctx.fillStyle = isFlashing ? '#ffffff' : '#71717a';
        ctx.beginPath();
        ctx.moveTo(r * 0.5, -6);
        ctx.lineTo(r * 1.45, 0);
        ctx.lineTo(r * 0.5, 6);
        ctx.closePath();
        ctx.fill();

        // Sharp White Teeth
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(r * 1.35, -2, 3, 4);

        // Glowing Rabies Eyes
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(r * 0.75, -4.5, 2.8, 0, Math.PI * 2);
        ctx.arc(r * 0.75, 4.5, 2.8, 0, Math.PI * 2);
        ctx.fill();

        // Scuttling Tail with Sensor Node
        ctx.strokeStyle = '#fda4af';
        ctx.lineWidth = 2.8;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-r * 0.8, 0);
        ctx.quadraticCurveTo(-r * 1.3, waddle * 3, -r * 1.85, waddle * 4);
        ctx.stroke();
        break;
      }

      case 'zombie_cat': {
        // Biomechanical Ghoul Feline
        ctx.fillStyle = isFlashing ? '#ffffff' : '#3f6212';
        ctx.beginPath();
        ctx.ellipse(0, 0, r, r * 0.9, 0, 0, Math.PI * 2);
        ctx.fill();

        // Necrotic green fissures
        ctx.strokeStyle = '#84cc16';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.moveTo(-6, -6);
        ctx.lineTo(2, 0);
        ctx.lineTo(7, -4);
        ctx.stroke();

        // Exposed Cybernetic Skull Fragment
        ctx.fillStyle = '#94a3b8';
        ctx.beginPath();
        ctx.arc(6, 4, 5.5, 0, Math.PI * 2);
        ctx.fill();

        // Torn Ears
        ctx.fillStyle = isFlashing ? '#ffffff' : '#365314';
        ctx.beginPath();
        ctx.moveTo(6, -8);
        ctx.lineTo(15, -16);
        ctx.lineTo(2, -12);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(6, 8);
        ctx.lineTo(11, 13);
        ctx.lineTo(2, 11);
        ctx.fill();

        // Glowing Toxic Eyes
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(10, -4, 3.2, 0, Math.PI * 2);
        ctx.arc(10, 4, 3.2, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'armored_hound': {
        // Cyber Assault Hound
        ctx.fillStyle = isFlashing ? '#ffffff' : '#292524';
        ctx.beginPath();
        ctx.ellipse(0, 0, r, r * 0.8, 0, 0, Math.PI * 2);
        ctx.fill();

        // Titanium Ballistic Collar
        ctx.fillStyle = '#78716c';
        ctx.fillRect(r * 0.1, -r * 0.7, 6, r * 1.4);
        // Spikes on collar
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(r * 0.3, -r * 0.6, 3, 0, Math.PI * 2);
        ctx.arc(r * 0.3, r * 0.6, 3, 0, Math.PI * 2);
        ctx.fill();

        // Hydraulic Steel Jaw
        ctx.fillStyle = '#1c1917';
        ctx.fillRect(r * 0.5, -6, 12, 12);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(r * 0.9, -4, 3, 2);
        ctx.fillRect(r * 0.9, 2, 3, 2);

        // Menacing Quad Optic Sensors
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(r * 0.6, -3, 2, 0, Math.PI * 2);
        ctx.arc(r * 0.6, 3, 2, 0, Math.PI * 2);
        ctx.arc(r * 0.35, -4, 1.5, 0, Math.PI * 2);
        ctx.arc(r * 0.35, 4, 1.5, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'exploder': {
        // Volatile Bio-Plasma Orb
        const pulse = 1 + Math.sin(gameTime * 15) * 0.16;
        ctx.fillStyle = isFlashing ? '#ffffff' : '#dc2626';
        ctx.beginPath();
        ctx.arc(0, 0, r * pulse, 0, Math.PI * 2);
        ctx.fill();

        // Rotating Containment Ring
        ctx.strokeStyle = '#fde047';
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 0.7 * pulse, r * 0.4 * pulse, gameTime * 4, 0, Math.PI * 2);
        ctx.stroke();

        // Molten Core
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.38 * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.18 * pulse, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'acid_spitter': {
        // Acid-Artillery Amphibian
        ctx.fillStyle = isFlashing ? '#ffffff' : '#059669';
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();

        // Translucent Sloshing Venom Sac
        const venomPulse = 1 + Math.sin(gameTime * 8) * 0.18;
        ctx.fillStyle = 'rgba(163, 230, 53, 0.85)';
        ctx.beginPath();
        ctx.arc(-r * 0.35, 0, (r * 0.55) * venomPulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#65a30d';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Dual Spitter Nozzles
        ctx.fillStyle = '#064e3b';
        ctx.fillRect(r * 0.4, -6, 14, 5);
        ctx.fillRect(r * 0.4, 2, 14, 5);
        break;
      }

      case 'flying_drone': {
        // Hunter-Killer Quad Drone
        ctx.fillStyle = isFlashing ? '#ffffff' : '#0284c7';
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 0.8, r * 0.6, 0, 0, Math.PI * 2);
        ctx.fill();

        // Rotor Blur Discs (High RPM transparent blades)
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.65)';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.ellipse(-r * 0.6, -r * 0.6, r * 0.45, r * 0.25, gameTime * 20, 0, Math.PI * 2);
        ctx.ellipse(r * 0.6, -r * 0.6, r * 0.45, r * 0.25, -gameTime * 20, 0, Math.PI * 2);
        ctx.ellipse(-r * 0.6, r * 0.6, r * 0.45, r * 0.25, -gameTime * 20, 0, Math.PI * 2);
        ctx.ellipse(r * 0.6, r * 0.6, r * 0.45, r * 0.25, gameTime * 20, 0, Math.PI * 2);
        ctx.stroke();

        // Central Red Scanner Lens
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(r * 0.35, 0, 3.5, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'heavy_mech': {
        // Bipedal Titan War Machine
        ctx.fillStyle = isFlashing ? '#ffffff' : '#0f172a';
        ctx.fillRect(-r * 0.75, -r * 0.75, r * 1.5, r * 1.5);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-r * 0.75, -r * 0.75, r * 1.5, r * 1.5);

        // Core Cockpit Screen
        ctx.fillStyle = '#334155';
        ctx.fillRect(-r * 0.4, -r * 0.4, r * 0.8, r * 0.8);
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(r * 0.1, -2, 4, 4);

        // Dual Gatling Cannons
        ctx.fillStyle = '#475569';
        ctx.fillRect(r * 0.5, -9, 15, 6);
        ctx.fillRect(r * 0.5, 3, 15, 6);
        break;
      }

      case 'frost_crawler': {
        // Glacial Crystalline Arachnid
        ctx.fillStyle = isFlashing ? '#ffffff' : '#0369a1';
        ctx.beginPath();
        ctx.ellipse(0, 0, r, r * 0.8, 0, 0, Math.PI * 2);
        ctx.fill();

        // Diamond Ice Spine
        ctx.fillStyle = '#e0f2fe';
        ctx.beginPath();
        ctx.moveTo(0, -r * 0.6);
        ctx.lineTo(r * 0.6, 0);
        ctx.lineTo(0, r * 0.6);
        ctx.lineTo(-r * 0.6, 0);
        ctx.closePath();
        ctx.fill();

        // 6 Icicle Scythe Legs
        ctx.strokeStyle = '#bae6fd';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        for (let i = -1; i <= 1; i++) {
          ctx.moveTo(i * 6, -r * 0.6);
          ctx.lineTo(i * 12, -r * 1.2);
          ctx.moveTo(i * 6, r * 0.6);
          ctx.lineTo(i * 12, r * 1.2);
        }
        ctx.stroke();
        break;
      }

      case 'desert_scorpion': {
        // Dune Razor Scorpion
        ctx.fillStyle = isFlashing ? '#ffffff' : '#78350f';
        ctx.beginPath();
        ctx.ellipse(0, 0, r, r * 0.7, 0, 0, Math.PI * 2);
        ctx.fill();

        // Snapping Pincers
        ctx.fillStyle = '#d97706';
        ctx.beginPath();
        ctx.arc(r * 0.8, -9, 6, 0, Math.PI * 2);
        ctx.arc(r * 0.8, 9, 6, 0, Math.PI * 2);
        ctx.fill();

        // Segmented Stinger Tail
        const tailBob = Math.sin(gameTime * 9) * 4;
        ctx.strokeStyle = '#b45309';
        ctx.lineWidth = 3.2;
        ctx.beginPath();
        ctx.moveTo(-r * 0.6, 0);
        ctx.quadraticCurveTo(-r * 1.2, tailBob, -r * 1.6, -7);
        ctx.stroke();
        // Poison Needle Tip
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(-r * 1.6, -7, 3, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      default: {
        // Biomechanical Chimera
        ctx.fillStyle = isFlashing ? '#ffffff' : '#581c87';
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.6, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  }

  /**
   * Draws epic multi-stage procedural Boss sprites
   */
  public static drawBoss(
    ctx: CanvasRenderingContext2D,
    boss: BossInstance,
    gameTime: number,
    isFlashing: boolean
  ) {
    const r = boss.radius;

    // Outer Armored Carapace
    ctx.fillStyle = isFlashing ? '#ffffff' : '#0f172a';
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.fill();

    // Heavy Exterior Plating
    ctx.fillStyle = '#991b1b';
    ctx.beginPath();
    ctx.arc(r * 0.2, 0, r * 0.75, 0, Math.PI * 2);
    ctx.fill();

    // Pulsing Apocalypse Reactor Core
    const corePulse = 1 + Math.sin(gameTime * 8) * 0.22;
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.38 * corePulse, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.2 * corePulse, 0, Math.PI * 2);
    ctx.fill();

    // Heavy Armor Shoulder Fins
    ctx.fillStyle = '#475569';
    ctx.beginPath();
    ctx.moveTo(r * 0.6, -r * 0.6);
    ctx.lineTo(r * 1.45, -r * 0.95);
    ctx.lineTo(r * 0.3, -r * 0.85);
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(r * 0.6, r * 0.6);
    ctx.lineTo(r * 1.45, r * 0.95);
    ctx.lineTo(r * 0.3, r * 0.85);
    ctx.fill();

    // Glowing Menacing Mandibles
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.moveTo(r * 0.75, -16);
    ctx.lineTo(r * 1.35, -5);
    ctx.lineTo(r * 0.8, -2);
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(r * 0.75, 16);
    ctx.lineTo(r * 1.35, 5);
    ctx.lineTo(r * 0.8, 2);
    ctx.fill();
  }
}
