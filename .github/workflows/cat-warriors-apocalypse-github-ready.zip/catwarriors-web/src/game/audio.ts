/**
 * Procedural Web Audio Sound Synthesizer for Cat Warriors: Apocalypse
 * Generates arcade-quality sound effects, gun merge celebrations, rebirth fanfares,
 * and cute meows with zero external assets and 100% fail-safe error protection.
 */

class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  private initContext() {
    try {
      if (!this.ctx && typeof window !== 'undefined') {
        const AudioCtxClass =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtxClass) {
          this.ctx = new AudioCtxClass();
        }
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
    } catch {
      // Audio context restricted or unavailable
    }
  }

  public init() {
    this.initContext();
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      this.stopCombatBgm();
    }
  }

  public playClick() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.05);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.06);
    } catch {
      // Audio playback suppressed
    }
  }

  public playShoot(weaponType: string) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      if (weaponType.includes('shotgun') || weaponType === 'sawed_off_fury' || weaponType === 'devastator_shotgun') {
        this.playNoiseBlast(0.18, 0.22, 400);
        this.playToneSweep(250, 60, 0.15, 'sawtooth', 0.2);
      } else if (weaponType.includes('sniper') || weaponType === 'hunter_sniper') {
        this.playToneSweep(1200, 150, 0.2, 'square', 0.2);
        this.playNoiseBlast(0.12, 0.16, 1200);
      } else if (weaponType.includes('rocket') || weaponType.includes('missile') || weaponType.includes('grenade')) {
        this.playToneSweep(350, 110, 0.25, 'sawtooth', 0.25);
      } else if (
        weaponType.includes('energy') ||
        weaponType.includes('plasma') ||
        weaponType.includes('laser') ||
        weaponType.includes('void') ||
        weaponType.includes('pulse')
      ) {
        this.playToneSweep(900, 220, 0.11, 'sawtooth', 0.18);
        this.playToneSweep(1400, 350, 0.08, 'sine', 0.15);
      } else if (weaponType.includes('flame') || weaponType.includes('inferno')) {
        this.playNoiseBlast(0.08, 0.06, 600);
      } else if (weaponType.includes('minigun')) {
        this.playToneSweep(550, 150, 0.04, 'triangle', 0.15);
        this.playNoiseBlast(0.03, 0.08, 900);
      } else {
        this.playToneSweep(450, 100, 0.07, 'triangle', 0.16);
        this.playNoiseBlast(0.04, 0.08, 800);
      }
    } catch {
      // Audio suppressed
    }
  }

  public playExplosion() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      this.playNoiseBlast(0.42, 0.3, 300);
      this.playToneSweep(180, 30, 0.38, 'sawtooth', 0.25);
    } catch {}
  }

  public playEnemyHit() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, now);
      osc.frequency.exponentialRampToValueAtTime(80, now + 0.05);

      gain.gain.setValueAtTime(0.07, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.06);
    } catch {}
  }

  public playCatHurt() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      this.playToneSweep(650, 300, 0.16, 'sawtooth', 0.18);
      this.playNoiseBlast(0.08, 0.1, 1000);
    } catch {}
  }

  public playReload() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      this.playToneSweep(500, 750, 0.04, 'triangle', 0.09);
      setTimeout(() => {
        try {
          this.playToneSweep(750, 1100, 0.05, 'triangle', 0.11);
        } catch {}
      }, 120);
    } catch {}
  }

  public playSkill() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(900, now + 0.15);
      osc.frequency.exponentialRampToValueAtTime(1400, now + 0.3);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.35);
    } catch {}
  }

  public playPickup() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      this.playToneSweep(600, 1200, 0.09, 'sine', 0.15);
    } catch {}
  }

  // Gun Merge Success Sound
  public playMerge() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const chord = [523.25, 659.25, 783.99, 1046.5]; // C Major arpeggio
      chord.forEach((freq, idx) => {
        setTimeout(() => {
          if (!this.ctx) return;
          try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now);
            gain.gain.setValueAtTime(0.16, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.25);
          } catch {}
        }, idx * 60);
      });
    } catch {}
  }

  // Cute Meow Vocalization
  public playMeow() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.exponentialRampToValueAtTime(950, now + 0.08);
      osc.frequency.exponentialRampToValueAtTime(550, now + 0.28);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
    } catch {}
  }

  // Rebirth Prestige Fanfare
  public playRebirth() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const fanfare = [392, 523, 659, 784, 1046, 1318];
      fanfare.forEach((freq, i) => {
        setTimeout(() => {
          if (!this.ctx) return;
          try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now);
            gain.gain.setValueAtTime(0.18, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.35);
          } catch {}
        }, i * 90);
      });
    } catch {}
  }

  public playVictory() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const notes = [440, 554, 659, 880];
      notes.forEach((freq, i) => {
        setTimeout(() => {
          if (!this.ctx) return;
          try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now);

            gain.gain.setValueAtTime(0.18, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.3);
          } catch {}
        }, i * 110);
      });
    } catch {}
  }

  public playGameOver() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const notes = [400, 340, 280, 200];
      notes.forEach((freq, i) => {
        setTimeout(() => {
          if (!this.ctx) return;
          try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(freq, now);

            gain.gain.setValueAtTime(0.16, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.35);
          } catch {}
        }, i * 140);
      });
    } catch {}
  }

  public playBossRoar() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      this.playToneSweep(120, 45, 0.55, 'sawtooth', 0.28);
      this.playNoiseBlast(0.55, 0.22, 200);
    } catch {}
  }

  private playToneSweep(
    startFreq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType,
    volume: number
  ) {
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(Math.max(20, startFreq), now);
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + duration);

      gain.gain.setValueAtTime(Math.max(0.001, volume), now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + duration);
    } catch {}
  }

  private bgmInterval: ReturnType<typeof setInterval> | null = null;
  private bgmStep: number = 0;

  public startCombatBgm() {
    if (this.isMuted || this.bgmInterval) return;
    this.initContext();
    if (!this.ctx) return;

    const bassNotes = [110, 110, 130.8, 146.8, 110, 110, 164.8, 146.8];
    this.bgmStep = 0;
    this.bgmInterval = setInterval(() => {
      if (this.isMuted || !this.ctx) return;
      try {
        const now = this.ctx.currentTime;
        const freq = bassNotes[this.bgmStep % bassNotes.length];
        this.bgmStep++;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(320, now);

        gain.gain.setValueAtTime(0.045, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.18);
      } catch {}
    }, 220);
  }

  public stopCombatBgm() {
    if (this.bgmInterval) {
      clearInterval(this.bgmInterval);
      this.bgmInterval = null;
    }
  }

  private playNoiseBlast(duration: number, volume: number, filterFreq: number) {
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const dur = Math.max(0.02, duration);
      const bufferSize = Math.max(256, Math.floor(this.ctx.sampleRate * dur));
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);

      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(Math.max(50, filterFreq), now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(Math.max(0.001, volume), now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      whiteNoise.start(now);
      whiteNoise.stop(now + dur);
    } catch {}
  }
}

export const sound = new SoundSynthesizer();
