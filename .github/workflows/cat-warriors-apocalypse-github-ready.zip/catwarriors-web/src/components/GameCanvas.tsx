import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from '../game/engine';
import { GameRenderer } from '../game/renderer';
import { PlayerStats, PlayerProfile } from '../types/game';
import { CAT_WARRIORS, WEAPONS, ZONES } from '../game/constants';
import { calculateEffectiveWeaponStats } from '../types/game';
import { sound } from '../game/audio';
import { TacticalMinimap } from './TacticalMinimap';
import { MissionObjectivesHUD } from './MissionObjectivesHUD';
import { ActiveWeaponStatsHUD } from './ActiveWeaponStatsHUD';
import {
  Crosshair,
  RotateCcw,
  Volume2,
  VolumeX,
  Pause,
  Play,
  Home,
  AlertTriangle,
  Zap,
  Wind,
  Shield,
  Activity,
  Radar,
  Radio,
  SlidersHorizontal,
} from 'lucide-react';

interface GameCanvasProps {
  profile: PlayerProfile;
  zoneId: number;
  missionIndex: number;
  onExit: (
    rewardStats?: { coins: number; scrap: number; score: number; won: boolean },
    action?: 'MENU' | 'RETRY' | 'NEXT'
  ) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  profile,
  zoneId,
  missionIndex,
  onExit,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const joystickPointerIdRef = useRef<number | null>(null);

  const [playerStats, setPlayerStats] = useState<PlayerStats | null>(null);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [hudMode, setHudMode] = useState<'compact' | 'full'>('compact');
  const [victoryStats, setVictoryStats] = useState<{ kills: number; coins: number; scrap: number; score: number } | null>(null);
  const [gameOverStats, setGameOverStats] = useState<{ kills: number; coins: number; scrap: number; score: number } | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(profile?.settings?.soundEnabled ?? true);
  const [autoAim, setAutoAim] = useState<boolean>(profile?.settings?.autoAim ?? true);

  // Mobile virtual joystick state
  const [joystickTouch, setJoystickTouch] = useState<{
    active: boolean;
    startX: number;
    startY: number;
    currentX: number;
    currentY: number;
  }>({
    active: false,
    startX: 0,
    startY: 0,
    currentX: 0,
    currentY: 0,
  });

  // Engine instance reference
  const engineRef = useRef<GameEngine | null>(null);
  const rendererRef = useRef<GameRenderer | null>(null);
  const requestRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());
  const isPausedRef = useRef<boolean>(false);
  isPausedRef.current = isPaused;

  // Stable callbacks for Engine events
  const handleStatsUpdate = useCallback((stats: PlayerStats) => {
    setPlayerStats(stats);
  }, []);

  const handleGameOver = useCallback((stats: { kills: number; coins: number; scrap: number; score: number }) => {
    sound.stopCombatBgm();
    setGameOverStats(stats);
  }, []);

  const handleVictory = useCallback((stats: { kills: number; coins: number; scrap: number; score: number }) => {
    sound.stopCombatBgm();
    setVictoryStats(stats);
  }, []);

  // Initialize Game Engine & Renderer once per mission start
  useEffect(() => {
    if (!canvasRef.current) return;

    sound.init();
    sound.setMuted(!soundEnabled);
    if (soundEnabled) {
      sound.startCombatBgm();
    }

    const canvas = canvasRef.current;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const engine = new GameEngine(
      profile,
      zoneId,
      missionIndex,
      {
        onGameOver: handleGameOver,
        onVictory: handleVictory,
        onStatsUpdate: handleStatsUpdate,
      }
    );
    engineRef.current = engine;
    rendererRef.current = new GameRenderer();

    let animationFrameId: number;

    const loop = (time: number) => {
      const dt = Math.min((time - lastTimeRef.current) / 1000, 0.05);
      lastTimeRef.current = time;

      if (!isPausedRef.current && engineRef.current && rendererRef.current && canvasRef.current) {
        const currentCanvas = canvasRef.current;
        const ctx = currentCanvas.getContext('2d');
        if (ctx) {
          try {
            engineRef.current.update(dt);
            rendererRef.current.draw(
              ctx,
              currentCanvas.width,
              currentCanvas.height,
              engineRef.current.cameraX,
              engineRef.current.cameraY,
              engineRef.current.currentZone,
              engineRef.current.player,
              engineRef.current.projectiles,
              engineRef.current.enemies,
              engineRef.current.boss,
              engineRef.current.particles,
              engineRef.current.floatingTexts,
              engineRef.current.pickups,
              engineRef.current.drones,
              engineRef.current.gameTime
            );
          } catch (renderErr) {
            console.error('Render error:', renderErr);
          }
        }
      }

      animationFrameId = requestAnimationFrame(loop);
    };

    lastTimeRef.current = performance.now();
    animationFrameId = requestAnimationFrame(loop);
    requestRef.current = animationFrameId;

    return () => {
      cancelAnimationFrame(animationFrameId);
      sound.stopCombatBgm();
    };
  }, [profile, zoneId, missionIndex, handleGameOver, handleVictory, handleStatsUpdate]);

  // Window resize handler
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Keyboard controls
  useEffect(() => {
    const keys: Record<string, boolean> = {};

    const handleKeyDown = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = true;

      if (e.key === 'p' || e.key === 'Escape') {
        setIsPaused((prev) => !prev);
      }
      if (e.key.toLowerCase() === 'r') {
        engineRef.current?.triggerReload();
      }
      if (e.key.toLowerCase() === 'e' || e.key.toLowerCase() === 'q') {
        engineRef.current?.triggerSkill();
      }
      if (e.key === ' ' || e.key === 'Shift') {
        engineRef.current?.triggerDodge();
      }

      updateMoveDir();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = false;
      updateMoveDir();
    };

    const updateMoveDir = () => {
      if (!engineRef.current) return;
      let mx = 0;
      let my = 0;
      if (keys['w'] || keys['arrowup']) my -= 1;
      if (keys['s'] || keys['arrowdown']) my += 1;
      if (keys['a'] || keys['arrowleft']) mx -= 1;
      if (keys['d'] || keys['arrowright']) mx += 1;

      const len = Math.hypot(mx, my);
      if (len > 0) {
        mx /= len;
        my /= len;
      }
      engineRef.current.moveDir = { x: mx, y: my };
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Mouse firing and aiming
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0 && engineRef.current) {
      engineRef.current.isShooting = true;
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (e.button === 0 && engineRef.current) {
      engineRef.current.isShooting = false;
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!engineRef.current || autoAim || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left - canvasRef.current.width / 2;
    const my = e.clientY - rect.top - canvasRef.current.height / 2;
    engineRef.current.aimDir = { x: mx, y: my };
  };

  // Touch handlers for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    const halfWidth = window.innerWidth * 0.45;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.clientX < halfWidth && joystickPointerIdRef.current === null) {
        joystickPointerIdRef.current = touch.identifier;
        setJoystickTouch({
          active: true,
          startX: touch.clientX,
          startY: touch.clientY,
          currentX: touch.clientX,
          currentY: touch.clientY,
        });
      }
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickPointerIdRef.current) {
        const dx = touch.clientX - joystickTouch.startX;
        const dy = touch.clientY - joystickTouch.startY;
        const dist = Math.hypot(dx, dy);
        const maxRadius = 60;

        const clampedDist = Math.min(dist, maxRadius);
        const angle = Math.atan2(dy, dx);
        const curX = joystickTouch.startX + Math.cos(angle) * clampedDist;
        const curY = joystickTouch.startY + Math.sin(angle) * clampedDist;

        setJoystickTouch((prev) => ({
          ...prev,
          currentX: curX,
          currentY: curY,
        }));

        if (engineRef.current) {
          engineRef.current.moveDir = {
            x: clampedDist > 5 ? (Math.cos(angle) * clampedDist) / maxRadius : 0,
            y: clampedDist > 5 ? (Math.sin(angle) * clampedDist) / maxRadius : 0,
          };
        }
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickPointerIdRef.current) {
        joystickPointerIdRef.current = null;
        setJoystickTouch({
          active: false,
          startX: 0,
          startY: 0,
          currentX: 0,
          currentY: 0,
        });
        if (engineRef.current) {
          engineRef.current.moveDir = { x: 0, y: 0 };
        }
      }
    }
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sound.setMuted(!next);
    if (next) {
      sound.startCombatBgm();
    } else {
      sound.stopCombatBgm();
    }
  };

  const toggleAutoAim = () => {
    const next = !autoAim;
    setAutoAim(next);
    if (engineRef.current) {
      engineRef.current.autoAim = next;
    }
  };

  const selectedCat = CAT_WARRIORS.find((c) => c.id === profile.selectedCat) || CAT_WARRIORS[0];
  const selectedWeapon = WEAPONS.find((w) => w.id === profile.selectedWeapon) || WEAPONS[0];
  const currentZone = ZONES.find((z) => z.id === zoneId) || ZONES[0];
  const effectiveWeaponStats =
    engineRef.current?.effectiveWeaponStats ||
    calculateEffectiveWeaponStats(
      selectedWeapon,
      profile?.weaponLevels?.[selectedWeapon.id] || 1,
      profile?.gearUpgrades?.modchip || 0
    );

  return (
    <div
      className="relative w-screen h-screen overflow-hidden bg-[#040711] select-none touch-none"
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseMove={handleMouseMove}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Fullscreen Canvas */}
      <canvas ref={canvasRef} className="block w-full h-full" />

      {/* TOP TACTICAL HUD OVERLAY */}
      <div className="absolute top-0 left-0 right-0 p-3 sm:p-4 pointer-events-none flex flex-col gap-2 z-10">
        <div className="flex items-start justify-between gap-2">
          {/* Top-Left: Hero Vitals + Mission Objectives */}
          <div className="flex flex-col gap-2 items-start pointer-events-auto">
            {/* Hero & Vital Bars */}
            <div className="flex items-center gap-3 bg-[#090e1c]/90 backdrop-blur border border-amber-500/30 rounded-xl px-3 sm:px-3.5 py-2 pointer-events-auto tactical-border shadow-xl">
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white text-lg shadow-md border border-white/20 shrink-0"
                style={{ backgroundColor: selectedCat.color }}
              >
                {selectedCat.avatarIcon || '🐱'}
              </div>
              <div className="flex flex-col gap-1 w-32 sm:w-44 font-tech">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-100 font-display truncate">{selectedCat.name}</span>
                  <span className="text-emerald-400 font-semibold tabular-nums text-[11px]">
                    {playerStats ? Math.round(playerStats.hp) : 100} / {playerStats ? playerStats.maxHp : 100}
                  </span>
                </div>
                {/* HP Bar */}
                <div className="w-full h-2 bg-[#050914] rounded overflow-hidden border border-emerald-950">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-green-400 transition-all duration-100 shadow-sm"
                    style={{
                      width: `${playerStats ? Math.max(0, (playerStats.hp / playerStats.maxHp) * 100) : 100}%`,
                    }}
                  />
                </div>
                {/* Armor Bar */}
                <div className="w-full h-1.5 bg-[#050914] rounded overflow-hidden border border-blue-950">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-100 shadow-sm"
                    style={{
                      width: `${playerStats ? Math.max(0, (playerStats.armor / playerStats.maxArmor) * 100) : 100}%`,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Dynamic Mission Objectives HUD */}
            <MissionObjectivesHUD
              zone={currentZone}
              missionIndex={missionIndex}
              currentWave={engineRef.current?.currentWave || 1}
              maxWaves={engineRef.current?.maxWaves || 3}
              waveEnemiesRemaining={engineRef.current?.waveEnemiesRemaining || 0}
              boss={engineRef.current?.boss || null}
              playerStats={playerStats}
              comboCount={engineRef.current?.comboCount || 0}
              coinsEarned={engineRef.current?.coinsEarned || 0}
              forceCompact={hudMode === 'compact'}
            />
          </div>

          {/* Center: Sector Radar Telemetry Banner (Desktop / Tablet) */}
          <div className="hidden lg:flex items-center gap-4 bg-[#090e1c]/90 backdrop-blur border border-slate-800 rounded-xl px-4 py-2 text-xs font-tech text-slate-200 tactical-border-cyan shadow-xl pointer-events-auto">
            <div className="flex items-center gap-1.5">
              <Radar className="w-4 h-4 text-cyan-400" />
              <span>ZON {zoneId} · UPPD 0{missionIndex}</span>
            </div>
            <div className="w-px h-4 bg-slate-800" />
            <div className="text-amber-400 font-bold uppercase">
              VÅG {engineRef.current ? engineRef.current.currentWave : 1} / {engineRef.current ? engineRef.current.maxWaves : 3}
            </div>
          </div>

          {/* Top-Right: Collectibles & Controls + Tactical Minimap */}
          <div className="flex flex-col gap-2 items-end pointer-events-auto">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-3 bg-[#090e1c]/90 backdrop-blur border border-slate-800 rounded-xl px-3 py-1.5 text-xs font-tech font-bold shadow-xl">
                <span className="text-amber-400 flex items-center gap-1">
                  🪙 {engineRef.current?.coinsEarned || 0}
                </span>
                <span className="text-slate-700">|</span>
                <span className="text-cyan-400 flex items-center gap-1">
                  ⚙️ {engineRef.current?.scrapEarned || 0}
                </span>
              </div>

              <button
                onClick={() => setHudMode((m) => (m === 'compact' ? 'full' : 'compact'))}
                className={`p-2 rounded-lg border backdrop-blur transition-all cursor-pointer ${
                  hudMode === 'compact'
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-500/20'
                    : 'bg-[#090e1c]/90 border-slate-800 text-slate-400 hover:text-white'
                }`}
                title={hudMode === 'compact' ? 'HUD: Kompakt stridsläge (klicka för Full Taktik)' : 'HUD: Full Taktik (klicka för Kompakt)'}
              >
                <SlidersHorizontal className="w-4 h-4" />
              </button>

              <button
                onClick={toggleAutoAim}
                className={`p-2 rounded-lg border backdrop-blur transition-all cursor-pointer ${
                  autoAim
                    ? 'bg-amber-500/20 border-amber-500 text-amber-400 shadow-md shadow-amber-500/20'
                    : 'bg-[#090e1c]/90 border-slate-800 text-slate-400 hover:text-white'
                }`}
                title="Växla Auto-Sikte"
              >
                <Crosshair className="w-4 h-4" />
              </button>

              <button
                onClick={toggleSound}
                className="p-2 bg-[#090e1c]/90 border border-slate-800 rounded-lg text-slate-300 hover:text-white backdrop-blur transition-colors cursor-pointer"
                title="Växla Ljud"
              >
                {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
              </button>

              <button
                onClick={() => setIsPaused(true)}
                className="p-2 bg-[#090e1c]/90 border border-slate-800 rounded-lg text-slate-300 hover:text-white backdrop-blur transition-colors cursor-pointer"
                title="Pausa"
              >
                <Pause className="w-4 h-4" />
              </button>
            </div>

            {/* Tactical Radar Minimap */}
            <TacticalMinimap
              engineRef={engineRef}
              currentWave={engineRef.current?.currentWave || 1}
              maxWaves={engineRef.current?.maxWaves || 3}
              forceCompact={hudMode === 'compact'}
            />
          </div>
        </div>

        {/* Boss Health Bar Banner (if Boss Active) */}
        {engineRef.current?.boss && (
          <div className="w-full max-w-md mx-auto mt-1 bg-[#090e1c]/95 border border-rose-500/50 rounded-xl p-2.5 shadow-2xl backdrop-blur pointer-events-auto tactical-border">
            <div className="flex justify-between items-center text-xs mb-1.5 font-bold font-tech">
              <span className="text-rose-400 flex items-center gap-1.5 font-display">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <span>{engineRef.current.boss.name}</span>
              </span>
              <span className="text-slate-300 font-mono">
                {Math.round((engineRef.current.boss.hp / engineRef.current.boss.maxHp) * 100)}%
              </span>
            </div>
            <div className="w-full h-2 bg-[#050914] rounded overflow-hidden border border-rose-950">
              <div
                className="h-full bg-gradient-to-r from-rose-600 via-orange-500 to-amber-400 transition-all duration-75 shadow-sm"
                style={{
                  width: `${Math.max(0, (engineRef.current.boss.hp / engineRef.current.boss.maxHp) * 100)}%`,
                }}
              />
            </div>
          </div>
        )}
      </div>

      {/* 1. Low Health Critical Warning Vignette */}
      {playerStats && playerStats.hp / playerStats.maxHp < 0.35 && (
        <div className="absolute inset-0 pointer-events-none z-15 border-[10px] border-rose-600/35 animate-pulse bg-radial from-transparent via-transparent to-rose-950/40" />
      )}

      {/* 2. Damage Flash Screen Overlay */}
      {engineRef.current && engineRef.current.playerHitFlashTimer > 0 && (
        <div className="absolute inset-0 pointer-events-none z-15 bg-rose-600/20 backdrop-brightness-110" />
      )}

      {/* 3. Boss Incoming Alert Warning Banner */}
      {engineRef.current && engineRef.current.bossWarningTimer > 0 && engineRef.current.boss && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-40 w-full max-w-lg px-4 pointer-events-none animate-bounce">
          <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-rose-950 border-2 border-rose-500 rounded-2xl p-4 shadow-2xl text-center backdrop-blur-md">
            <div className="text-[11px] font-tech font-black tracking-widest text-rose-300 uppercase flex items-center justify-center gap-2">
              <span className="animate-ping">⚠️</span>
              <span>VARNING: EXTREMT APEX-HOT UPPTÄCKT</span>
              <span className="animate-ping">⚠️</span>
            </div>
            <div className="text-xl sm:text-2xl font-display font-black text-rose-200 mt-1 uppercase tracking-wider drop-shadow-lg">
              {engineRef.current.boss.name} ENTRAR ARENAN!
            </div>
          </div>
        </div>
      )}

      {/* 4. Dynamic Combo Streak Badge */}
      {engineRef.current && engineRef.current.comboCount >= 3 && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-25 pointer-events-none font-tech flex flex-col items-center">
          <div className="bg-[#090e1c]/95 border-2 border-amber-500/60 rounded-xl px-4 py-2 shadow-2xl flex items-center gap-2.5 backdrop-blur-md animate-pulse">
            <span className="text-xl">🔥</span>
            <div>
              <div className="text-xs font-black text-amber-400 uppercase tracking-wide">
                {engineRef.current.comboCount}X KOMBO-STRIKE!
              </div>
              <div className="w-24 h-1.5 bg-slate-900 rounded-full overflow-hidden mt-1 border border-amber-950">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-orange-400 transition-all duration-75"
                  style={{ width: `${Math.min(100, (engineRef.current.comboTimer / 2.8) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Central Reload Indicator */}
      {playerStats?.isReloading && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none bg-slate-950/85 backdrop-blur-md border border-amber-500/60 px-5 py-2.5 rounded-2xl flex items-center gap-2.5 font-tech shadow-2xl shadow-amber-500/20">
          <RotateCcw className="w-5 h-5 text-amber-400 animate-spin" />
          <span className="text-xs font-bold text-amber-300 uppercase tracking-widest font-mono">
            Laddar om magasinet...
          </span>
        </div>
      )}

      {/* 6. Active Weapon Stats & Telemetry HUD Overlay (Bottom-Left) */}
      <div className="absolute bottom-4 sm:bottom-6 left-4 sm:left-6 z-20 pointer-events-none">
        <div className="pointer-events-auto inline-block">
          <ActiveWeaponStatsHUD
            weapon={selectedWeapon}
            effectiveStats={effectiveWeaponStats}
            playerStats={playerStats}
            forceCompact={hudMode === 'compact'}
          />
        </div>
      </div>

      {/* VIRTUAL JOYSTICK (Left Screen on Touch) */}
      {joystickTouch.active && (
        <div
          className="fixed pointer-events-none rounded-full border-2 border-amber-500/40 bg-[#090e1c]/40 z-20"
          style={{
            left: joystickTouch.startX - 50,
            top: joystickTouch.startY - 50,
            width: 100,
            height: 100,
          }}
        >
          <div
            className="absolute rounded-full bg-amber-500/90 shadow-lg shadow-amber-500/40"
            style={{
              left: joystickTouch.currentX - joystickTouch.startX + 25,
              top: joystickTouch.currentY - joystickTouch.startY + 25,
              width: 50,
              height: 50,
            }}
          />
        </div>
      )}

      {/* MOBILE ACTION BUTTONS (Right Screen Cluster) */}
      <div className="absolute bottom-6 right-6 flex flex-col items-end gap-3.5 pointer-events-auto z-20 font-tech">
        {/* Upper Action Row: Skill & Dodge */}
        <div className="flex items-center gap-3">
          {/* Special Skill Button */}
          <button
            onClick={() => engineRef.current?.triggerSkill()}
            disabled={playerStats ? playerStats.skillCooldownRemaining > 0 : false}
            className={`relative w-14 h-14 rounded-xl border flex flex-col items-center justify-center font-bold text-xs shadow-xl transition-all active:scale-95 cursor-pointer ${
              playerStats && playerStats.skillCooldownRemaining > 0
                ? 'bg-[#090e1c]/90 border-slate-800 text-slate-500'
                : 'bg-gradient-to-tr from-purple-700 to-indigo-600 border-indigo-400 text-white shadow-purple-500/30'
            }`}
          >
            <Zap className="w-5 h-5 mb-0.5" />
            {playerStats && playerStats.skillCooldownRemaining > 0 ? (
              <span className="text-[10px] font-mono font-bold text-amber-400">
                {Math.ceil(playerStats.skillCooldownRemaining)}s
              </span>
            ) : (
              <span className="text-[9px] uppercase tracking-tighter">Skill</span>
            )}
          </button>

          {/* Dodge Roll Button */}
          <button
            onClick={() => engineRef.current?.triggerDodge()}
            disabled={playerStats ? playerStats.dodgeCooldownRemaining > 0 : false}
            className={`relative w-14 h-14 rounded-xl border flex flex-col items-center justify-center font-bold text-xs shadow-xl transition-all active:scale-95 cursor-pointer ${
              playerStats && playerStats.dodgeCooldownRemaining > 0
                ? 'bg-[#090e1c]/90 border-slate-800 text-slate-500'
                : 'bg-gradient-to-tr from-cyan-600 to-blue-500 border-cyan-400 text-white shadow-cyan-500/30'
            }`}
          >
            <Wind className="w-5 h-5 mb-0.5" />
            {playerStats && playerStats.dodgeCooldownRemaining > 0 ? (
              <span className="text-[10px] font-mono font-bold text-amber-400">
                {Math.ceil(playerStats.dodgeCooldownRemaining)}s
              </span>
            ) : (
              <span className="text-[9px] uppercase tracking-tighter">Undvik</span>
            )}
          </button>
        </div>

        {/* Lower Action Row: Reload & Fire */}
        <div className="flex items-center gap-3">
          {/* Reload Button */}
          <button
            onClick={() => engineRef.current?.triggerReload()}
            disabled={playerStats?.isReloading}
            className="w-14 h-14 rounded-xl bg-[#090e1c]/90 border border-slate-700 flex flex-col items-center justify-center text-xs shadow-xl transition-all active:scale-95 cursor-pointer"
          >
            <RotateCcw
              className={`w-4 h-4 text-slate-300 mb-0.5 ${
                playerStats?.isReloading ? 'animate-spin text-amber-400' : ''
              }`}
            />
            <span className="text-[10px] font-mono text-slate-200">
              {playerStats?.ammo}/{playerStats?.maxAmmo}
            </span>
          </button>

          {/* Big Fire Button */}
          <button
            onMouseDown={() => {
              if (engineRef.current) engineRef.current.isShooting = true;
            }}
            onMouseUp={() => {
              if (engineRef.current) engineRef.current.isShooting = false;
            }}
            onTouchStart={() => {
              if (engineRef.current) engineRef.current.isShooting = true;
            }}
            onTouchEnd={() => {
              if (engineRef.current) engineRef.current.isShooting = false;
            }}
            className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-600 to-orange-600 border-2 border-amber-300 flex flex-col items-center justify-center text-slate-950 font-black shadow-2xl shadow-amber-500/40 active:scale-95 cursor-pointer"
          >
            <Crosshair className="w-8 h-8" />
            <span className="text-[10px] uppercase font-tech font-bold tracking-wider">SKJUT</span>
          </button>
        </div>
      </div>

      {/* PAUSE MODAL */}
      {isPaused && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50">
          <div className="w-full max-w-sm bg-[#090e1c] border border-amber-500/30 rounded-xl p-6 shadow-2xl space-y-4 text-center tactical-border">
            <h2 className="text-xl font-bold text-slate-100 font-display">Stridsinsats Pausad</h2>
            <p className="text-xs text-slate-400 font-tech">
              Kattkrigarna avvaktar taktiska order i skydd.
            </p>

            <div className="space-y-2 pt-2 font-tech">
              <button
                onClick={() => setIsPaused(false)}
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/20"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>Fortsätt Strida</span>
              </button>

              <button
                onClick={toggleSound}
                className="w-full py-2.5 bg-[#050914] border border-slate-800 hover:bg-slate-800 text-slate-200 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
                <span>Ljud: {soundEnabled ? 'PÅ' : 'AV'}</span>
              </button>

              <button
                onClick={() => onExit()}
                className="w-full py-2.5 bg-rose-950/40 border border-rose-900/60 hover:bg-rose-900/60 text-rose-300 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Home className="w-4 h-4" />
                <span>Avbryt & Gå till Huvudmeny</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VICTORY MODAL */}
      {victoryStats && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50">
          <div className="w-full max-w-md bg-[#090e1c] border border-amber-500/50 rounded-xl p-6 shadow-2xl text-center space-y-4 tactical-border">
            <div className="w-14 h-14 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-center mx-auto text-3xl text-amber-400">
              🏆
            </div>
            <div>
              <h2 className="text-xl font-black text-amber-400 tracking-wide font-display">
                SEKTOR SÄKRAD // SEGER
              </h2>
              <p className="text-xs text-slate-400 mt-1 font-tech">
                Kattkrigarna eliminerade alla muterade fientliga mål i området.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2 bg-[#050914] p-3 rounded-lg border border-slate-800 font-tech text-xs">
              <div>
                <div className="text-slate-500 uppercase text-[10px]">Nedkämpade</div>
                <div className="text-base font-bold text-slate-100">{victoryStats.kills}</div>
              </div>
              <div>
                <div className="text-amber-500 uppercase text-[10px]">Krediter</div>
                <div className="text-base font-bold text-amber-400">+{victoryStats.coins}</div>
              </div>
              <div>
                <div className="text-cyan-500 uppercase text-[10px]">Vapendelar</div>
                <div className="text-base font-bold text-cyan-400">+{victoryStats.scrap}</div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="space-y-2 pt-2 font-tech">
              <button
                onClick={() =>
                  onExit(
                    {
                      coins: victoryStats.coins,
                      scrap: victoryStats.scrap,
                      score: victoryStats.score,
                      won: true,
                    },
                    'NEXT'
                  )
                }
                className="w-full py-3 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold uppercase tracking-wider rounded-xl text-xs transition-all shadow-xl shadow-amber-500/25 active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>
                  {missionIndex === 3 ? 'Gå Vidare till Nästa Zon 🚀' : `Nästa Uppdrag (0${missionIndex + 1}) ➡️`}
                </span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() =>
                    onExit(
                      {
                        coins: victoryStats.coins,
                        scrap: victoryStats.scrap,
                        score: victoryStats.score,
                        won: true,
                      },
                      'RETRY'
                    )
                  }
                  className="py-2.5 bg-[#050914] border border-amber-500/40 hover:bg-amber-500/10 text-amber-300 font-bold uppercase tracking-wider rounded-lg text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Spela Igen</span>
                </button>

                <button
                  onClick={() =>
                    onExit(
                      {
                        coins: victoryStats.coins,
                        scrap: victoryStats.scrap,
                        score: victoryStats.score,
                        won: true,
                      },
                      'MENU'
                    )
                  }
                  className="py-2.5 bg-[#050914] border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold uppercase tracking-wider rounded-lg text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Home className="w-3.5 h-3.5" />
                  <span>Kommandocentral</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* GAME OVER MODAL */}
      {gameOverStats && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50">
          <div className="w-full max-w-md bg-[#090e1c] border border-rose-500/50 rounded-xl p-6 shadow-2xl text-center space-y-4 tactical-border">
            <div className="w-14 h-14 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center justify-center mx-auto text-3xl text-rose-500">
              💀
            </div>
            <div>
              <h2 className="text-xl font-black text-rose-500 tracking-wide font-display">
                KATTKRIGAREN FÖLL I STRID
              </h2>
              <p className="text-xs text-slate-400 mt-1 font-tech">
                Mutanternas horder övermannade positionen. Samla nya krafter och uppgradera arsenalförrådet.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-[#050914] p-3 rounded-lg border border-slate-800 font-tech text-xs">
              <div>
                <div className="text-slate-500 uppercase text-[10px]">Nedkämpade Fiender</div>
                <div className="text-base font-bold text-slate-100">{gameOverStats.kills}</div>
              </div>
              <div>
                <div className="text-amber-500 uppercase text-[10px]">Bärgade Krediter</div>
                <div className="text-base font-bold text-amber-400">+{gameOverStats.coins}</div>
              </div>
            </div>

            <div className="space-y-2 pt-2 font-tech">
              <button
                onClick={() =>
                  onExit(
                    {
                      coins: gameOverStats.coins,
                      scrap: gameOverStats.scrap,
                      score: gameOverStats.score,
                      won: false,
                    },
                    'RETRY'
                  )
                }
                className="w-full py-3 bg-gradient-to-r from-rose-600 via-rose-500 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold uppercase tracking-wider rounded-xl text-xs transition-all shadow-xl shadow-rose-600/25 active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Försök Igen (Snabbstart)</span>
              </button>

              <button
                onClick={() =>
                  onExit(
                    {
                      coins: gameOverStats.coins,
                      scrap: gameOverStats.scrap,
                      score: gameOverStats.score,
                      won: false,
                    },
                    'MENU'
                  )
                }
                className="w-full py-2.5 bg-[#050914] border border-slate-700 hover:bg-slate-800 text-slate-300 font-semibold uppercase tracking-wider rounded-lg text-xs transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Home className="w-4 h-4" />
                <span>Återvänd till Huvudmenyn</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
