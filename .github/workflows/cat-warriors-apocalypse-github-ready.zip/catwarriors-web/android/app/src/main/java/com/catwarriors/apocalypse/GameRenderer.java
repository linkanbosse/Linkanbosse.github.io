package com.catwarriors.apocalypse;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.List;

public class GameRenderer {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public void render(Canvas canvas, Camera camera, Player player,
                       List<Projectile> projectiles, List<Enemy> enemies,
                       Boss boss, ParticleSystem particles) {
        // Clear background
        canvas.drawColor(0xFF0F172A);

        canvas.save();
        canvas.translate(-camera.x, -camera.y);

        // Render Arena Grid
        paint.setColor(0xFF1E293B);
        paint.setStrokeWidth(2);
        for (int x = -1400; x <= 1400; x += 100) {
            canvas.drawLine(x, -1400, x, 1400, paint);
        }
        for (int y = -1400; y <= 1400; y += 100) {
            canvas.drawLine(-1400, y, 1400, y, paint);
        }

        // Render Enemies
        for (Enemy e : enemies) {
            if (!e.active) continue;
            paint.setColor(e.hitFlashTimer > 0 ? 0xFFFFFFFF : 0xFF71717A);
            canvas.drawCircle(e.x, e.y, e.radius, paint);
        }

        // Render Boss
        if (boss != null && boss.active) {
            paint.setColor(boss.hitFlashTimer > 0 ? 0xFFFFFFFF : 0xFFDC2626);
            canvas.drawCircle(boss.x, boss.y, boss.radius, paint);
        }

        // Render Player Cat
        paint.setColor(0xFF3B82F6);
        canvas.drawCircle(player.x, player.y, 18, paint);
        // Cat Ears
        paint.setColor(0xFFD97706);
        Path earPath = new Path();
        earPath.moveTo(player.x - 10, player.y - 12);
        earPath.lineTo(player.x - 16, player.y - 24);
        earPath.lineTo(player.x - 4, player.y - 14);
        canvas.drawPath(earPath, paint);

        // Render Projectiles
        for (Projectile p : projectiles) {
            if (!p.active) continue;
            paint.setColor(p.color);
            canvas.drawCircle(p.x, p.y, p.radius, paint);
        }

        // Render Particles
        particles.render(canvas, camera);

        canvas.restore();

        // Render HUD (HP, Armor, Ammo)
        paint.setColor(0xFFEF4444);
        canvas.drawRect(40, 40, 40 + (player.hp / player.maxHp) * 200, 60, paint);
        paint.setColor(0xFF3B82F6);
        canvas.drawRect(40, 66, 40 + (player.armor / player.maxArmor) * 200, 78, paint);
    }
}
