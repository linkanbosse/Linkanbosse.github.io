import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ANDROID_PROJECT_FILES } from '../src/android-project/files';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const androidRoot = path.join(__dirname, '../android');

for (const file of ANDROID_PROJECT_FILES) {
  const fullPath = path.join(androidRoot, file.path);
  const dir = path.dirname(fullPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(fullPath, file.content, 'utf8');
  console.log(`Exported: ${file.path}`);
}

console.log('All 30 Android project files written to disk in /android/ successfully!');
