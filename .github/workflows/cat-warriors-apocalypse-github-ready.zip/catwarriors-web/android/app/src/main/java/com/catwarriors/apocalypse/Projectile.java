package com.catwarriors.apocalypse;

public class Projectile {
    public float x;
    public float y;
    public float vx;
    public float vy;
    public float damage;
    public float rangeRemaining;
    public float radius;
    public int color;
    public boolean fromPlayer;
    public int penetrationRemaining;
    public boolean isExplosive;
    public float explosionRadius;
    public boolean active = true;

    public Projectile(float x, float y, float vx, float vy, float damage, float range,
                      float radius, int color, boolean fromPlayer, int penetration,
                      boolean isExplosive, float explosionRadius) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.damage = damage;
        this.rangeRemaining = range;
        this.radius = radius;
        this.color = color;
        this.fromPlayer = fromPlayer;
        this.penetrationRemaining = penetration;
        this.isExplosive = isExplosive;
        this.explosionRadius = explosionRadius;
    }

    public void update(float dt) {
        float dx = vx * dt;
        float dy = vy * dt;
        x += dx;
        y += dy;
        rangeRemaining -= (float) Math.hypot(dx, dy);
        if (rangeRemaining <= 0) {
            active = false;
        }
    }
}
