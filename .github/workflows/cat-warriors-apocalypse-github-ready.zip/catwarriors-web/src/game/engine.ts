import {
  PlayerStats,
  Projectile,
  EnemyInstance,
  EnemyType,
  BossInstance,
  Particle,
  FloatingText,
  PickupItem,
  Zone,
  PlayerProfile,
  WeaponCombatStats,
  calculateEffectiveWeaponStats,
} from '../types/game';
import { CAT_WARRIORS, WEAPONS, ENEMY_DEFINITIONS, BOSS_DEFINITIONS, ZONES } from './constants';
import { sound } from './audio';

export interface GameEngineCallbacks {
  onGameOver: (stats: { kills: number; coins: number; scrap: number; score: number }) => void;
  onVictory: (stats: { kills: number; coins: number; scrap: number; score: number }) => void;
  onStatsUpdate: (player: PlayerStats) => void;
}

export class GameEngine {
  public player: PlayerStats;
  public projectiles: Projectile[] = [];
  public enemies: EnemyInstance[] = [];
  public boss: BossInstance | null = null;
  public particles: Particle[] = [];
  public floatingTexts: FloatingText[] = [];
  public pickups: PickupItem[] = [];
  public drones: { x: number; y: number; angle: number; timer: number }[] = [];

  public currentZone: Zone;
  public missionIndex: number;
  public currentWave: number = 1;
  public maxWaves: number = 3;
  public waveEnemiesRemaining: number = 0;
  public isWaveSpawning: boolean = false;
  public nextWaveTimer: number = 0;

  public cameraX: number = 0;
  public cameraY: number = 0;
  public screenShake: number = 0;

  public kills: number = 0;
  public coinsEarned: number = 0;
  public scrapEarned: number = 0;
  public score: number = 0;
  public comboCount: number = 0;
  public comboTimer: number = 0;
  public playerHitFlashTimer: number = 0;
  public bossWarningTimer: number = 0;

  private projectileIdCounter = 1;
  private enemyIdCounter = 1;
  private textIdCounter = 1;
  private pickupIdCounter = 1;

  private fireCooldown: number = 0;
  private callbacks: GameEngineCallbacks;
  private isEnded: boolean = false;
  public gameTime: number = 0;
  private statsThrottleTimer: number = 0;

  // Active inputs
  public moveDir = { x: 0, y: 0 };
  public aimDir = { x: 1, y: 0 };
  public isShooting: boolean = false;
  public autoAim: boolean = true;
  public effectiveWeaponStats: WeaponCombatStats;

  constructor(profile: PlayerProfile, zoneId: number, missionIndex: number, callbacks: GameEngineCallbacks) {
    this.callbacks = callbacks;
    this.missionIndex = Math.max(1, missionIndex || 1);
    this.currentZone = ZONES.find((z) => z.id === zoneId) || ZONES[0];
    this.autoAim = profile?.settings?.autoAim ?? true;

    const catId = profile?.selectedCat || 'assault';
    const weaponId = profile?.selectedWeapon || 'assault_rifle';

    const cat = CAT_WARRIORS.find((c) => c.id === catId) || CAT_WARRIORS[0];
    const weapon = WEAPONS.find((w) => w.id === weaponId) || WEAPONS[0];

    const weaponLevels = profile?.weaponLevels || {};
    const weaponLevel = weaponLevels[weapon.id] || 1;

    const gearUpgrades = profile?.gearUpgrades || { helmet: 0, vest: 0, boots: 0, modchip: 0 };
    const rebirthMultiplier = profile?.rebirthMultiplier || 1.0;

    // Calculate real effective stats impacting combat (damage, rate of fire, reload speed)
    this.effectiveWeaponStats = calculateEffectiveWeaponStats(
      weapon,
      weaponLevel,
      gearUpgrades.modchip || 0
    );

    // Apply Rebirth damage boost
    this.effectiveWeaponStats.damage = Math.round(this.effectiveWeaponStats.damage * rebirthMultiplier);
    this.effectiveWeaponStats.dps = Math.round(this.effectiveWeaponStats.dps * rebirthMultiplier);

    // Gear bonuses
    const extraHp = (gearUpgrades.vest || 0) * 25;
    const extraArmor = (gearUpgrades.helmet || 0) * 15;
    const extraSpeed = (gearUpgrades.boots || 0) * 12;

    this.player = {
      hp: cat.baseHp + extraHp,
      maxHp: cat.baseHp + extraHp,
      armor: cat.baseArmor + extraArmor,
      maxArmor: cat.baseArmor + extraArmor,
      speed: cat.baseSpeed + extraSpeed,
      x: 0,
      y: 0,
      angle: 0,
      currentCat: cat.id,
      currentWeapon: weapon.id,
      ammo: this.effectiveWeaponStats.magazineSize,
      maxAmmo: this.effectiveWeaponStats.magazineSize,
      isReloading: false,
      reloadProgress: 0,
      skillCooldownRemaining: 0,
      dodgeCooldownRemaining: 0,
      isDodging: false,
      dodgeDuration: 0.25,
      dodgeTimer: 0,
      isShooting: false,
      recoilOffset: 0,
      level: 1,
      xp: 0,
      nextLevelXp: 100,
    };

    // Spawn wave 1
    this.startWave(1);
  }

  public update(dt: number) {
    if (this.isEnded) return;

    this.gameTime += dt;

    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) {
        this.comboCount = 0;
      }
    }
    if (this.playerHitFlashTimer > 0) {
      this.playerHitFlashTimer = Math.max(0, this.playerHitFlashTimer - dt);
    }
    if (this.bossWarningTimer > 0) {
      this.bossWarningTimer = Math.max(0, this.bossWarningTimer - dt);
    }

    // 1. Player updates (Dodge, Cooldowns, Movement)
    this.updatePlayer(dt);

    // 2. Camera smooth tracking with shake
    this.updateCamera(dt);

    // 3. Firing & Auto-aim logic
    this.updateWeaponFiring(dt);

    // 4. Update Drones (Engineer / Drone skills)
    this.updateDrones(dt);

    // 5. Update Projectiles
    this.updateProjectiles(dt);

    // 6. Update Enemies & AI
    this.updateEnemies(dt);

    // 7. Update Boss
    this.updateBoss(dt);

    // 8. Update Pickups
    this.updatePickups(dt);

    // 9. Update Particles & Floating Text
    this.updateFX(dt);

    // 10. Check Wave Progression
    this.checkWaveProgress(dt);

    // 11. Notify UI (throttled to ~15fps for ultra-smooth performance without React lag)
    this.statsThrottleTimer += dt;
    if (this.statsThrottleTimer >= 0.066) {
      this.statsThrottleTimer = 0;
      try {
        this.callbacks.onStatsUpdate({ ...this.player });
      } catch (err) {
        console.warn('onStatsUpdate callback warning:', err);
      }
    }
  }

  private updatePlayer(dt: number) {
    // Cooldowns
    if (this.player.skillCooldownRemaining > 0) {
      this.player.skillCooldownRemaining = Math.max(0, this.player.skillCooldownRemaining - dt);
    }
    if (this.player.dodgeCooldownRemaining > 0) {
      this.player.dodgeCooldownRemaining = Math.max(0, this.player.dodgeCooldownRemaining - dt);
    }

    // Dodge handling
    if (this.player.isDodging) {
      this.player.dodgeTimer -= dt;
      if (this.player.dodgeTimer <= 0) {
        this.player.isDodging = false;
      }
    }

    // Movement
    let speed = this.player.speed;
    if (this.player.isDodging) {
      speed *= 2.4; // High velocity dash
    }

    const moveMag = Math.hypot(this.moveDir.x, this.moveDir.y);
    if (moveMag > 0.05) {
      const nx = this.moveDir.x / (moveMag > 1 ? moveMag : 1);
      const ny = this.moveDir.y / (moveMag > 1 ? moveMag : 1);
      this.player.x += nx * speed * dt;
      this.player.y += ny * speed * dt;

      // Arena boundary limits
      const mapLimit = 1400;
      this.player.x = Math.max(-mapLimit, Math.min(mapLimit, this.player.x));
      this.player.y = Math.max(-mapLimit, Math.min(mapLimit, this.player.y));
    }

    // Aim angle
    if (this.autoAim) {
      const nearest = this.getNearestTarget();
      if (nearest) {
        const dx = nearest.x - this.player.x;
        const dy = nearest.y - this.player.y;
        this.player.angle = Math.atan2(dy, dx);
      } else if (moveMag > 0.1) {
        this.player.angle = Math.atan2(this.moveDir.y, this.moveDir.x);
      }
    } else {
      const aimMag = Math.hypot(this.aimDir.x, this.aimDir.y);
      if (aimMag > 0.1) {
        this.player.angle = Math.atan2(this.aimDir.y, this.aimDir.x);
      } else if (moveMag > 0.1) {
        this.player.angle = Math.atan2(this.moveDir.y, this.moveDir.x);
      }
    }

    // Reload handling
    if (this.player.isReloading) {
      this.player.reloadProgress += dt / this.effectiveWeaponStats.reloadSpeed;
      if (this.player.reloadProgress >= 1) {
        this.player.isReloading = false;
        this.player.reloadProgress = 0;
        this.player.ammo = this.effectiveWeaponStats.magazineSize;
        sound.playReload();
      }
    }
  }

  private updateCamera(dt: number) {
    // Smooth lerp camera toward player
    this.cameraX += (this.player.x - this.cameraX) * 9 * dt;
    this.cameraY += (this.player.y - this.cameraY) * 9 * dt;

    // Decay screen shake
    if (this.screenShake > 0) {
      this.screenShake = Math.max(0, this.screenShake - dt * 25);
      const shakeOffset = (Math.random() - 0.5) * this.screenShake;
      this.cameraX += shakeOffset;
      this.cameraY += shakeOffset;
    }
  }

  public triggerDodge() {
    if (this.player.dodgeCooldownRemaining > 0 || this.player.isDodging) return;
    this.player.isDodging = true;
    this.player.dodgeTimer = this.player.dodgeDuration;
    this.player.dodgeCooldownRemaining = 1.4;

    // Dust & motion particles
    for (let i = 0; i < 8; i++) {
      this.particles.push({
        x: this.player.x + (Math.random() - 0.5) * 20,
        y: this.player.y + (Math.random() - 0.5) * 20,
        vx: (Math.random() - 0.5) * 60,
        vy: (Math.random() - 0.5) * 60,
        color: '#94a3b8',
        radius: 3.5,
        alpha: 0.7,
        life: 0,
        maxLife: 0.3,
      });
    }
  }

  public triggerReload() {
    if (this.player.isReloading || this.player.ammo === this.effectiveWeaponStats.magazineSize) return;
    this.player.isReloading = true;
    this.player.reloadProgress = 0;
    sound.playReload();
  }

  public triggerSkill() {
    if (this.player.skillCooldownRemaining > 0) return;
    const cat = CAT_WARRIORS.find((c) => c.id === this.player.currentCat) || CAT_WARRIORS[0];
    this.player.skillCooldownRemaining = cat.skillCooldown;
    sound.playSkill();
    this.addFloatingText(this.player.x, this.player.y - 45, `${cat.skillName.toUpperCase()}!`, cat.accentColor, 1.4);

    // Support diverse kitty skills
    if (cat.id === 'assault' || cat.id === 'tigger') {
      // Cluster Grenade / Yarn Bombs: 6 explosive projectiles
      for (let i = 0; i < 6; i++) {
        const angle = (i * Math.PI * 2) / 6;
        this.projectiles.push({
          id: this.projectileIdCounter++,
          x: this.player.x,
          y: this.player.y,
          vx: Math.cos(angle) * 360,
          vy: Math.sin(angle) * 360,
          damage: 85,
          rangeRemaining: 280,
          radius: 8,
          color: '#ef4444',
          fromPlayer: true,
          penetrationRemaining: 1,
          isExplosive: true,
          explosionRadius: 100,
        });
      }
    } else if (cat.id === 'tank' || cat.id === 'marshmallow' || cat.id === 'sir_paws') {
      // Shield & Repel
      this.player.armor = Math.min(this.player.maxArmor, this.player.armor + 70);
      for (const e of this.enemies) {
        const d = Math.hypot(e.x - this.player.x, e.y - this.player.y);
        if (d < 220) {
          const pushAngle = Math.atan2(e.y - this.player.y, e.x - this.player.x);
          e.x += Math.cos(pushAngle) * 90;
          e.y += Math.sin(pushAngle) * 90;
          this.applyDamageToEnemy(e, 45, false);
        }
      }
      this.screenShake = 16;
    } else if (cat.id === 'medic') {
      // Catnip Overdrive: Heal HP and slow foes
      this.player.hp = Math.min(this.player.maxHp, this.player.hp + 75);
      this.addFloatingText(this.player.x, this.player.y - 25, '+75 HP', '#22c55e', 1.3);
      for (const e of this.enemies) {
        e.speed *= 0.55;
      }
    } else if (cat.id === 'engineer' || cat.id === 'professor_paws') {
      // Sentry Drones: Summon 2 orbiting gun drones
      for (let d = 0; d < 2; d++) {
        this.drones.push({
          x: this.player.x + (d === 0 ? 40 : -40),
          y: this.player.y + 20,
          angle: 0,
          timer: 15,
        });
      }
    } else if (cat.id === 'shadow' || cat.id === 'simba' || cat.id === 'bob' || cat.id === 'ninja_nala') {
      // Shadow Dash / Pounce: Teleport and slice
      const dashDist = 220;
      const tx = this.player.x + Math.cos(this.player.angle) * dashDist;
      const ty = this.player.y + Math.sin(this.player.angle) * dashDist;
      for (const e of this.enemies) {
        const d = Math.hypot(e.x - this.player.x, e.y - this.player.y);
        if (d < dashDist + 50) {
          this.applyDamageToEnemy(e, 160, true);
        }
      }
      this.player.x = tx;
      this.player.y = ty;
      this.screenShake = 14;
    } else if (cat.id === 'captain_claws' || cat.id === 'zephyr') {
      // Buckshot Hurricane: 360 shotgun burst
      for (let i = 0; i < 16; i++) {
        const ang = (i * Math.PI * 2) / 16;
        this.projectiles.push({
          id: this.projectileIdCounter++,
          x: this.player.x,
          y: this.player.y,
          vx: Math.cos(ang) * 500,
          vy: Math.sin(ang) * 500,
          damage: 38,
          rangeRemaining: 340,
          radius: 6,
          color: '#f97316',
          fromPlayer: true,
          penetrationRemaining: 2,
          isExplosive: false,
        });
      }
    } else if (cat.id === 'bella' || cat.id === 'pumpkin') {
      // Napalm Torrent: Wildfire fan blast
      for (let i = -4; i <= 4; i++) {
        const ang = this.player.angle + i * 0.15;
        this.projectiles.push({
          id: this.projectileIdCounter++,
          x: this.player.x,
          y: this.player.y,
          vx: Math.cos(ang) * 440,
          vy: Math.sin(ang) * 440,
          damage: 35,
          rangeRemaining: 360,
          radius: 9,
          color: '#ef4444',
          fromPlayer: true,
          penetrationRemaining: 99,
          isExplosive: false,
          isFlamethrower: true,
        });
      }
    } else if (cat.id === 'thor' || cat.id === 'buster') {
      // Thunder Stomp / Seismic shockwave
      this.screenShake = 22;
      sound.playExplosion();
      for (const e of this.enemies) {
        const d = Math.hypot(e.x - this.player.x, e.y - this.player.y);
        if (d < 350) {
          this.applyDamageToEnemy(e, 120, true);
          e.speed *= 0.4;
        }
      }
    } else if (cat.id === 'sniper' || cat.id === 'shadowfax') {
      // Deadeye piercing beam
      for (let s = 0; s < 3; s++) {
        this.projectiles.push({
          id: this.projectileIdCounter++,
          x: this.player.x,
          y: this.player.y,
          vx: Math.cos(this.player.angle) * 1100,
          vy: Math.sin(this.player.angle) * 1100,
          damage: 280,
          rangeRemaining: 950,
          radius: 8,
          color: '#a855f7',
          fromPlayer: true,
          penetrationRemaining: 99,
          isExplosive: false,
        });
      }
    } else {
      // General Supercharge: Instant ammo replenish & radial burst
      this.player.ammo = this.effectiveWeaponStats.magazineSize;
      for (let i = 0; i < 8; i++) {
        const ang = (i * Math.PI * 2) / 8;
        this.projectiles.push({
          id: this.projectileIdCounter++,
          x: this.player.x,
          y: this.player.y,
          vx: Math.cos(ang) * 540,
          vy: Math.sin(ang) * 540,
          damage: 60,
          rangeRemaining: 400,
          radius: 6,
          color: '#38bdf8',
          fromPlayer: true,
          penetrationRemaining: 2,
          isExplosive: false,
        });
      }
    }
  }

  private updateWeaponFiring(dt: number) {
    if (this.fireCooldown > 0) {
      this.fireCooldown -= dt;
    }

    if (this.player.recoilOffset && this.player.recoilOffset > 0) {
      this.player.recoilOffset = Math.max(0, this.player.recoilOffset - dt * 22);
    }

    if (this.player.isReloading) {
      this.player.isShooting = false;
      return;
    }

    const weapon = WEAPONS.find((w) => w.id === this.player.currentWeapon) || WEAPONS[0];

    // Fire if shooting is pressed, or if auto-aim has a target in range
    let shouldFire = this.isShooting;
    if (this.autoAim && !shouldFire) {
      const nearest = this.getNearestTarget();
      if (nearest) {
        const dist = Math.hypot(nearest.x - this.player.x, nearest.y - this.player.y);
        if (dist <= weapon.range + 40) {
          shouldFire = true;
        }
      }
    }

    this.player.isShooting = shouldFire;

    if (shouldFire && this.fireCooldown <= 0) {
      if (this.player.ammo <= 0) {
        this.triggerReload();
        return;
      }

      this.player.ammo--;
      this.player.recoilOffset = 5.0;
      this.fireCooldown = 1 / Math.max(0.5, this.effectiveWeaponStats.fireRate);
      sound.playShoot(weapon.id);

      // Screen shake for heavy weapons
      if (weapon.isExplosive || weapon.category.includes('Shotgun') || weapon.category.includes('Heavy')) {
        this.screenShake = Math.min(22, this.screenShake + 5);
      }

      // Projectiles based on pellet count and spread
      const baseAngle = this.player.angle;
      for (let p = 0; p < weapon.pelletCount; p++) {
        const spreadOffset = (Math.random() - 0.5) * weapon.spread;
        const shotAngle = baseAngle + spreadOffset;
        const vx = Math.cos(shotAngle) * weapon.bulletSpeed;
        const vy = Math.sin(shotAngle) * weapon.bulletSpeed;

        this.projectiles.push({
          id: this.projectileIdCounter++,
          x: this.player.x + Math.cos(baseAngle) * 24,
          y: this.player.y + Math.sin(baseAngle) * 24,
          vx,
          vy,
          damage: this.effectiveWeaponStats.damage,
          rangeRemaining: weapon.range,
          radius: weapon.isExplosive ? 7 : weapon.category === 'Sniper' ? 5 : 4.5,
          color: weapon.bulletColor,
          fromPlayer: true,
          penetrationRemaining: weapon.penetration,
          isExplosive: weapon.isExplosive,
          explosionRadius: weapon.explosionRadius,
          isFlamethrower: weapon.isFlamethrower,
        });
      }

      // Auto reload if empty
      if (this.player.ammo <= 0) {
        this.triggerReload();
      }
    }
  }

  private updateDrones(dt: number) {
    for (let i = this.drones.length - 1; i >= 0; i--) {
      const drone = this.drones[i];
      drone.timer -= dt;
      if (drone.timer <= 0) {
        this.drones.splice(i, 1);
        continue;
      }

      const orbitSpeed = 2.2;
      const orbitDist = 65;
      const angle = this.gameTime * orbitSpeed + (i * Math.PI);
      drone.x = this.player.x + Math.cos(angle) * orbitDist;
      drone.y = this.player.y + Math.sin(angle) * orbitDist;

      // Shoot nearest enemy every ~0.25s
      if (Math.random() < dt * 4) {
        const nearest = this.getNearestTarget();
        if (nearest) {
          const aimAngle = Math.atan2(nearest.y - drone.y, nearest.x - drone.x);
          drone.angle = aimAngle;
          this.projectiles.push({
            id: this.projectileIdCounter++,
            x: drone.x,
            y: drone.y,
            vx: Math.cos(aimAngle) * 600,
            vy: Math.sin(aimAngle) * 600,
            damage: 22,
            rangeRemaining: 440,
            radius: 3.5,
            color: '#fb923c',
            fromPlayer: true,
            penetrationRemaining: 1,
            isExplosive: false,
          });
          sound.playShoot('smg');
        }
      }
    }
  }

  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      const dx = p.vx * dt;
      const dy = p.vy * dt;
      p.x += dx;
      p.y += dy;
      p.rangeRemaining -= Math.hypot(dx, dy);

      // Range expired
      if (p.rangeRemaining <= 0) {
        if (p.isExplosive) {
          this.detonateExplosive(p.x, p.y, p.damage, p.explosionRadius || 85, p.fromPlayer);
        }
        this.projectiles.splice(i, 1);
        continue;
      }

      // Player projectiles hitting enemies
      if (p.fromPlayer) {
        let hitSomething = false;

        // Check boss
        if (this.boss) {
          const dist = Math.hypot(p.x - this.boss.x, p.y - this.boss.y);
          if (dist < this.boss.radius + p.radius) {
            this.applyDamageToBoss(p.damage);
            p.penetrationRemaining--;
            hitSomething = true;
            if (p.isExplosive) {
              this.detonateExplosive(p.x, p.y, p.damage, p.explosionRadius || 85, true);
              p.penetrationRemaining = 0;
            }
          }
        }

        // Check regular enemies
        for (let j = this.enemies.length - 1; j >= 0; j--) {
          const enemy = this.enemies[j];
          const dist = Math.hypot(p.x - enemy.x, p.y - enemy.y);
          if (dist < enemy.radius + p.radius) {
            this.applyDamageToEnemy(enemy, p.damage);
            p.penetrationRemaining--;
            hitSomething = true;

            if (p.isExplosive) {
              this.detonateExplosive(p.x, p.y, p.damage, p.explosionRadius || 85, true);
              p.penetrationRemaining = 0;
              break;
            }

            if (p.penetrationRemaining <= 0) break;
          }
        }

        if (hitSomething && p.penetrationRemaining <= 0) {
          this.projectiles.splice(i, 1);
        }
      } else {
        // Enemy projectiles hitting player
        if (!this.player.isDodging) {
          const dist = Math.hypot(p.x - this.player.x, p.y - this.player.y);
          if (dist < 18 + p.radius) {
            this.applyDamageToPlayer(p.damage);
            this.projectiles.splice(i, 1);
          }
        }
      }
    }
  }

  private detonateExplosive(x: number, y: number, damage: number, radius: number, fromPlayer: boolean) {
    sound.playExplosion();
    this.screenShake = 18;

    // Explosion particles
    for (let i = 0; i < 24; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 60 + Math.random() * 260;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: i % 2 === 0 ? '#ef4444' : '#fbbf24',
        radius: 3 + Math.random() * 4.5,
        alpha: 0.9,
        life: 0,
        maxLife: 0.4 + Math.random() * 0.3,
      });
    }

    if (fromPlayer) {
      if (this.boss) {
        const d = Math.hypot(x - this.boss.x, y - this.boss.y);
        if (d < radius + this.boss.radius) {
          this.applyDamageToBoss(damage);
        }
      }
      for (const enemy of this.enemies) {
        const d = Math.hypot(x - enemy.x, y - enemy.y);
        if (d < radius + enemy.radius) {
          this.applyDamageToEnemy(enemy, damage);
        }
      }
    } else {
      if (!this.player.isDodging) {
        const d = Math.hypot(x - this.player.x, y - this.player.y);
        if (d < radius + 18) {
          this.applyDamageToPlayer(damage);
        }
      }
    }
  }

  private updateEnemies(dt: number) {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.hitFlashTimer > 0) e.hitFlashTimer -= dt;

      const dx = this.player.x - e.x;
      const dy = this.player.y - e.y;
      const dist = Math.hypot(dx, dy);

      e.angle = Math.atan2(dy, dx);

      // AI Logic
      if (e.isRanged) {
        if (dist > 250) {
          e.x += (dx / dist) * e.speed * dt;
          e.y += (dy / dist) * e.speed * dt;
        } else if (dist < 160) {
          e.x -= (dx / dist) * e.speed * 0.6 * dt;
          e.y -= (dy / dist) * e.speed * 0.6 * dt;
        }

        e.attackTimer -= dt;
        if (e.attackTimer <= 0) {
          const def = ENEMY_DEFINITIONS[e.type];
          e.attackTimer = def?.attackCooldown || 2.0;

          const pSpeed = def?.projectileSpeed || 280;
          this.projectiles.push({
            id: this.projectileIdCounter++,
            x: e.x,
            y: e.y,
            vx: Math.cos(e.angle) * pSpeed,
            vy: Math.sin(e.angle) * pSpeed,
            damage: e.damage,
            rangeRemaining: 420,
            radius: 5,
            color: def?.projectileColor || '#22c55e',
            fromPlayer: false,
            penetrationRemaining: 1,
            isExplosive: false,
          });
        }
      } else {
        // Melee charger
        e.x += (dx / dist) * e.speed * dt;
        e.y += (dy / dist) * e.speed * dt;

        if (dist < e.radius + 18 && !this.player.isDodging) {
          e.attackTimer -= dt;
          if (e.attackTimer <= 0) {
            e.attackTimer = 0.8;
            this.applyDamageToPlayer(e.damage);

            if (e.type === 'exploder') {
              this.detonateExplosive(e.x, e.y, e.damage, 90, false);
              this.enemies.splice(i, 1);
              continue;
            }
          }
        }
      }
    }
  }

  private updateBoss(dt: number) {
    if (!this.boss) return;

    if (this.boss.hitFlashTimer > 0) this.boss.hitFlashTimer -= dt;

    const dx = this.player.x - this.boss.x;
    const dy = this.player.y - this.boss.y;
    const dist = Math.hypot(dx, dy);

    this.boss.angle = Math.atan2(dy, dx);

    // Movement
    if (dist > 150) {
      this.boss.x += (dx / dist) * this.boss.speed * dt;
      this.boss.y += (dy / dist) * this.boss.speed * dt;
    }

    // Attacks
    this.boss.attackTimer -= dt;
    this.boss.specialTimer -= dt;

    // Standard attack
    if (this.boss.attackTimer <= 0) {
      this.boss.attackTimer = 1.8;
      for (let s = -1; s <= 1; s++) {
        const shotAngle = this.boss.angle + s * 0.25;
        this.projectiles.push({
          id: this.projectileIdCounter++,
          x: this.boss.x,
          y: this.boss.y,
          vx: Math.cos(shotAngle) * 320,
          vy: Math.sin(shotAngle) * 320,
          damage: 28,
          rangeRemaining: 600,
          radius: 7,
          color: '#f97316',
          fromPlayer: false,
          penetrationRemaining: 1,
          isExplosive: false,
        });
      }
    }

    // Special boss attack
    if (this.boss.specialTimer <= 0) {
      this.boss.specialTimer = 5.0;
      this.boss.isTelegraphing = true;
      this.boss.telegraphTimer = 0.8;
      sound.playBossRoar();

      setTimeout(() => {
        if (!this.boss) return;
        this.boss.isTelegraphing = false;
        // Radial 360 blast
        for (let a = 0; a < 12; a++) {
          const ang = (a * Math.PI * 2) / 12;
          this.projectiles.push({
            id: this.projectileIdCounter++,
            x: this.boss.x,
            y: this.boss.y,
            vx: Math.cos(ang) * 280,
            vy: Math.sin(ang) * 280,
            damage: 32,
            rangeRemaining: 550,
            radius: 8,
            color: '#dc2626',
            fromPlayer: false,
            penetrationRemaining: 1,
            isExplosive: true,
            explosionRadius: 60,
          });
        }
      }, 800);
    }
  }

  private updatePickups(dt: number) {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const item = this.pickups[i];
      item.duration -= dt;
      if (item.duration <= 0) {
        this.pickups.splice(i, 1);
        continue;
      }

      const dist = Math.hypot(this.player.x - item.x, this.player.y - item.y);
      if (dist < 150) {
        const pullAngle = Math.atan2(this.player.y - item.y, this.player.x - item.x);
        item.x += Math.cos(pullAngle) * 280 * dt;
        item.y += Math.sin(pullAngle) * 280 * dt;
      }

      if (dist < 28) {
        sound.playPickup();
        if (item.type === 'coin') {
          this.coinsEarned += item.value;
          this.addFloatingText(item.x, item.y, `+${item.value} 🪙`, '#eab308');
        } else if (item.type === 'scrap') {
          this.scrapEarned += item.value;
          this.addFloatingText(item.x, item.y, `+${item.value} ⚙️`, '#38bdf8');
        } else if (item.type === 'medkit') {
          this.player.hp = Math.min(this.player.maxHp, this.player.hp + item.value);
          this.addFloatingText(item.x, item.y, `+${item.value} HP`, '#22c55e');
        } else if (item.type === 'ammo') {
          this.player.ammo = this.effectiveWeaponStats.magazineSize;
          this.addFloatingText(item.x, item.y, 'AMMO MAX', '#3b82f6');
        }
        this.pickups.splice(i, 1);
      }
    }
  }

  private updateFX(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life += dt;
      pt.alpha = 1 - pt.life / pt.maxLife;
      if (pt.life >= pt.maxLife) {
        this.particles.splice(i, 1);
      }
    }

    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const t = this.floatingTexts[i];
      t.y += t.vy * dt;
      t.alpha -= dt * 1.4;
      if (t.alpha <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }
  }

  private applyDamageToPlayer(rawDamage: number) {
    sound.playCatHurt();
    this.screenShake = 14;
    this.playerHitFlashTimer = 0.22;

    let finalDmg = rawDamage;
    if (this.player.armor > 0) {
      const armorAbsorb = Math.min(this.player.armor, rawDamage * 0.6);
      this.player.armor -= armorAbsorb;
      finalDmg = rawDamage - armorAbsorb;
    }

    this.player.hp -= finalDmg;
    this.addFloatingText(this.player.x, this.player.y - 20, `-${Math.round(finalDmg)}`, '#ef4444', 1.2);

    if (this.player.hp <= 0) {
      this.player.hp = 0;
      this.isEnded = true;
      sound.playGameOver();
      try {
        this.callbacks.onGameOver({
          kills: this.kills,
          coins: this.coinsEarned,
          scrap: this.scrapEarned,
          score: this.score,
        });
      } catch (err) {
        console.warn('onGameOver callback error:', err);
      }
    }
  }

  private applyDamageToEnemy(enemy: EnemyInstance, damage: number, isCrit = false) {
    sound.playEnemyHit();
    enemy.hitFlashTimer = 0.08;

    const cat = CAT_WARRIORS.find((c) => c.id === this.player.currentCat) || CAT_WARRIORS[0];
    const rollCrit = isCrit || Math.random() < cat.critChance;
    const finalDamage = rollCrit ? Math.round(damage * 1.8) : damage;

    enemy.hp -= finalDamage;

    this.addFloatingText(
      enemy.x + (Math.random() - 0.5) * 14,
      enemy.y - 15,
      rollCrit ? `CRIT ${finalDamage}!` : `${finalDamage}`,
      rollCrit ? '#f59e0b' : '#ffffff',
      rollCrit ? 1.3 : 1.0
    );

    for (let p = 0; p < 4; p++) {
      this.particles.push({
        x: enemy.x,
        y: enemy.y,
        vx: (Math.random() - 0.5) * 120,
        vy: (Math.random() - 0.5) * 120,
        color: '#dc2626',
        radius: 2.5,
        alpha: 0.8,
        life: 0,
        maxLife: 0.25,
      });
    }

    if (enemy.hp <= 0) {
      this.onEnemyKilled(enemy);
    }
  }

  private applyDamageToBoss(damage: number) {
    if (!this.boss) return;
    sound.playEnemyHit();
    this.boss.hitFlashTimer = 0.08;

    this.boss.hp -= damage;
    this.addFloatingText(
      this.boss.x + (Math.random() - 0.5) * 30,
      this.boss.y - 30,
      `${damage}`,
      '#fbbf24',
      1.2
    );

    if (this.boss.hp <= 0) {
      this.onBossKilled();
    }
  }

  private onEnemyKilled(enemy: EnemyInstance) {
    const idx = this.enemies.indexOf(enemy);
    if (idx !== -1) this.enemies.splice(idx, 1);

    this.kills++;
    this.comboCount++;
    this.comboTimer = 2.8;

    if (this.comboCount >= 3) {
      let comboMsg = `${this.comboCount}X KOMBO!`;
      let comboColor = '#38bdf8';
      if (this.comboCount >= 20) {
        comboMsg = `${this.comboCount}X GUDOMLIG KATT! 🔥`;
        comboColor = '#f43f5e';
      } else if (this.comboCount >= 10) {
        comboMsg = `${this.comboCount}X OSTOPPBAR! ⚡`;
        comboColor = '#a855f7';
      } else if (this.comboCount >= 5) {
        comboMsg = `${this.comboCount}X PURR-FEKT! ✨`;
        comboColor = '#eab308';
      }
      if (this.comboCount % 3 === 0 || this.comboCount === 5 || this.comboCount === 10) {
        this.addFloatingText(this.player.x, this.player.y - 45, comboMsg, comboColor, 1.35);
      }
    }

    const def = ENEMY_DEFINITIONS[enemy.type] || ENEMY_DEFINITIONS.mutant_rat;
    this.score += (def?.scoreValue || 50) + this.comboCount * 5;

    // Loot drops
    if (Math.random() < (def?.coinDropChance || 0.5)) {
      this.pickups.push({
        id: this.pickupIdCounter++,
        type: 'coin',
        x: enemy.x,
        y: enemy.y,
        value: def?.coinDropAmount || 5,
        radius: 8,
        duration: 25,
      });
    }
    if (Math.random() < (def?.scrapDropChance || 0.2)) {
      this.pickups.push({
        id: this.pickupIdCounter++,
        type: 'scrap',
        x: enemy.x + 10,
        y: enemy.y,
        value: 1,
        radius: 9,
        duration: 25,
      });
    }
    if (Math.random() < 0.12) {
      this.pickups.push({
        id: this.pickupIdCounter++,
        type: 'medkit',
        x: enemy.x - 10,
        y: enemy.y,
        value: 35,
        radius: 10,
        duration: 20,
      });
    }
  }

  private onBossKilled() {
    if (!this.boss) return;
    this.boss = null;
    sound.playVictory();
    this.isEnded = true;

    this.coinsEarned += this.currentZone.boss.rewardCoins;
    this.scrapEarned += this.currentZone.boss.rewardScrap;

    try {
      this.callbacks.onVictory({
        kills: this.kills,
        coins: this.coinsEarned,
        scrap: this.scrapEarned,
        score: this.score + 2500,
      });
    } catch (err) {
      console.warn('onVictory callback error:', err);
    }
  }

  private startWave(waveNum: number) {
    this.currentWave = waveNum;
    this.isWaveSpawning = false;

    // Final mission & final wave = Boss Encounter!
    const isBossLevel = this.missionIndex === 3;
    if (isBossLevel && waveNum === this.maxWaves) {
      const bossDef = this.currentZone.boss || BOSS_DEFINITIONS.boss_rat_king;
      this.boss = {
        id: bossDef.id,
        name: bossDef.name,
        x: this.player.x + 350,
        y: this.player.y - 200,
        vx: 0,
        vy: 0,
        hp: bossDef.maxHp,
        maxHp: bossDef.maxHp,
        speed: bossDef.speed,
        phase: 1,
        radius: bossDef.radius,
        angle: 0,
        attackTimer: 2.0,
        specialTimer: 4.5,
        isTelegraphing: false,
        telegraphTimer: 0,
        telegraphType: 'circle',
        hitFlashTimer: 0,
      };
      sound.playBossRoar();
      this.bossWarningTimer = 3.5;
      this.addFloatingText(this.player.x, this.player.y - 80, `BOSS ENCOUNTER: ${bossDef.name.toUpperCase()}!`, '#ef4444', 1.8);
      return;
    }

    // Spawn wave of regular enemies
    const enemyCount = 6 + waveNum * 4 + this.missionIndex * 3;
    this.waveEnemiesRemaining = enemyCount;

    for (let i = 0; i < enemyCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 420 + Math.random() * 320;
      const ex = this.player.x + Math.cos(angle) * distance;
      const ey = this.player.y + Math.sin(angle) * distance;

      const types = this.currentZone.allowedEnemies && this.currentZone.allowedEnemies.length > 0
        ? this.currentZone.allowedEnemies
        : ['mutant_rat', 'zombie_cat'];
      const type = types[Math.floor(Math.random() * types.length)];
      const def = ENEMY_DEFINITIONS[type] || ENEMY_DEFINITIONS.mutant_rat;

      this.enemies.push({
        id: this.enemyIdCounter++,
        type: type as EnemyType,
        x: ex,
        y: ey,
        vx: 0,
        vy: 0,
        hp: def.hp,
        maxHp: def.hp,
        speed: def.speed,
        radius: def.radius,
        damage: def.damage,
        isRanged: def.isRanged,
        attackTimer: Math.random() * 1.5,
        hitFlashTimer: 0,
        angle: 0,
      });
    }
  }

  private checkWaveProgress(dt: number) {
    if (this.boss) return;

    if (this.enemies.length === 0 && !this.isEnded) {
      if (this.currentWave < this.maxWaves) {
        if (!this.isWaveSpawning) {
          this.isWaveSpawning = true;
          this.nextWaveTimer = 2.0;
          this.addFloatingText(this.player.x, this.player.y - 60, 'VÅG SLUTFÖRD!', '#22c55e', 1.5);
        } else {
          this.nextWaveTimer -= dt;
          if (this.nextWaveTimer <= 0) {
            this.startWave(this.currentWave + 1);
          }
        }
      } else {
        // Mission Victory!
        this.isEnded = true;
        sound.playVictory();
        try {
          this.callbacks.onVictory({
            kills: this.kills,
            coins: this.coinsEarned + 120,
            scrap: this.scrapEarned + 18,
            score: this.score + 1000,
          });
        } catch (err) {
          console.warn('onVictory callback error:', err);
        }
      }
    }
  }

  private getNearestTarget(): { x: number; y: number } | null {
    let nearest: { x: number; y: number } | null = null;
    let minDist = Infinity;

    if (this.boss) {
      const d = Math.hypot(this.boss.x - this.player.x, this.boss.y - this.player.y);
      if (d < 850) return this.boss;
    }

    for (const e of this.enemies) {
      const d = Math.hypot(e.x - this.player.x, e.y - this.player.y);
      if (d < minDist) {
        minDist = d;
        nearest = e;
      }
    }
    return nearest;
  }

  private addFloatingText(x: number, y: number, text: string, color: string, scale = 1.0) {
    this.floatingTexts.push({
      id: this.textIdCounter++,
      x,
      y,
      text,
      color,
      alpha: 1.0,
      scale,
      vy: -35,
    });
  }
}
