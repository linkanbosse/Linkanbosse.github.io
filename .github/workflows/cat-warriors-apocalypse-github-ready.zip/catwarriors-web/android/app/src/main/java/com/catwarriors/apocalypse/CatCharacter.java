package com.catwarriors.apocalypse;

public class CatCharacter {
    public String id;
    public String name;
    public String codename;
    public String role;
    public int baseHp;
    public int baseArmor;
    public float baseSpeed;
    public float critChance;
    public String skillName;
    public float skillCooldown;
    public String startingWeaponId;

    public CatCharacter(String id, String name, String codename, String role,
                        int baseHp, int baseArmor, float baseSpeed, float critChance,
                        String skillName, float skillCooldown, String startingWeaponId) {
        this.id = id;
        this.name = name;
        this.codename = codename;
        this.role = role;
        this.baseHp = baseHp;
        this.baseArmor = baseArmor;
        this.baseSpeed = baseSpeed;
        this.critChance = critChance;
        this.skillName = skillName;
        this.skillCooldown = skillCooldown;
        this.startingWeaponId = startingWeaponId;
    }
}
