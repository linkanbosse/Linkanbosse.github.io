package com.catwarriors.apocalypse;

import java.util.List;

public class MissionManager {
    public Level currentLevel;
    public int currentWave = 1;
    public boolean waveInProgress = false;

    public MissionManager(int zoneId, int missionIndex) {
        this.currentLevel = new Level(zoneId, "Zon " + zoneId, missionIndex, 3, missionIndex == 3);
    }

    public void spawnWave(Player player, List<Enemy> enemies, Boss[] bossRef) {
        if (currentLevel.isBossLevel && currentWave == currentLevel.totalWaves) {
            bossRef[0] = new Boss("boss_" + currentLevel.zoneId, "Zone Boss", 2500, 110, 50);
            return;
        }

        int count = 6 + currentWave * 4;
        for (int i = 0; i < count; i++) {
            double ang = Math.random() * Math.PI * 2;
            float dist = (float) (350 + Math.random() * 250);
            float ex = player.x + (float) Math.cos(ang) * dist;
            float ey = player.y + (float) Math.sin(ang) * dist;
            enemies.add(new Enemy(GameConstants.ENEMY_MUTANT_RAT, ex, ey, 50, 160, 20, 15, false, 1.0f));
        }
    }
}
