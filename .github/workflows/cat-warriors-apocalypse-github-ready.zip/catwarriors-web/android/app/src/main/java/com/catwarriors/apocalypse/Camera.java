package com.catwarriors.apocalypse;

public class Camera {
    public float x = 0;
    public float y = 0;
    public float shake = 0;

    public void update(float targetX, float targetY, float viewportW, float viewportH, float dt) {
        float desiredX = targetX - viewportW / 2;
        float desiredY = targetY - viewportH / 2;

        x += (desiredX - x) * 8 * dt;
        y += (desiredY - y) * 8 * dt;

        if (shake > 0) {
            shake = Math.max(0, shake - dt * 20);
            x += (Math.random() - 0.5f) * shake;
            y += (Math.random() - 0.5f) * shake;
        }
    }

    public void addShake(float amount) {
        shake = Math.min(25f, shake + amount);
    }
}
