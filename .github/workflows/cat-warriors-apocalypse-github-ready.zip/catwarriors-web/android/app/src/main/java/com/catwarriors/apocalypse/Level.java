package com.catwarriors.apocalypse;

public class Level {
    public int zoneId;
    public String zoneName;
    public int missionIndex;
    public int totalWaves;
    public boolean isBossLevel;

    public Level(int zoneId, String zoneName, int missionIndex, int totalWaves, boolean isBossLevel) {
        this.zoneId = zoneId;
        this.zoneName = zoneName;
        this.missionIndex = missionIndex;
        this.totalWaves = totalWaves;
        this.isBossLevel = isBossLevel;
    }
}
