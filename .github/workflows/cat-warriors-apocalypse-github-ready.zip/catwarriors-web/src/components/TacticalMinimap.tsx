import React, { useRef, useEffect, useState } from 'react';
import { GameEngine } from '../game/engine';
import { Radar, ZoomIn, ZoomOut, ChevronDown, ChevronUp } from 'lucide-react';

interface TacticalMinimapProps {
  engineRef: React.RefObject<GameEngine | null>;
  currentWave: number;
  maxWaves: number;
  forceCompact?: boolean;
}

export const TacticalMinimap: React.FC<TacticalMinimapProps> = ({
  engineRef,
  currentWave,
  maxWaves,
  forceCompact = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1); // 1 = 600m range, 0.5 = 1200m range
  const [enemyCount, setEnemyCount] = useState<number>(0);
  const [hasBoss, setHasBoss] = useState<boolean>(false);

  const collapsed = isCollapsed || forceCompact;

  useEffect(() => {
    let animId: number;
    let sweepAngle = 0;
    let lastEnemyUpdate = 0;

    const renderMinimap = () => {
      const canvas = canvasRef.current;
      const engine = engineRef.current;

      if (canvas && engine && !isCollapsed) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;
          const cx = w / 2;
          const cy = h / 2;
          const radarRadius = w / 2 - 4;

          // 1. Clear background
          ctx.clearRect(0, 0, w, h);

          // Radar circle background
          ctx.fillStyle = '#060a14ee';
          ctx.beginPath();
          ctx.arc(cx, cy, radarRadius, 0, Math.PI * 2);
          ctx.fill();

          // Radar perimeter ring
          ctx.strokeStyle = '#0284c7';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(cx, cy, radarRadius, 0, Math.PI * 2);
          ctx.stroke();

          // Range rings (1/3, 2/3, 3/3)
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.2)';
          ctx.lineWidth = 1;
          for (let r = 1; r <= 3; r++) {
            ctx.beginPath();
            ctx.arc(cx, cy, (radarRadius / 3) * r, 0, Math.PI * 2);
            ctx.stroke();
          }

          // Crosshairs (N, S, E, W axes)
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.25)';
          ctx.beginPath();
          ctx.moveTo(cx, cy - radarRadius);
          ctx.lineTo(cx, cy + radarRadius);
          ctx.moveTo(cx - radarRadius, cy);
          ctx.lineTo(cx + radarRadius, cy);
          ctx.stroke();

          // Cardinal markings (N, E, S, W)
          ctx.fillStyle = '#38bdf8';
          ctx.font = '8px monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('N', cx, cy - radarRadius + 7);
          ctx.fillText('S', cx, cy + radarRadius - 7);
          ctx.fillText('W', cx - radarRadius + 7, cy);
          ctx.fillText('E', cx + radarRadius - 7, cy);

          // Rotating radar sweep beam
          sweepAngle += 0.045;
          ctx.save();
          ctx.beginPath();
          ctx.arc(cx, cy, radarRadius, 0, Math.PI * 2);
          ctx.clip();

          // Sweep cone gradient
          const sweepGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, radarRadius);
          sweepGrad.addColorStop(0, 'rgba(6, 182, 212, 0.3)');
          sweepGrad.addColorStop(1, 'rgba(6, 182, 212, 0)');

          ctx.fillStyle = 'rgba(6, 182, 212, 0.12)';
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.arc(cx, cy, radarRadius, sweepAngle - 0.4, sweepAngle);
          ctx.closePath();
          ctx.fill();

          // Sweep leading line
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(
            cx + Math.cos(sweepAngle) * radarRadius,
            cy + Math.sin(sweepAngle) * radarRadius
          );
          ctx.stroke();
          ctx.restore();

          // World to Radar transformation:
          // Maximum world range mapped to radarRadius
          const maxWorldDist = 700 / zoomLevel;
          const px = engine.player.x;
          const py = engine.player.y;

          // 2. Plot Pickups (Coins = Gold, Scrap = Cyan, Medkit = Green)
          for (const item of engine.pickups) {
            const dx = item.x - px;
            const dy = item.y - py;
            const dist = Math.hypot(dx, dy);
            if (dist < maxWorldDist) {
              const mx = cx + (dx / maxWorldDist) * radarRadius;
              const my = cy + (dy / maxWorldDist) * radarRadius;

              if (item.type === 'coin') {
                ctx.fillStyle = '#facc15';
              } else if (item.type === 'scrap') {
                ctx.fillStyle = '#38bdf8';
              } else if (item.type === 'medkit') {
                ctx.fillStyle = '#22c55e';
              } else {
                ctx.fillStyle = '#e2e8f0';
              }
              ctx.beginPath();
              ctx.arc(mx, my, 2, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          // 3. Plot Enemies (Red blips)
          for (const enemy of engine.enemies) {
            const dx = enemy.x - px;
            const dy = enemy.y - py;
            const dist = Math.hypot(dx, dy);

            if (dist < maxWorldDist) {
              const mx = cx + (dx / maxWorldDist) * radarRadius;
              const my = cy + (dy / maxWorldDist) * radarRadius;

              // Enemy dot with glow
              ctx.fillStyle = enemy.isRanged ? '#f97316' : '#ef4444';
              ctx.beginPath();
              ctx.arc(mx, my, 2.5, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          // 4. Plot Boss (Large pulsing hazard diamond)
          if (engine.boss) {
            const dx = engine.boss.x - px;
            const dy = engine.boss.y - py;
            const dist = Math.hypot(dx, dy);

            // If boss is outside radar, clamp to edge with arrow pointer!
            const clampedDist = Math.min(dist, maxWorldDist - 12);
            const angle = Math.atan2(dy, dx);
            const bx = cx + (clampedDist / maxWorldDist) * radarRadius * Math.cos(angle);
            const by = cy + (clampedDist / maxWorldDist) * radarRadius * Math.sin(angle);

            // Boss beacon pulse
            const pulse = 1 + Math.sin(engine.gameTime * 6) * 0.3;
            ctx.fillStyle = 'rgba(239, 68, 68, 0.4)';
            ctx.beginPath();
            ctx.arc(bx, by, 7 * pulse, 0, Math.PI * 2);
            ctx.fill();

            // Boss icon
            ctx.fillStyle = '#dc2626';
            ctx.beginPath();
            ctx.arc(bx, by, 4.5, 0, Math.PI * 2);
            ctx.fill();

            ctx.strokeStyle = '#fee2e2';
            ctx.lineWidth = 1;
            ctx.stroke();
          }

          // 5. Plot Player (Center friendly green/cyan arrow)
          ctx.fillStyle = '#10b981';
          ctx.beginPath();
          ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
          ctx.fill();

          // Aim direction pointer
          const aimAngle = Math.atan2(engine.aimDir.y, engine.aimDir.x);
          ctx.strokeStyle = '#34d399';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(cx + Math.cos(aimAngle) * 8, cy + Math.sin(aimAngle) * 8);
          ctx.stroke();

          // Update enemy count throttled
          const now = performance.now();
          if (now - lastEnemyUpdate > 250) {
            lastEnemyUpdate = now;
            setEnemyCount(engine.enemies.length);
            setHasBoss(!!engine.boss);
          }
        }
      }

      animId = requestAnimationFrame(renderMinimap);
    };

    animId = requestAnimationFrame(renderMinimap);
    return () => cancelAnimationFrame(animId);
  }, [engineRef, collapsed, zoomLevel]);

  return (
    <div className="bg-[#090e1c]/75 backdrop-blur-md border border-cyan-500/30 rounded-xl p-2 shadow-2xl tactical-border-cyan flex flex-col items-center pointer-events-auto font-tech select-none transition-all duration-200">
      {/* Header bar */}
      <div className="flex items-center justify-between w-full px-1 text-[10px] text-cyan-400 font-bold uppercase tracking-wider gap-2">
        <div className="flex items-center gap-1.5 truncate">
          <Radar className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow shrink-0" />
          <span className="truncate">{collapsed ? `${enemyCount} FIENDER` : 'TAKTIK-RADAR'}</span>
        </div>
        <div className="flex items-center gap-1 text-slate-400 shrink-0">
          {!collapsed && (
            <button
              onClick={() => setZoomLevel((z) => (z === 1 ? 0.5 : 1))}
              className="p-1 hover:text-cyan-300 rounded hover:bg-slate-800 transition-colors cursor-pointer"
              title={zoomLevel === 1 ? 'Zooma ut (2x)' : 'Zooma in (1x)'}
            >
              {zoomLevel === 1 ? <ZoomOut className="w-3 h-3" /> : <ZoomIn className="w-3 h-3" />}
            </button>
          )}
          <button
            onClick={() => setIsCollapsed((c) => !c)}
            className="p-1 hover:text-cyan-300 rounded hover:bg-slate-800 transition-colors cursor-pointer"
            title={collapsed ? 'Expandera radar' : 'Minimera radar'}
          >
            {collapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Minimap Canvas Container */}
      {!collapsed && (
        <div className="relative mt-1">
          <canvas
            ref={canvasRef}
            width={104}
            height={104}
            className="rounded-full shadow-inner block"
          />
          {/* Radar Telemetry Footer */}
          <div className="flex items-center justify-between w-full mt-1 px-1 text-[9px] text-slate-400">
            <span className="flex items-center gap-1 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block" />
              <span>{enemyCount} FIENDER</span>
            </span>
            {hasBoss && (
              <span className="text-rose-400 font-bold uppercase animate-pulse">
                ⚠️ APEX
              </span>
            )}
            <span className="font-mono text-cyan-400 font-bold">
              {zoomLevel === 1 ? '700m' : '1400m'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
