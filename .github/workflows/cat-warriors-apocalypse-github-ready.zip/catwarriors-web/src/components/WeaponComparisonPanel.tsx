import React from 'react';
import { Weapon, WeaponCombatStats } from '../types/game';
import { Zap, Activity, RotateCcw, TrendingUp, TrendingDown, Minus, ArrowRightLeft } from 'lucide-react';
import { WEAPON_METRIC_BENCHMARKS } from './TacticalStatBar';

interface WeaponComparisonPanelProps {
  currentWeapon: Weapon;
  currentStats: WeaponCombatStats;
  currentLevel: number;
  comparedWeapon: Weapon;
  comparedStats: WeaponCombatStats;
  comparedLevel: number;
  onSelectCompared?: () => void;
  isEquipped?: boolean;
}

export const WeaponComparisonPanel: React.FC<WeaponComparisonPanelProps> = ({
  currentWeapon,
  currentStats,
  currentLevel,
  comparedWeapon,
  comparedStats,
  comparedLevel,
  onSelectCompared,
  isEquipped = false,
}) => {
  // Delta calculations
  const damageDelta = comparedStats.damage - currentStats.damage;
  const fireRateDelta = parseFloat((comparedStats.fireRate - currentStats.fireRate).toFixed(2));
  // For reload speed: LOWER is better (faster reload)
  const reloadDelta = parseFloat((currentStats.reloadSpeed - comparedStats.reloadSpeed).toFixed(2));
  const dpsDelta = comparedStats.dps - currentStats.dps;

  // Percentage widths for progress bars
  const currentDamagePct = Math.min(100, (currentStats.damage / WEAPON_METRIC_BENCHMARKS.damage) * 100);
  const comparedDamagePct = Math.min(100, (comparedStats.damage / WEAPON_METRIC_BENCHMARKS.damage) * 100);

  const currentFireRatePct = Math.min(100, (currentStats.fireRate / WEAPON_METRIC_BENCHMARKS.fireRate) * 100);
  const comparedFireRatePct = Math.min(100, (comparedStats.fireRate / WEAPON_METRIC_BENCHMARKS.fireRate) * 100);

  // Reload Agility: inverted so faster reload (lower seconds) has a higher progress bar
  const currentReloadAgilityPct = Math.max(
    10,
    Math.min(
      100,
      ((WEAPON_METRIC_BENCHMARKS.reloadSpeed - currentStats.reloadSpeed) /
        (WEAPON_METRIC_BENCHMARKS.reloadSpeed - 0.4)) *
        100
    )
  );
  const comparedReloadAgilityPct = Math.max(
    10,
    Math.min(
      100,
      ((WEAPON_METRIC_BENCHMARKS.reloadSpeed - comparedStats.reloadSpeed) /
        (WEAPON_METRIC_BENCHMARKS.reloadSpeed - 0.4)) *
        100
    )
  );

  return (
    <div className="bg-[#090e1a]/95 border border-amber-500/30 rounded-xl p-5 shadow-2xl backdrop-blur tactical-border relative overflow-hidden">
      {/* Header comparing the two weapons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <ArrowRightLeft className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-100 font-display">
                Taktisk Ballistisk Jämförelse
              </h3>
              <span className="text-[10px] font-tech text-amber-400 font-semibold">
                SYSTEM 2097
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Visuell prestandaanalys av skada, eldhastighet och omladdningstid med segmenterade mätare.
            </p>
          </div>
        </div>

        {/* Action button if not equipped */}
        {!isEquipped && onSelectCompared && (
          <button
            onClick={onSelectCompared}
            className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-lg text-xs tracking-wide transition-all cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 self-start sm:self-auto uppercase font-tech"
          >
            Utrusta {comparedWeapon.name}
          </button>
        )}
      </div>

      {/* Side-by-side title tags */}
      <div className="grid grid-cols-2 gap-4 pb-3 mb-4 text-xs font-tech border-b border-slate-800/60">
        {/* Left: Currently equipped */}
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-sm bg-slate-400" />
          <div className="truncate">
            <span className="text-slate-500 uppercase text-[10px]">Utrustat: </span>
            <span className="text-slate-200 font-bold">{currentWeapon.name}</span>
            <span className="text-slate-500 text-[10px]"> [LVL {currentLevel}]</span>
          </div>
        </div>

        {/* Right: Compared weapon */}
        <div className="flex items-center gap-2 justify-end text-right">
          <div className="truncate">
            <span className="text-amber-500/70 uppercase text-[10px]">Mål: </span>
            <span className="text-amber-400 font-bold">{comparedWeapon.name}</span>
            <span className="text-amber-500/70 text-[10px]"> [LVL {comparedLevel}]</span>
          </div>
          <div className="w-2 h-2 rounded-sm bg-amber-500" />
        </div>
      </div>

      {/* 3 CORE STATS WITH STYLIZED SEGMENTED PROGRESS BARS */}
      <div className="space-y-4 font-tech">
        {/* 1. DAMAGE (Skada) */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <div className="flex items-center gap-1.5 font-bold text-slate-200 font-display">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Skada (Damage Per Projectile)</span>
            </div>
            {/* Delta badge */}
            <div className="flex items-center gap-1 font-tech text-xs">
              {damageDelta > 0 ? (
                <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                  <TrendingUp className="w-3.5 h-3.5" /> +{damageDelta} Skada
                </span>
              ) : damageDelta < 0 ? (
                <span className="text-rose-400 font-bold flex items-center gap-0.5">
                  <TrendingDown className="w-3.5 h-3.5" /> {damageDelta} Skada
                </span>
              ) : (
                <span className="text-slate-500 flex items-center gap-0.5">
                  <Minus className="w-3.5 h-3.5" /> Identisk
                </span>
              )}
            </div>
          </div>

          {/* Current Weapon Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-tech text-slate-400">
              <span>{currentWeapon.name}</span>
              <span className="text-slate-200 font-semibold">{currentStats.damage} dmg</span>
            </div>
            <div className="relative w-full h-2.5 bg-[#050914] rounded overflow-hidden border border-slate-800">
              {/* Tactical tick grid */}
              <div className="absolute inset-0 grid grid-cols-10 pointer-events-none z-10 opacity-30">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="border-r border-slate-700/60 h-full" />
                ))}
              </div>
              <div
                className="h-full bg-slate-400 transition-all duration-300"
                style={{ width: `${currentDamagePct}%` }}
              />
            </div>
          </div>

          {/* Compared Weapon Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-tech text-slate-400">
              <span className="text-amber-400">{comparedWeapon.name}</span>
              <span className="text-amber-300 font-bold">{comparedStats.damage} dmg</span>
            </div>
            <div className="relative w-full h-2.5 bg-[#050914] rounded overflow-hidden border border-amber-500/30">
              {/* Tactical tick grid */}
              <div className="absolute inset-0 grid grid-cols-10 pointer-events-none z-10 opacity-30">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="border-r border-amber-400/40 h-full" />
                ))}
              </div>
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-orange-400 transition-all duration-300 shadow-sm"
                style={{ width: `${comparedDamagePct}%` }}
              />
            </div>
          </div>
        </div>

        {/* 2. RATE OF FIRE (Eldtakt) */}
        <div className="space-y-2 pt-3 border-t border-slate-800/60">
          <div className="flex justify-between items-center text-xs">
            <div className="flex items-center gap-1.5 font-bold text-slate-200 font-display">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Eldtakt (Rate of Fire)</span>
            </div>
            {/* Delta badge */}
            <div className="flex items-center gap-1 font-tech text-xs">
              {fireRateDelta > 0 ? (
                <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                  <TrendingUp className="w-3.5 h-3.5" /> +{fireRateDelta} skott/s
                </span>
              ) : fireRateDelta < 0 ? (
                <span className="text-rose-400 font-bold flex items-center gap-0.5">
                  <TrendingDown className="w-3.5 h-3.5" /> {fireRateDelta} skott/s
                </span>
              ) : (
                <span className="text-slate-500 flex items-center gap-0.5">
                  <Minus className="w-3.5 h-3.5" /> Identisk
                </span>
              )}
            </div>
          </div>

          {/* Current Weapon Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-tech text-slate-400">
              <span>{currentWeapon.name}</span>
              <span className="text-slate-200 font-semibold">{currentStats.fireRate} skott/s</span>
            </div>
            <div className="relative w-full h-2.5 bg-[#050914] rounded overflow-hidden border border-slate-800">
              <div className="absolute inset-0 grid grid-cols-10 pointer-events-none z-10 opacity-30">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="border-r border-slate-700/60 h-full" />
                ))}
              </div>
              <div
                className="h-full bg-slate-400 transition-all duration-300"
                style={{ width: `${currentFireRatePct}%` }}
              />
            </div>
          </div>

          {/* Compared Weapon Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-tech text-slate-400">
              <span className="text-cyan-400">{comparedWeapon.name}</span>
              <span className="text-cyan-300 font-bold">{comparedStats.fireRate} skott/s</span>
            </div>
            <div className="relative w-full h-2.5 bg-[#050914] rounded overflow-hidden border border-cyan-500/30">
              <div className="absolute inset-0 grid grid-cols-10 pointer-events-none z-10 opacity-30">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="border-r border-cyan-400/40 h-full" />
                ))}
              </div>
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-blue-400 transition-all duration-300 shadow-sm"
                style={{ width: `${comparedFireRatePct}%` }}
              />
            </div>
          </div>
        </div>

        {/* 3. RELOAD SPEED (Omladdningshastighet) */}
        <div className="space-y-2 pt-3 border-t border-slate-800/60">
          <div className="flex justify-between items-center text-xs">
            <div className="flex items-center gap-1.5 font-bold text-slate-200 font-display">
              <RotateCcw className="w-3.5 h-3.5 text-blue-400" />
              <span>Omladdningshastighet (Reload Agility)</span>
            </div>
            {/* Delta badge */}
            <div className="flex items-center gap-1 font-tech text-xs">
              {reloadDelta > 0 ? (
                <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                  <TrendingUp className="w-3.5 h-3.5" /> {reloadDelta}s snabbare
                </span>
              ) : reloadDelta < 0 ? (
                <span className="text-rose-400 font-bold flex items-center gap-0.5">
                  <TrendingDown className="w-3.5 h-3.5" /> {Math.abs(reloadDelta)}s långsammare
                </span>
              ) : (
                <span className="text-slate-500 flex items-center gap-0.5">
                  <Minus className="w-3.5 h-3.5" /> Identisk
                </span>
              )}
            </div>
          </div>

          {/* Current Weapon Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-tech text-slate-400">
              <span>{currentWeapon.name}</span>
              <span className="text-slate-200 font-semibold">{currentStats.reloadSpeed} sek</span>
            </div>
            <div className="relative w-full h-2.5 bg-[#050914] rounded overflow-hidden border border-slate-800">
              <div className="absolute inset-0 grid grid-cols-10 pointer-events-none z-10 opacity-30">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="border-r border-slate-700/60 h-full" />
                ))}
              </div>
              <div
                className="h-full bg-slate-400 transition-all duration-300"
                style={{ width: `${currentReloadAgilityPct}%` }}
              />
            </div>
          </div>

          {/* Compared Weapon Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-tech text-slate-400">
              <span className="text-blue-400">{comparedWeapon.name}</span>
              <span className="text-blue-300 font-bold">{comparedStats.reloadSpeed} sek</span>
            </div>
            <div className="relative w-full h-2.5 bg-[#050914] rounded overflow-hidden border border-blue-500/30">
              <div className="absolute inset-0 grid grid-cols-10 pointer-events-none z-10 opacity-30">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="border-r border-blue-400/40 h-full" />
                ))}
              </div>
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-indigo-400 transition-all duration-300 shadow-sm"
                style={{ width: `${comparedReloadAgilityPct}%` }}
              />
            </div>
          </div>
        </div>

        {/* 4. TOTAL SUSTAINED DPS SUMMARY */}
        <div className="mt-4 p-3 bg-[#050914] rounded-lg border border-slate-800 flex items-center justify-between font-tech text-xs">
          <div>
            <div className="text-[10px] uppercase text-slate-500 font-bold">Total Eldkraft & DPS Balans</div>
            <div className="text-slate-300 text-[11px] mt-0.5">
              Magasin: <span className="text-slate-100 font-bold">{comparedStats.magazineSize}</span> · Räckvidd:{' '}
              <span className="text-slate-100 font-bold">{comparedStats.range}px</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs font-bold text-slate-400">
              DPS: <span className="text-amber-400">{comparedStats.dps}</span>
            </div>
            <div className="text-[10px]">
              {dpsDelta > 0 ? (
                <span className="text-emerald-400 font-bold">+{dpsDelta} DPS mot nuvarande</span>
              ) : dpsDelta < 0 ? (
                <span className="text-rose-400 font-bold">{dpsDelta} DPS mot nuvarande</span>
              ) : (
                <span className="text-slate-500 font-bold">±0 DPS</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
