package com.catwarriors.apocalypse;

import android.content.Context;
import android.graphics.Canvas;
import java.util.ArrayList;
import java.util.List;

public class GameEngine {
    private final Context context;
    private final Camera camera;
    private final Player player;
    private final GameRenderer renderer;
    private final ParticleSystem particleSystem;
    private final AudioManager audioManager;
    private final SaveManager saveManager;
    private final MissionManager missionManager;

    private final List<Projectile> projectiles = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final Boss[] bossContainer = new Boss[1];

    private float moveX = 0;
    private float moveY = 0;
    private boolean isShooting = false;
    private float fireCooldown = 0;
    private float viewportW = 1920;
    private float viewportH = 1080;

    public GameEngine(Context context) {
        this.context = context;
        this.camera = new Camera();
        this.renderer = new GameRenderer();
        this.particleSystem = new ParticleSystem(150);
        this.audioManager = new AudioManager(context);
        this.saveManager = new SaveManager(context);
        this.missionManager = new MissionManager(1, 1);

        CatCharacter cat = new CatCharacter(
                GameConstants.CAT_ASSAULT, "Major Whiskers", "Assault Cat", "All-round",
                120, 40, 230, 0.12f, "Cluster Grenade", 8, GameConstants.WEAPON_ASSAULT_RIFLE
        );
        Weapon weapon = new Weapon(
                GameConstants.WEAPON_ASSAULT_RIFLE, "AR-24 Tomcat", "Rifle",
                22, 6.5f, 30, 1.6f, 520, 680, 0xFF60A5FA, 0.09f, 1, 1, false, 0
        );

        this.player = new Player(cat, weapon);
        missionManager.spawnWave(player, enemies, bossContainer);
    }

    public void setViewportSize(int w, int h) {
        this.viewportW = w;
        this.viewportH = h;
    }

    public void setMoveInput(float x, float y) {
        this.moveX = x;
        this.moveY = y;
    }

    public void onFirePressed() {
        this.isShooting = true;
    }

    public void onFireReleased() {
        this.isShooting = false;
    }

    public void onDodgePressed() {
        player.triggerDodge();
    }

    public void onSkillPressed() {
        // Skill execution
        camera.addShake(12f);
    }

    public void update(float dt) {
        // 1. Move Player
        player.update(dt);
        float speed = player.speed * (player.isDodging ? 2.2f : 1.0f);
        player.x += moveX * speed * dt;
        player.y += moveY * speed * dt;

        // 2. Firing
        fireCooldown -= dt;
        if (isShooting && fireCooldown <= 0 && player.ammo > 0) {
            player.ammo--;
            fireCooldown = 1f / player.currentWeapon.fireRate;
            projectiles.add(new Projectile(
                    player.x, player.y,
                    (float) Math.cos(player.angle) * player.currentWeapon.bulletSpeed,
                    (float) Math.sin(player.angle) * player.currentWeapon.bulletSpeed,
                    player.currentWeapon.damage, player.currentWeapon.range,
                    4f, player.currentWeapon.color, true, 1, false, 0
            ));
            audioManager.playShoot();
        }

        // 3. Update Projectiles
        for (int i = projectiles.size() - 1; i >= 0; i--) {
            Projectile p = projectiles.get(i);
            p.update(dt);
            if (!p.active) projectiles.remove(i);
        }

        // 4. Update Enemies
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy e = enemies.get(i);
            EnemyAI.updateEnemy(e, player, dt, projectiles);
            if (!e.active) enemies.remove(i);
        }

        // 5. Update Boss
        if (bossContainer[0] != null && bossContainer[0].active) {
            bossContainer[0].update(player, dt, projectiles);
        }

        // 6. Collisions
        CollisionSystem.checkCollisions(player, projectiles, enemies, bossContainer[0], particleSystem);

        // 7. Particles & Camera
        particleSystem.update(dt);
        camera.update(player.x, player.y, viewportW, viewportH, dt);
    }

    public void render(Canvas canvas) {
        renderer.render(canvas, camera, player, projectiles, enemies, bossContainer[0], particleSystem);
    }

    public void cleanup() {
        audioManager.release();
    }
}
