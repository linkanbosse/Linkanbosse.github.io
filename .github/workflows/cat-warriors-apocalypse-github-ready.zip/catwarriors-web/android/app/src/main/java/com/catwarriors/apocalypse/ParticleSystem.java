package com.catwarriors.apocalypse;

import android.graphics.Canvas;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.List;

public class ParticleSystem {
    public static class Particle {
        public float x, y, vx, vy, radius, life, maxLife;
        public int color;
        public boolean active = false;
    }

    private final List<Particle> pool = new ArrayList<>();
    private final Paint paint = new Paint();

    public ParticleSystem(int maxParticles) {
        for (int i = 0; i < maxParticles; i++) {
            pool.add(new Particle());
        }
    }

    public void emitSparks(float x, float y, int count) {
        int spawned = 0;
        for (Particle p : pool) {
            if (!p.active) {
                p.active = true;
                p.x = x;
                p.y = y;
                double ang = Math.random() * Math.PI * 2;
                float spd = (float) (80 + Math.random() * 160);
                p.vx = (float) Math.cos(ang) * spd;
                p.vy = (float) Math.sin(ang) * spd;
                p.radius = (float) (2 + Math.random() * 3);
                p.color = Math.random() > 0.5 ? 0xFFEF4444 : 0xFFFBBF24;
                p.life = 0;
                p.maxLife = 0.25f;
                spawned++;
                if (spawned >= count) break;
            }
        }
    }

    public void update(float dt) {
        for (Particle p : pool) {
            if (p.active) {
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.life += dt;
                if (p.life >= p.maxLife) {
                    p.active = false;
                }
            }
        }
    }

    public void render(Canvas canvas, Camera camera) {
        for (Particle p : pool) {
            if (p.active) {
                paint.setColor(p.color);
                float alpha = 1.0f - (p.life / p.maxLife);
                paint.setAlpha((int) (alpha * 255));
                canvas.drawCircle(p.x - camera.x, p.y - camera.y, p.radius, paint);
            }
        }
    }
}
