package com.catwarriors.apocalypse;

import java.util.List;

public class EnemyAI {
    public static void updateEnemy(Enemy enemy, Player player, float dt, List<Projectile> projectiles) {
        float dx = player.x - enemy.x;
        float dy = player.y - enemy.y;
        float dist = (float) Math.hypot(dx, dy);

        enemy.angle = (float) Math.atan2(dy, dx);
        if (enemy.hitFlashTimer > 0) enemy.hitFlashTimer -= dt;

        if (enemy.isRanged) {
            // Standoff distance
            if (dist > 250) {
                enemy.x += (dx / dist) * enemy.speed * dt;
                enemy.y += (dy / dist) * enemy.speed * dt;
            } else if (dist < 160) {
                enemy.x -= (dx / dist) * enemy.speed * 0.6f * dt;
                enemy.y -= (dy / dist) * enemy.speed * 0.6f * dt;
            }

            enemy.attackTimer -= dt;
            if (enemy.attackTimer <= 0) {
                enemy.attackTimer = enemy.attackCooldown;
                // Fire projectile toward player
                float pSpeed = 280f;
                projectiles.add(new Projectile(
                        enemy.x, enemy.y,
                        (float) Math.cos(enemy.angle) * pSpeed,
                        (float) Math.sin(enemy.angle) * pSpeed,
                        enemy.damage, 400f, 5f, 0xFF22C55E, false, 1, false, 0
                ));
            }
        } else {
            // Direct melee chase
            enemy.x += (dx / dist) * enemy.speed * dt;
            enemy.y += (dy / dist) * enemy.speed * dt;

            if (dist < enemy.radius + 18 && !player.isDodging) {
                enemy.attackTimer -= dt;
                if (enemy.attackTimer <= 0) {
                    enemy.attackTimer = 0.8f;
                    player.takeDamage(enemy.damage);
                }
            }
        }
    }
}
