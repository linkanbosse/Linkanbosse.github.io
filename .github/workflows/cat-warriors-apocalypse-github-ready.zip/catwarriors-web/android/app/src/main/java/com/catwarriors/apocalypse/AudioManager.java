package com.catwarriors.apocalypse;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

public class AudioManager {
    private SoundPool soundPool;
    private boolean soundEnabled = true;

    public AudioManager(Context context) {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(8)
                .setAudioAttributes(attrs)
                .build();
    }

    public void setSoundEnabled(boolean enabled) {
        this.soundEnabled = enabled;
    }

    public void playShoot() {}
    public void playExplosion() {}
    public void playHit() {}
    public void playVictory() {}

    public void release() {
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
    }
}
