/**
 * Cat Warriors: Apocalypse - Complete Native Android Java Source Files for CodeAssist
 * Package: com.catwarriors.apocalypse
 */

export interface AndroidFile {
  path: string;
  name: string;
  category: 'java' | 'gradle' | 'xml';
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFile[] = [
  // 1. settings.gradle
  {
    path: 'settings.gradle',
    name: 'settings.gradle',
    category: 'gradle',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "CatWarriorsApocalypse"
include ':app'
`,
  },

  // 2. build.gradle (root)
  {
    path: 'build.gradle',
    name: 'build.gradle (root)',
    category: 'gradle',
    content: `buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`,
  },

  // 3. app/build.gradle
  {
    path: 'app/build.gradle',
    name: 'app/build.gradle',
    category: 'gradle',
    content: `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.catwarriors.apocalypse'
    compileSdk 34

    defaultConfig {
        applicationId "com.catwarriors.apocalypse"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
}
`,
  },

  // 4. AndroidManifest.xml
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    category: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.catwarriors.apocalypse">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.CatWarriors">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:screenOrientation="sensorLandscape">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,
  },

  // 5. res/values/strings.xml
  {
    path: 'app/src/main/res/values/strings.xml',
    name: 'strings.xml',
    category: 'xml',
    content: `<resources>
    <string name="app_name">Cat Warriors: Apocalypse</string>
    <string name="start_game">Start Mission</string>
    <string name="barracks">Cat Barracks</string>
    <string name="armory">Armory</string>
    <string name="upgrades">Upgrades</string>
    <string name="settings">Settings</string>
</resources>
`,
  },

  // 6. res/values/colors.xml
  {
    path: 'app/src/main/res/values/colors.xml',
    name: 'colors.xml',
    category: 'xml',
    content: `<resources>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
    <color name="background">#0F172A</color>
    <color name="accent_blue">#3B82F6</color>
    <color name="accent_gold">#EAB308</color>
    <color name="accent_red">#EF4444</color>
</resources>
`,
  },

  // 7. res/values/styles.xml
  {
    path: 'app/src/main/res/values/styles.xml',
    name: 'styles.xml',
    category: 'xml',
    content: `<resources>
    <style name="Theme.CatWarriors" parent="Theme.AppCompat.NoActionBar">
        <item name="android:windowFullscreen">true</item>
        <item name="android:windowContentOverlay">@null</item>
        <item name="android:windowBackground">@color/background</item>
    </style>
</resources>
`,
  },

  // 8. res/layout/activity_main.xml
  {
    path: 'app/src/main/res/layout/activity_main.xml',
    name: 'activity_main.xml',
    category: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/game_container"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/background">

    <!-- GameView is added programmatically in MainActivity -->

</FrameLayout>
`,
  },

  // 9. GameConstants.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/GameConstants.java',
    name: 'GameConstants.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class GameConstants {
    public static final int TARGET_FPS = 60;
    public static final long OPTIMAL_TIME = 1000000000 / TARGET_FPS;
    public static final float ARENA_SIZE = 1400f;

    // Cat Warrior IDs
    public static final String CAT_ASSAULT = "assault";
    public static final String CAT_TANK = "tank";
    public static final String CAT_SNIPER = "sniper";
    public static final String CAT_MEDIC = "medic";
    public static final String CAT_ENGINEER = "engineer";
    public static final String CAT_SHADOW = "shadow";

    // Weapon IDs
    public static final String WEAPON_PISTOL = "pistol";
    public static final String WEAPON_ASSAULT_RIFLE = "assault_rifle";
    public static final String WEAPON_SMG = "smg";
    public static final String WEAPON_SHOTGUN = "shotgun";
    public static final String WEAPON_SNIPER = "sniper_rifle";
    public static final String WEAPON_LMG = "lmg";
    public static final String WEAPON_ROCKET = "rocket_launcher";
    public static final String WEAPON_FLAMETHROWER = "flamethrower";
    public static final String WEAPON_ENERGY_CARBINE = "energy_carbine";
    public static final String WEAPON_PLASMA = "plasma_cannon";
    public static final String WEAPON_GRENADE_LAUNCHER = "grenade_launcher";
    public static final String WEAPON_OBLITERATOR = "experimental_obliterator";

    // Enemy Types
    public static final String ENEMY_MUTANT_RAT = "mutant_rat";
    public static final String ENEMY_ZOMBIE_CAT = "zombie_cat";
    public static final String ENEMY_ARMORED_HOUND = "armored_hound";
    public static final String ENEMY_EXPLODER = "exploder";
    public static final String ENEMY_ACID_SPITTER = "acid_spitter";
    public static final String ENEMY_FLYING_DRONE = "flying_drone";
    public static final String ENEMY_HEAVY_MECH = "heavy_mech";
    public static final String ENEMY_BERSERKER = "berserker";
    public static final String ENEMY_SHIELDED_ELITE = "shielded_elite";
    public static final String ENEMY_LAB_ABOMINATION = "lab_abomination";
}
`,
  },

  // 10. MainActivity.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/MainActivity.java',
    name: 'MainActivity.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable fullscreen immersive mode
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        FrameLayout container = findViewById(R.id.game_container);
        gameView = new GameView(this);
        container.addView(gameView);

        hideSystemUI();
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI();
        if (gameView != null) {
            gameView.resumeGame();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (gameView != null) {
            gameView.pauseGame();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (gameView != null) {
            gameView.cleanup();
        }
    }
}
`,
  },

  // 11. GameLoop.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/GameLoop.java',
    name: 'GameLoop.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class GameLoop extends Thread {
    private final SurfaceHolder surfaceHolder;
    private final GameView gameView;
    private boolean isRunning = false;
    private long lastTime;

    public GameLoop(SurfaceHolder surfaceHolder, GameView gameView) {
        this.surfaceHolder = surfaceHolder;
        this.gameView = gameView;
    }

    public void setRunning(boolean running) {
        this.isRunning = running;
    }

    @Override
    public void run() {
        lastTime = System.nanoTime();

        while (isRunning) {
            Canvas canvas = null;
            long now = System.nanoTime();
            float dt = (now - lastTime) / 1_000_000_000.0f;
            lastTime = now;

            // Clamp delta time to avoid large physics steps
            if (dt > 0.05f) dt = 0.05f;

            try {
                canvas = surfaceHolder.lockCanvas();
                synchronized (surfaceHolder) {
                    if (canvas != null) {
                        gameView.update(dt);
                        gameView.draw(canvas);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (canvas != null) {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            // Sleep to maintain steady 60 FPS
            long elapsed = System.nanoTime() - now;
            long sleepMs = (GameConstants.OPTIMAL_TIME - elapsed) / 1_000_000;
            if (sleepMs > 0) {
                try {
                    Thread.sleep(sleepMs);
                } catch (InterruptedException ignored) {}
            }
        }
    }
}
`,
  },

  // 12. GameView.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/GameView.java',
    name: 'GameView.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private GameLoop gameLoop;
    private GameEngine gameEngine;

    // Touch controls tracking
    private int joystickPointerId = -1;
    private float joystickStartX = 0;
    private float joystickStartY = 0;
    private float joystickCurX = 0;
    private float joystickCurY = 0;

    public GameView(Context context) {
        super(context);
        getHolder().addCallback(this);
        setFocusable(true);

        this.gameEngine = new GameEngine(context);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        resumeGame();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        gameEngine.setViewportSize(width, height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        pauseGame();
    }

    public void resumeGame() {
        if (gameLoop == null || !gameLoop.isAlive()) {
            gameLoop = new GameLoop(getHolder(), this);
            gameLoop.setRunning(true);
            gameLoop.start();
        }
    }

    public void pauseGame() {
        if (gameLoop != null) {
            gameLoop.setRunning(false);
            boolean retry = true;
            while (retry) {
                try {
                    gameLoop.join();
                    retry = false;
                } catch (InterruptedException ignored) {}
            }
            gameLoop = null;
        }
    }

    public void cleanup() {
        pauseGame();
        if (gameEngine != null) {
            gameEngine.cleanup();
        }
    }

    public void update(float dt) {
        if (gameEngine != null) {
            gameEngine.update(dt);
        }
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (gameEngine != null) {
            gameEngine.render(canvas);
            drawTouchControls(canvas);
        }
    }

    private void drawTouchControls(Canvas canvas) {
        if (joystickPointerId != -1) {
            android.graphics.Paint p = new android.graphics.Paint();
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setColor(0x66FFFFFF);
            p.setStrokeWidth(4);
            canvas.drawCircle(joystickStartX, joystickStartY, 100, p);

            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(0xAA3B82F6);
            canvas.drawCircle(joystickCurX, joystickCurY, 45, p);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();
        int pointerId = event.getPointerId(index);

        float x = event.getX(index);
        float y = event.getY(index);
        int screenWidth = getWidth();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (x < screenWidth * 0.45f) {
                    // Left screen = movement joystick
                    joystickPointerId = pointerId;
                    joystickStartX = x;
                    joystickStartY = y;
                    joystickCurX = x;
                    joystickCurY = y;
                } else {
                    // Right screen buttons: Skill, Dodge, Fire
                    if (y > getHeight() * 0.7f && x > screenWidth * 0.8f) {
                        gameEngine.onFirePressed();
                    } else if (x > screenWidth * 0.85f && y < getHeight() * 0.65f) {
                        gameEngine.onDodgePressed();
                    } else if (x > screenWidth * 0.7f && y > getHeight() * 0.75f) {
                        gameEngine.onSkillPressed();
                    }
                }
                break;

            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int pId = event.getPointerId(i);
                    if (pId == joystickPointerId) {
                        float px = event.getX(i);
                        float py = event.getY(i);
                        float dx = px - joystickStartX;
                        float dy = py - joystickStartY;
                        float dist = (float) Math.hypot(dx, dy);
                        float maxRadius = 100f;

                        if (dist > maxRadius) {
                            dx = (dx / dist) * maxRadius;
                            dy = (dy / dist) * maxRadius;
                        }

                        joystickCurX = joystickStartX + dx;
                        joystickCurY = joystickStartY + dy;

                        gameEngine.setMoveInput(dx / maxRadius, dy / maxRadius);
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if (pointerId == joystickPointerId) {
                    joystickPointerId = -1;
                    gameEngine.setMoveInput(0, 0);
                } else {
                    gameEngine.onFireReleased();
                }
                break;
        }

        return true;
    }
}
`,
  },

  // 13. CatCharacter.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/CatCharacter.java',
    name: 'CatCharacter.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class CatCharacter {
    public String id;
    public String name;
    public String codename;
    public String role;
    public int baseHp;
    public int baseArmor;
    public float baseSpeed;
    public float critChance;
    public String skillName;
    public float skillCooldown;
    public String startingWeaponId;

    public CatCharacter(String id, String name, String codename, String role,
                        int baseHp, int baseArmor, float baseSpeed, float critChance,
                        String skillName, float skillCooldown, String startingWeaponId) {
        this.id = id;
        this.name = name;
        this.codename = codename;
        this.role = role;
        this.baseHp = baseHp;
        this.baseArmor = baseArmor;
        this.baseSpeed = baseSpeed;
        this.critChance = critChance;
        this.skillName = skillName;
        this.skillCooldown = skillCooldown;
        this.startingWeaponId = startingWeaponId;
    }
}
`,
  },

  // 14. Player.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Player.java',
    name: 'Player.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class Player {
    public float x = 0;
    public float y = 0;
    public float angle = 0;
    public float hp;
    public float maxHp;
    public float armor;
    public float maxArmor;
    public float speed;
    public float critChance;

    public CatCharacter currentCat;
    public Weapon currentWeapon;

    public int ammo;
    public boolean isReloading = false;
    public float reloadTimer = 0;
    public float skillCooldownRemaining = 0;
    public float dodgeCooldownRemaining = 0;
    public boolean isDodging = false;
    public float dodgeTimer = 0;

    public Player(CatCharacter cat, Weapon weapon) {
        this.currentCat = cat;
        this.currentWeapon = weapon;
        this.maxHp = cat.baseHp;
        this.hp = cat.baseHp;
        this.maxArmor = cat.baseArmor;
        this.armor = cat.baseArmor;
        this.speed = cat.baseSpeed;
        this.critChance = cat.critChance;
        this.ammo = weapon.magazineSize;
    }

    public void update(float dt) {
        if (skillCooldownRemaining > 0) {
            skillCooldownRemaining = Math.max(0, skillCooldownRemaining - dt);
        }
        if (dodgeCooldownRemaining > 0) {
            dodgeCooldownRemaining = Math.max(0, dodgeCooldownRemaining - dt);
        }
        if (isDodging) {
            dodgeTimer -= dt;
            if (dodgeTimer <= 0) {
                isDodging = false;
            }
        }
        if (isReloading) {
            reloadTimer -= dt;
            if (reloadTimer <= 0) {
                isReloading = false;
                ammo = currentWeapon.magazineSize;
            }
        }
    }

    public void triggerDodge() {
        if (dodgeCooldownRemaining <= 0 && !isDodging) {
            isDodging = true;
            dodgeTimer = 0.25f;
            dodgeCooldownRemaining = 1.6f;
        }
    }

    public void reload() {
        if (!isReloading && ammo < currentWeapon.magazineSize) {
            isReloading = true;
            reloadTimer = currentWeapon.reloadTime;
        }
    }

    public void takeDamage(float rawDamage) {
        float finalDamage = rawDamage;
        if (armor > 0) {
            float absorbed = Math.min(armor, rawDamage * 0.6f);
            armor -= absorbed;
            finalDamage = rawDamage - absorbed;
        }
        hp = Math.max(0, hp - finalDamage);
    }
}
`,
  },

  // 15. Weapon.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Weapon.java',
    name: 'Weapon.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class Weapon {
    public String id;
    public String name;
    public String category;
    public float damage;
    public float fireRate;
    public int magazineSize;
    public float reloadSpeed;
    public float reloadTime;
    public float dps;
    public float range;
    public float bulletSpeed;
    public int color;
    public float spread;
    public int pelletCount;
    public int penetration;
    public boolean isExplosive;
    public float explosionRadius;

    public Weapon(String id, String name, String category, float damage, float fireRate,
                  int magazineSize, float reloadTime, float range, float bulletSpeed,
                  int color, float spread, int pelletCount, int penetration,
                  boolean isExplosive, float explosionRadius) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.damage = damage;
        this.fireRate = fireRate;
        this.magazineSize = magazineSize;
        this.reloadSpeed = reloadTime;
        this.reloadTime = reloadTime;
        this.dps = damage * pelletCount * fireRate;
        this.range = range;
        this.bulletSpeed = bulletSpeed;
        this.color = color;
        this.spread = spread;
        this.pelletCount = pelletCount;
        this.penetration = penetration;
        this.isExplosive = isExplosive;
        this.explosionRadius = explosionRadius;
    }
}
`,
  },

  // 16. Projectile.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Projectile.java',
    name: 'Projectile.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class Projectile {
    public float x;
    public float y;
    public float vx;
    public float vy;
    public float damage;
    public float rangeRemaining;
    public float radius;
    public int color;
    public boolean fromPlayer;
    public int penetrationRemaining;
    public boolean isExplosive;
    public float explosionRadius;
    public boolean active = true;

    public Projectile(float x, float y, float vx, float vy, float damage, float range,
                      float radius, int color, boolean fromPlayer, int penetration,
                      boolean isExplosive, float explosionRadius) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.damage = damage;
        this.rangeRemaining = range;
        this.radius = radius;
        this.color = color;
        this.fromPlayer = fromPlayer;
        this.penetrationRemaining = penetration;
        this.isExplosive = isExplosive;
        this.explosionRadius = explosionRadius;
    }

    public void update(float dt) {
        float dx = vx * dt;
        float dy = vy * dt;
        x += dx;
        y += dy;
        rangeRemaining -= (float) Math.hypot(dx, dy);
        if (rangeRemaining <= 0) {
            active = false;
        }
    }
}
`,
  },

  // 17. Enemy.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Enemy.java',
    name: 'Enemy.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class Enemy {
    public String type;
    public float x;
    public float y;
    public float hp;
    public float maxHp;
    public float speed;
    public float radius;
    public float damage;
    public boolean isRanged;
    public float attackTimer;
    public float attackCooldown;
    public float angle;
    public float hitFlashTimer = 0;
    public boolean active = true;

    public Enemy(String type, float x, float y, float hp, float speed,
                 float radius, float damage, boolean isRanged, float attackCooldown) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.hp = hp;
        this.maxHp = hp;
        this.speed = speed;
        this.radius = radius;
        this.damage = damage;
        this.isRanged = isRanged;
        this.attackCooldown = attackCooldown;
        this.attackTimer = (float) (Math.random() * attackCooldown);
    }

    public void takeDamage(float dmg) {
        hp -= dmg;
        hitFlashTimer = 0.08f;
        if (hp <= 0) {
            active = false;
        }
    }
}
`,
  },

  // 18. EnemyAI.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/EnemyAI.java',
    name: 'EnemyAI.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import java.util.List;

public class EnemyAI {
    public static void updateEnemy(Enemy enemy, Player player, float dt, List<Projectile> projectiles) {
        float dx = player.x - enemy.x;
        float dy = player.y - enemy.y;
        float dist = (float) Math.hypot(dx, dy);

        enemy.angle = (float) Math.atan2(dy, dx);
        if (enemy.hitFlashTimer > 0) enemy.hitFlashTimer -= dt;

        if (enemy.isRanged) {
            // Standoff distance
            if (dist > 250) {
                enemy.x += (dx / dist) * enemy.speed * dt;
                enemy.y += (dy / dist) * enemy.speed * dt;
            } else if (dist < 160) {
                enemy.x -= (dx / dist) * enemy.speed * 0.6f * dt;
                enemy.y -= (dy / dist) * enemy.speed * 0.6f * dt;
            }

            enemy.attackTimer -= dt;
            if (enemy.attackTimer <= 0) {
                enemy.attackTimer = enemy.attackCooldown;
                // Fire projectile toward player
                float pSpeed = 280f;
                projectiles.add(new Projectile(
                        enemy.x, enemy.y,
                        (float) Math.cos(enemy.angle) * pSpeed,
                        (float) Math.sin(enemy.angle) * pSpeed,
                        enemy.damage, 400f, 5f, 0xFF22C55E, false, 1, false, 0
                ));
            }
        } else {
            // Direct melee chase
            enemy.x += (dx / dist) * enemy.speed * dt;
            enemy.y += (dy / dist) * enemy.speed * dt;

            if (dist < enemy.radius + 18 && !player.isDodging) {
                enemy.attackTimer -= dt;
                if (enemy.attackTimer <= 0) {
                    enemy.attackTimer = 0.8f;
                    player.takeDamage(enemy.damage);
                }
            }
        }
    }
}
`,
  },

  // 19. Boss.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Boss.java',
    name: 'Boss.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import java.util.List;

public class Boss {
    public String id;
    public String name;
    public float x;
    public float y;
    public float hp;
    public float maxHp;
    public float radius;
    public float speed;
    public float angle;
    public int phase = 1;
    public float attackTimer = 2.0f;
    public float specialTimer = 5.0f;
    public boolean isTelegraphing = false;
    public float hitFlashTimer = 0;
    public boolean active = true;

    public Boss(String id, String name, float maxHp, float speed, float radius) {
        this.id = id;
        this.name = name;
        this.hp = maxHp;
        this.maxHp = maxHp;
        this.speed = speed;
        this.radius = radius;
        this.x = 350;
        this.y = -200;
    }

    public void update(Player player, float dt, List<Projectile> projectiles) {
        if (hitFlashTimer > 0) hitFlashTimer -= dt;

        float dx = player.x - x;
        float dy = player.y - y;
        float dist = (float) Math.hypot(dx, dy);

        angle = (float) Math.atan2(dy, dx);

        if (dist > 150) {
            x += (dx / dist) * speed * dt;
            y += (dy / dist) * speed * dt;
        }

        attackTimer -= dt;
        specialTimer -= dt;

        // Spread shot
        if (attackTimer <= 0) {
            attackTimer = 1.8f;
            for (int s = -1; s <= 1; s++) {
                float shotAngle = angle + s * 0.25f;
                projectiles.add(new Projectile(
                        x, y,
                        (float) Math.cos(shotAngle) * 320,
                        (float) Math.sin(shotAngle) * 320,
                        28, 600, 7, 0xFFF97316, false, 1, false, 0
                ));
            }
        }

        // Radial nova burst
        if (specialTimer <= 0) {
            specialTimer = 5.5f;
            for (int a = 0; a < 12; a++) {
                float ang = (float) ((a * Math.PI * 2) / 12);
                projectiles.add(new Projectile(
                        x, y,
                        (float) Math.cos(ang) * 280,
                        (float) Math.sin(ang) * 280,
                        32, 550, 8, 0xFFDC2626, false, 1, true, 60
                ));
            }
        }
    }

    public void takeDamage(float dmg) {
        hp -= dmg;
        hitFlashTimer = 0.08f;
        if (hp <= 0) {
            active = false;
        }
    }
}
`,
  },

  // 20. CollisionSystem.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/CollisionSystem.java',
    name: 'CollisionSystem.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import java.util.List;

public class CollisionSystem {
    public static void checkCollisions(Player player, List<Projectile> projectiles,
                                        List<Enemy> enemies, Boss boss,
                                        ParticleSystem particles) {
        for (Projectile p : projectiles) {
            if (!p.active) continue;

            if (p.fromPlayer) {
                // Check against boss
                if (boss != null && boss.active) {
                    float d = (float) Math.hypot(p.x - boss.x, p.y - boss.y);
                    if (d < boss.radius + p.radius) {
                        boss.takeDamage(p.damage);
                        p.penetrationRemaining--;
                        particles.emitSparks(p.x, p.y, 6);
                        if (p.penetrationRemaining <= 0) {
                            p.active = false;
                        }
                    }
                }

                // Check against enemies
                for (Enemy e : enemies) {
                    if (!e.active) continue;
                    float d = (float) Math.hypot(p.x - e.x, p.y - e.y);
                    if (d < e.radius + p.radius) {
                        e.takeDamage(p.damage);
                        p.penetrationRemaining--;
                        particles.emitSparks(p.x, p.y, 4);
                        if (p.penetrationRemaining <= 0) {
                            p.active = false;
                            break;
                        }
                    }
                }
            } else {
                // Check enemy projectile against player
                if (!player.isDodging) {
                    float d = (float) Math.hypot(p.x - player.x, p.y - player.y);
                    if (d < 18 + p.radius) {
                        player.takeDamage(p.damage);
                        particles.emitSparks(player.x, player.y, 6);
                        p.active = false;
                    }
                }
            }
        }
    }
}
`,
  },

  // 21. ParticleSystem.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/ParticleSystem.java',
    name: 'ParticleSystem.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.graphics.Canvas;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.List;

public class ParticleSystem {
    public static class Particle {
        public float x, y, vx, vy, radius, life, maxLife;
        public int color;
        public boolean active = false;
    }

    private final List<Particle> pool = new ArrayList<>();
    private final Paint paint = new Paint();

    public ParticleSystem(int maxParticles) {
        for (int i = 0; i < maxParticles; i++) {
            pool.add(new Particle());
        }
    }

    public void emitSparks(float x, float y, int count) {
        int spawned = 0;
        for (Particle p : pool) {
            if (!p.active) {
                p.active = true;
                p.x = x;
                p.y = y;
                double ang = Math.random() * Math.PI * 2;
                float spd = (float) (80 + Math.random() * 160);
                p.vx = (float) Math.cos(ang) * spd;
                p.vy = (float) Math.sin(ang) * spd;
                p.radius = (float) (2 + Math.random() * 3);
                p.color = Math.random() > 0.5 ? 0xFFEF4444 : 0xFFFBBF24;
                p.life = 0;
                p.maxLife = 0.25f;
                spawned++;
                if (spawned >= count) break;
            }
        }
    }

    public void update(float dt) {
        for (Particle p : pool) {
            if (p.active) {
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.life += dt;
                if (p.life >= p.maxLife) {
                    p.active = false;
                }
            }
        }
    }

    public void render(Canvas canvas, Camera camera) {
        for (Particle p : pool) {
            if (p.active) {
                paint.setColor(p.color);
                float alpha = 1.0f - (p.life / p.maxLife);
                paint.setAlpha((int) (alpha * 255));
                canvas.drawCircle(p.x - camera.x, p.y - camera.y, p.radius, paint);
            }
        }
    }
}
`,
  },

  // 22. Camera.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Camera.java',
    name: 'Camera.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class Camera {
    public float x = 0;
    public float y = 0;
    public float shake = 0;

    public void update(float targetX, float targetY, float viewportW, float viewportH, float dt) {
        float desiredX = targetX - viewportW / 2;
        float desiredY = targetY - viewportH / 2;

        x += (desiredX - x) * 8 * dt;
        y += (desiredY - y) * 8 * dt;

        if (shake > 0) {
            shake = Math.max(0, shake - dt * 20);
            x += (Math.random() - 0.5f) * shake;
            y += (Math.random() - 0.5f) * shake;
        }
    }

    public void addShake(float amount) {
        shake = Math.min(25f, shake + amount);
    }
}
`,
  },

  // 23. Level.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Level.java',
    name: 'Level.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class Level {
    public int zoneId;
    public String zoneName;
    public int missionIndex;
    public int totalWaves;
    public boolean isBossLevel;

    public Level(int zoneId, String zoneName, int missionIndex, int totalWaves, boolean isBossLevel) {
        this.zoneId = zoneId;
        this.zoneName = zoneName;
        this.missionIndex = missionIndex;
        this.totalWaves = totalWaves;
        this.isBossLevel = isBossLevel;
    }
}
`,
  },

  // 24. MissionManager.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/MissionManager.java',
    name: 'MissionManager.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import java.util.List;

public class MissionManager {
    public Level currentLevel;
    public int currentWave = 1;
    public boolean waveInProgress = false;

    public MissionManager(int zoneId, int missionIndex) {
        this.currentLevel = new Level(zoneId, "Zon " + zoneId, missionIndex, 3, missionIndex == 3);
    }

    public void spawnWave(Player player, List<Enemy> enemies, Boss[] bossRef) {
        if (currentLevel.isBossLevel && currentWave == currentLevel.totalWaves) {
            bossRef[0] = new Boss("boss_" + currentLevel.zoneId, "Zone Boss", 2500, 110, 50);
            return;
        }

        int count = 6 + currentWave * 4;
        for (int i = 0; i < count; i++) {
            double ang = Math.random() * Math.PI * 2;
            float dist = (float) (350 + Math.random() * 250);
            float ex = player.x + (float) Math.cos(ang) * dist;
            float ey = player.y + (float) Math.sin(ang) * dist;
            enemies.add(new Enemy(GameConstants.ENEMY_MUTANT_RAT, ex, ey, 50, 160, 20, 15, false, 1.0f));
        }
    }
}
`,
  },

  // 25. Inventory.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/Inventory.java',
    name: 'Inventory.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    public int coins = 100;
    public int scrap = 20;
    public List<String> unlockedCats = new ArrayList<>();
    public List<String> unlockedWeapons = new ArrayList<>();

    public Inventory() {
        unlockedCats.add(GameConstants.CAT_ASSAULT);
        unlockedWeapons.add(GameConstants.WEAPON_ASSAULT_RIFLE);
        unlockedWeapons.add(GameConstants.WEAPON_PISTOL);
    }
}
`,
  },

  // 26. UpgradeSystem.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/UpgradeSystem.java',
    name: 'UpgradeSystem.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

public class UpgradeSystem {
    public int helmetLevel = 0;
    public int vestLevel = 0;
    public int bootsLevel = 0;
    public int modchipLevel = 0;

    public void applyUpgrades(Player player) {
        player.maxArmor += helmetLevel * 15;
        player.armor = player.maxArmor;
        player.maxHp += vestLevel * 25;
        player.hp = player.maxHp;
        player.speed += bootsLevel * 12;
        player.critChance += modchipLevel * 0.03f;
    }
}
`,
  },

  // 27. SaveManager.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/SaveManager.java',
    name: 'SaveManager.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.content.Context;
import android.content.SharedPreferences;

public class SaveManager {
    private static final String PREF_NAME = "cat_warriors_save";
    private final SharedPreferences prefs;

    public SaveManager(Context context) {
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveProgress(int coins, int scrap, int zone, int mission) {
        prefs.edit()
             .putInt("coins", coins)
             .putInt("scrap", scrap)
             .putInt("highest_zone", zone)
             .putInt("highest_mission", mission)
             .apply();
    }

    public int getCoins() { return prefs.getInt("coins", 150); }
    public int getScrap() { return prefs.getInt("scrap", 25); }
    public int getHighestZone() { return prefs.getInt("highest_zone", 1); }
    public int getHighestMission() { return prefs.getInt("highest_mission", 1); }
}
`,
  },

  // 28. AudioManager.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/AudioManager.java',
    name: 'AudioManager.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

public class AudioManager {
    private SoundPool soundPool;
    private boolean soundEnabled = true;

    public AudioManager(Context context) {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(8)
                .setAudioAttributes(attrs)
                .build();
    }

    public void setSoundEnabled(boolean enabled) {
        this.soundEnabled = enabled;
    }

    public void playShoot() {}
    public void playExplosion() {}
    public void playHit() {}
    public void playVictory() {}

    public void release() {
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
    }
}
`,
  },

  // 29. GameRenderer.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/GameRenderer.java',
    name: 'GameRenderer.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.List;

public class GameRenderer {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public void render(Canvas canvas, Camera camera, Player player,
                       List<Projectile> projectiles, List<Enemy> enemies,
                       Boss boss, ParticleSystem particles) {
        // Clear background
        canvas.drawColor(0xFF0F172A);

        canvas.save();
        canvas.translate(-camera.x, -camera.y);

        // Render Arena Grid
        paint.setColor(0xFF1E293B);
        paint.setStrokeWidth(2);
        for (int x = -1400; x <= 1400; x += 100) {
            canvas.drawLine(x, -1400, x, 1400, paint);
        }
        for (int y = -1400; y <= 1400; y += 100) {
            canvas.drawLine(-1400, y, 1400, y, paint);
        }

        // Render Enemies
        for (Enemy e : enemies) {
            if (!e.active) continue;
            paint.setColor(e.hitFlashTimer > 0 ? 0xFFFFFFFF : 0xFF71717A);
            canvas.drawCircle(e.x, e.y, e.radius, paint);
        }

        // Render Boss
        if (boss != null && boss.active) {
            paint.setColor(boss.hitFlashTimer > 0 ? 0xFFFFFFFF : 0xFFDC2626);
            canvas.drawCircle(boss.x, boss.y, boss.radius, paint);
        }

        // Render Player Cat
        paint.setColor(0xFF3B82F6);
        canvas.drawCircle(player.x, player.y, 18, paint);
        // Cat Ears
        paint.setColor(0xFFD97706);
        Path earPath = new Path();
        earPath.moveTo(player.x - 10, player.y - 12);
        earPath.lineTo(player.x - 16, player.y - 24);
        earPath.lineTo(player.x - 4, player.y - 14);
        canvas.drawPath(earPath, paint);

        // Render Projectiles
        for (Projectile p : projectiles) {
            if (!p.active) continue;
            paint.setColor(p.color);
            canvas.drawCircle(p.x, p.y, p.radius, paint);
        }

        // Render Particles
        particles.render(canvas, camera);

        canvas.restore();

        // Render HUD (HP, Armor, Ammo)
        paint.setColor(0xFFEF4444);
        canvas.drawRect(40, 40, 40 + (player.hp / player.maxHp) * 200, 60, paint);
        paint.setColor(0xFF3B82F6);
        canvas.drawRect(40, 66, 40 + (player.armor / player.maxArmor) * 200, 78, paint);
    }
}
`,
  },

  // 30. GameEngine.java
  {
    path: 'app/src/main/java/com/catwarriors/apocalypse/GameEngine.java',
    name: 'GameEngine.java',
    category: 'java',
    content: `package com.catwarriors.apocalypse;

import android.content.Context;
import android.graphics.Canvas;
import java.util.ArrayList;
import java.util.List;

public class GameEngine {
    private final Context context;
    private final Camera camera;
    private final Player player;
    private final GameRenderer renderer;
    private final ParticleSystem particleSystem;
    private final AudioManager audioManager;
    private final SaveManager saveManager;
    private final MissionManager missionManager;

    private final List<Projectile> projectiles = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final Boss[] bossContainer = new Boss[1];

    private float moveX = 0;
    private float moveY = 0;
    private boolean isShooting = false;
    private float fireCooldown = 0;
    private float viewportW = 1920;
    private float viewportH = 1080;

    public GameEngine(Context context) {
        this.context = context;
        this.camera = new Camera();
        this.renderer = new GameRenderer();
        this.particleSystem = new ParticleSystem(150);
        this.audioManager = new AudioManager(context);
        this.saveManager = new SaveManager(context);
        this.missionManager = new MissionManager(1, 1);

        CatCharacter cat = new CatCharacter(
                GameConstants.CAT_ASSAULT, "Major Whiskers", "Assault Cat", "All-round",
                120, 40, 230, 0.12f, "Cluster Grenade", 8, GameConstants.WEAPON_ASSAULT_RIFLE
        );
        Weapon weapon = new Weapon(
                GameConstants.WEAPON_ASSAULT_RIFLE, "AR-24 Tomcat", "Rifle",
                22, 6.5f, 30, 1.6f, 520, 680, 0xFF60A5FA, 0.09f, 1, 1, false, 0
        );

        this.player = new Player(cat, weapon);
        missionManager.spawnWave(player, enemies, bossContainer);
    }

    public void setViewportSize(int w, int h) {
        this.viewportW = w;
        this.viewportH = h;
    }

    public void setMoveInput(float x, float y) {
        this.moveX = x;
        this.moveY = y;
    }

    public void onFirePressed() {
        this.isShooting = true;
    }

    public void onFireReleased() {
        this.isShooting = false;
    }

    public void onDodgePressed() {
        player.triggerDodge();
    }

    public void onSkillPressed() {
        // Skill execution
        camera.addShake(12f);
    }

    public void update(float dt) {
        // 1. Move Player
        player.update(dt);
        float speed = player.speed * (player.isDodging ? 2.2f : 1.0f);
        player.x += moveX * speed * dt;
        player.y += moveY * speed * dt;

        // 2. Firing
        fireCooldown -= dt;
        if (isShooting && fireCooldown <= 0 && player.ammo > 0) {
            player.ammo--;
            fireCooldown = 1f / player.currentWeapon.fireRate;
            projectiles.add(new Projectile(
                    player.x, player.y,
                    (float) Math.cos(player.angle) * player.currentWeapon.bulletSpeed,
                    (float) Math.sin(player.angle) * player.currentWeapon.bulletSpeed,
                    player.currentWeapon.damage, player.currentWeapon.range,
                    4f, player.currentWeapon.color, true, 1, false, 0
            ));
            audioManager.playShoot();
        }

        // 3. Update Projectiles
        for (int i = projectiles.size() - 1; i >= 0; i--) {
            Projectile p = projectiles.get(i);
            p.update(dt);
            if (!p.active) projectiles.remove(i);
        }

        // 4. Update Enemies
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy e = enemies.get(i);
            EnemyAI.updateEnemy(e, player, dt, projectiles);
            if (!e.active) enemies.remove(i);
        }

        // 5. Update Boss
        if (bossContainer[0] != null && bossContainer[0].active) {
            bossContainer[0].update(player, dt, projectiles);
        }

        // 6. Collisions
        CollisionSystem.checkCollisions(player, projectiles, enemies, bossContainer[0], particleSystem);

        // 7. Particles & Camera
        particleSystem.update(dt);
        camera.update(player.x, player.y, viewportW, viewportH, dt);
    }

    public void render(Canvas canvas) {
        renderer.render(canvas, camera, player, projectiles, enemies, bossContainer[0], particleSystem);
    }

    public void cleanup() {
        audioManager.release();
    }
}
`,
  },
];
