import { Zone } from '../types/game';

export interface TerrainFeature {
  id: number;
  x: number;
  y: number;
  type: 'rock' | 'structure' | 'pool' | 'foliage' | 'barrier' | 'crater' | 'conduit';
  subtype: string;
  width: number;
  height: number;
  rotation: number;
  color: string;
  secondaryColor: string;
  seed: number;
}

/**
 * Deterministic pseudo-random number generator for procedural terrain
 */
function seededRandom(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/**
 * Procedural Terrain Manager
 * Generates rich, biome-specific environmental terrain objects,
 * ground textures, natural obstacles, hazard pools, and boundary fortifications.
 */
export class ProceduralTerrain {
  private zoneId: number = -1;
  public features: TerrainFeature[] = [];
  public groundDecals: { x: number; y: number; size: number; rotation: number; variant: number }[] = [];

  constructor(zone: Zone) {
    this.generate(zone);
  }

  public generate(zone: Zone) {
    this.zoneId = zone.id;
    this.features = [];
    this.groundDecals = [];

    const rng = seededRandom(zone.id * 7919 + 42);
    const arenaRadius = 1350;

    // 1. Generate ground texture decals (cracks, patches, markings)
    const numDecals = 90;
    for (let i = 0; i < numDecals; i++) {
      const angle = rng() * Math.PI * 2;
      const dist = 60 + rng() * (arenaRadius - 100);
      this.groundDecals.push({
        x: Math.cos(angle) * dist,
        y: Math.sin(angle) * dist,
        size: 40 + rng() * 80,
        rotation: rng() * Math.PI * 2,
        variant: Math.floor(rng() * 4),
      });
    }

    // 2. Generate biome-specific physical & decorative features
    const numFeatures = 85;
    for (let i = 0; i < numFeatures; i++) {
      const angle = rng() * Math.PI * 2;
      const dist = 100 + rng() * (arenaRadius - 120);
      const x = Math.cos(angle) * dist;
      const y = Math.sin(angle) * dist;

      const pick = rng();
      let type: TerrainFeature['type'];
      let subtype: string;
      let width = 28 + rng() * 36;
      let height = width * (0.8 + rng() * 0.4);
      let color = zone.wallColor;
      let secondaryColor = zone.hazardColor;

      if (zone.biome === 'forest') {
        if (pick < 0.35) {
          type = 'foliage';
          subtype = 'fern_cluster';
          color = '#15803d';
          secondaryColor = '#22c55e';
          width = 32 + rng() * 28;
        } else if (pick < 0.6) {
          type = 'rock';
          subtype = 'mossy_boulder';
          color = '#1e293b';
          secondaryColor = '#166534';
          width = 30 + rng() * 30;
        } else if (pick < 0.8) {
          type = 'pool';
          subtype = 'spore_puddle';
          color = '#064e3b';
          secondaryColor = '#4ade80';
          width = 45 + rng() * 45;
        } else {
          type = 'structure';
          subtype = 'ancient_monolith';
          color = '#334155';
          secondaryColor = '#86efac';
          width = 24 + rng() * 16;
        }
      } else if (zone.biome === 'urban') {
        if (pick < 0.35) {
          type = 'barrier';
          subtype = 'concrete_block';
          color = '#334155';
          secondaryColor = '#eab308';
          width = 44 + rng() * 26;
          height = 20 + rng() * 10;
        } else if (pick < 0.6) {
          type = 'structure';
          subtype = 'scrap_pile';
          color = '#1e293b';
          secondaryColor = '#ef4444';
          width = 34 + rng() * 24;
        } else if (pick < 0.8) {
          type = 'pool';
          subtype = 'oil_slick';
          color = '#090d16';
          secondaryColor = '#38bdf8';
          width = 40 + rng() * 35;
        } else {
          type = 'conduit';
          subtype = 'manhole_vent';
          color = '#475569';
          secondaryColor = '#f59e0b';
          width = 28 + rng() * 10;
          height = width;
        }
      } else if (zone.biome === 'industrial') {
        if (pick < 0.35) {
          type = 'structure';
          subtype = 'cargo_crate';
          color = '#3f3f46';
          secondaryColor = '#f97316';
          width = 36 + rng() * 20;
          height = 30 + rng() * 14;
        } else if (pick < 0.6) {
          type = 'barrier';
          subtype = 'hazard_fence';
          color = '#27272a';
          secondaryColor = '#eab308';
          width = 48 + rng() * 24;
          height = 18;
        } else if (pick < 0.8) {
          type = 'pool';
          subtype = 'molten_slag';
          color = '#7c2d12';
          secondaryColor = '#ea580c';
          width = 42 + rng() * 30;
        } else {
          type = 'conduit';
          subtype = 'steam_pipe';
          color = '#52525b';
          secondaryColor = '#fdba74';
          width = 32 + rng() * 18;
        }
      } else if (zone.biome === 'desert') {
        if (pick < 0.4) {
          type = 'rock';
          subtype = 'sandstone_crag';
          color = '#78350f';
          secondaryColor = '#b45309';
          width = 36 + rng() * 34;
        } else if (pick < 0.65) {
          type = 'structure';
          subtype = 'ruined_pillar';
          color = '#92400e';
          secondaryColor = '#f59e0b';
          width = 26 + rng() * 16;
        } else if (pick < 0.85) {
          type = 'foliage';
          subtype = 'desert_cactus';
          color = '#15803d';
          secondaryColor = '#4ade80';
          width = 22 + rng() * 14;
        } else {
          type = 'pool';
          subtype = 'quicksand';
          color = '#451a03';
          secondaryColor = '#d97706';
          width = 48 + rng() * 35;
        }
      } else if (zone.biome === 'snow') {
        if (pick < 0.4) {
          type = 'rock';
          subtype = 'ice_crystal_cluster';
          color = '#0284c7';
          secondaryColor = '#e0f2fe';
          width = 32 + rng() * 26;
        } else if (pick < 0.65) {
          type = 'rock';
          subtype = 'frost_boulder';
          color = '#0c4a6e';
          secondaryColor = '#38bdf8';
          width = 38 + rng() * 28;
        } else if (pick < 0.85) {
          type = 'pool';
          subtype = 'frozen_pond';
          color = '#075985';
          secondaryColor = '#bae6fd';
          width = 50 + rng() * 40;
        } else {
          type = 'barrier';
          subtype = 'snow_barricade';
          color = '#1e3a5f';
          secondaryColor = '#7dd3fc';
          width = 40 + rng() * 20;
        }
      } else if (zone.biome === 'cyber') {
        if (pick < 0.4) {
          type = 'structure';
          subtype = 'holo_terminal';
          color = '#581c87';
          secondaryColor = '#c084fc';
          width = 30 + rng() * 18;
        } else if (pick < 0.65) {
          type = 'conduit';
          subtype = 'matrix_node';
          color = '#3b0764';
          secondaryColor = '#e879f9';
          width = 28 + rng() * 16;
        } else if (pick < 0.85) {
          type = 'pool';
          subtype = 'plasma_vent';
          color = '#2e1065';
          secondaryColor = '#a855f7';
          width = 44 + rng() * 30;
        } else {
          type = 'barrier';
          subtype = 'neon_barrier';
          color = '#4c1d95';
          secondaryColor = '#38bdf8';
          width = 46 + rng() * 22;
        }
      } else {
        // Volcanic
        if (pick < 0.4) {
          type = 'pool';
          subtype = 'magma_pit';
          color = '#450a0a';
          secondaryColor = '#ef4444';
          width = 48 + rng() * 36;
        } else if (pick < 0.65) {
          type = 'rock';
          subtype = 'obsidian_spire';
          color = '#1c1917';
          secondaryColor = '#dc2626';
          width = 34 + rng() * 26;
        } else if (pick < 0.85) {
          type = 'conduit';
          subtype = 'lava_fissure';
          color = '#7f1d1d';
          secondaryColor = '#f97316';
          width = 44 + rng() * 28;
        } else {
          type = 'rock';
          subtype = 'basalt_column';
          color = '#292524';
          secondaryColor = '#f59e0b';
          width = 30 + rng() * 20;
        }
      }

      this.features.push({
        id: i,
        x,
        y,
        type,
        subtype,
        width,
        height,
        rotation: rng() * Math.PI * 2,
        color,
        secondaryColor,
        seed: i * 37 + 11,
      });
    }
  }

  /**
   * Render ground decals and natural terrain features within camera viewport
   */
  public draw(
    ctx: CanvasRenderingContext2D,
    zone: Zone,
    cx: number,
    cy: number,
    vw: number,
    vh: number,
    gameTime: number
  ) {
    if (this.zoneId !== zone.id) {
      this.generate(zone);
    }

    const margin = 100;
    const minX = cx - vw / 2 - margin;
    const maxX = cx + vw / 2 + margin;
    const minY = cy - vh / 2 - margin;
    const maxY = cy + vh / 2 + margin;

    // 1. Draw Biome-Specific Ground Decals & Texture Patches
    for (const decal of this.groundDecals) {
      if (decal.x < minX || decal.x > maxX || decal.y < minY || decal.y > maxY) continue;

      ctx.save();
      ctx.translate(decal.x, decal.y);
      ctx.rotate(decal.rotation);

      if (zone.biome === 'forest') {
        // Mossy soil patch
        ctx.fillStyle = 'rgba(22, 101, 52, 0.12)';
        ctx.beginPath();
        ctx.ellipse(0, 0, decal.size * 0.7, decal.size * 0.45, 0, 0, Math.PI * 2);
        ctx.fill();
        // Little grass tufts
        ctx.strokeStyle = 'rgba(74, 222, 128, 0.25)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-6, 0);
        ctx.lineTo(-9, -8);
        ctx.moveTo(0, 2);
        ctx.lineTo(1, -10);
        ctx.moveTo(6, 0);
        ctx.lineTo(8, -7);
        ctx.stroke();
      } else if (zone.biome === 'urban') {
        // Concrete road markings / cracked pavement
        ctx.fillStyle = 'rgba(30, 41, 59, 0.22)';
        ctx.fillRect(-decal.size * 0.5, -decal.size * 0.35, decal.size, decal.size * 0.7);
        ctx.strokeStyle = 'rgba(234, 179, 8, 0.15)';
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 8]);
        ctx.beginPath();
        ctx.moveTo(-decal.size * 0.4, 0);
        ctx.lineTo(decal.size * 0.4, 0);
        ctx.stroke();
        ctx.setLineDash([]);
      } else if (zone.biome === 'industrial') {
        // Steel plating tread & rivet corners
        ctx.fillStyle = 'rgba(39, 39, 42, 0.25)';
        ctx.fillRect(-decal.size * 0.45, -decal.size * 0.45, decal.size * 0.9, decal.size * 0.9);
        ctx.strokeStyle = 'rgba(234, 88, 12, 0.18)';
        ctx.lineWidth = 1;
        ctx.strokeRect(-decal.size * 0.45, -decal.size * 0.45, decal.size * 0.9, decal.size * 0.9);
      } else if (zone.biome === 'desert') {
        // Sand ripple lines
        ctx.strokeStyle = 'rgba(217, 119, 6, 0.15)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(0, 0, decal.size * 0.5, 0.2, 1.2);
        ctx.arc(0, 0, decal.size * 0.3, 0.4, 1.4);
        ctx.stroke();
      } else if (zone.biome === 'snow') {
        // Frost crack lines
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.2)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(-decal.size * 0.3, -decal.size * 0.2);
        ctx.lineTo(0, 0);
        ctx.lineTo(decal.size * 0.3, decal.size * 0.1);
        ctx.moveTo(0, 0);
        ctx.lineTo(decal.size * 0.1, -decal.size * 0.3);
        ctx.stroke();
      } else if (zone.biome === 'cyber') {
        // Hexagonal cyber circuit trace
        ctx.strokeStyle = 'rgba(168, 85, 247, 0.18)';
        ctx.lineWidth = 1.2;
        ctx.strokeRect(-decal.size * 0.3, -decal.size * 0.3, decal.size * 0.6, decal.size * 0.6);
        ctx.beginPath();
        ctx.arc(0, 0, 3, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.3)';
        ctx.fill();
      } else {
        // Volcanic lava cracks
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-decal.size * 0.4, 0);
        ctx.lineTo(0, -4);
        ctx.lineTo(decal.size * 0.4, 3);
        ctx.stroke();
      }

      ctx.restore();
    }

    // 2. Draw Environmental Pools & Puddles (Lower ground layer)
    for (const feat of this.features) {
      if (feat.type !== 'pool') continue;
      if (feat.x < minX || feat.x > maxX || feat.y < minY || feat.y > maxY) continue;

      this.drawPool(ctx, feat, gameTime);
    }

    // 3. Draw Physical Terrain Features & Obstacles (With drop shadows & depth)
    for (const feat of this.features) {
      if (feat.type === 'pool') continue;
      if (feat.x < minX || feat.x > maxX || feat.y < minY || feat.y > maxY) continue;

      this.drawFeature(ctx, feat, gameTime);
    }

    // 4. Draw Reinforced Arena Perimeter Barricade
    this.drawArenaPerimeter(ctx, zone, gameTime);
  }

  private drawPool(ctx: CanvasRenderingContext2D, feat: TerrainFeature, gameTime: number) {
    ctx.save();
    ctx.translate(feat.x, feat.y);
    ctx.rotate(feat.rotation);

    const rx = feat.width / 2;
    const ry = (feat.height || feat.width) * 0.45;

    // Soft outer ground soak
    ctx.fillStyle = feat.color;
    ctx.globalAlpha = 0.65;
    ctx.beginPath();
    ctx.ellipse(0, 0, rx + 4, ry + 3, 0, 0, Math.PI * 2);
    ctx.fill();

    // Liquid surface
    const pulse = 0.5 + Math.sin(gameTime * 2.5 + feat.seed) * 0.15;
    ctx.fillStyle = feat.secondaryColor;
    ctx.globalAlpha = pulse;
    ctx.beginPath();
    ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();

    // Center bubbling / ripple highlight
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = 0.4;
    const bubbleX = Math.sin(gameTime * 3 + feat.seed) * (rx * 0.4);
    const bubbleY = Math.cos(gameTime * 3 + feat.seed) * (ry * 0.4);
    ctx.beginPath();
    ctx.arc(bubbleX, bubbleY, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawFeature(ctx: CanvasRenderingContext2D, feat: TerrainFeature, gameTime: number) {
    ctx.save();
    ctx.translate(feat.x, feat.y);

    // 1. Drop shadow for depth
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.beginPath();
    ctx.ellipse(0, feat.height * 0.35, feat.width * 0.55, feat.height * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.rotate(feat.rotation);

    if (feat.type === 'rock') {
      // Natural rock / boulder / crystal spire
      ctx.fillStyle = feat.color;
      ctx.beginPath();
      const w = feat.width / 2;
      const h = feat.height / 2;
      ctx.moveTo(-w, 0);
      ctx.lineTo(-w * 0.6, -h);
      ctx.lineTo(w * 0.4, -h * 0.9);
      ctx.lineTo(w, 0);
      ctx.lineTo(w * 0.7, h * 0.8);
      ctx.lineTo(-w * 0.5, h);
      ctx.closePath();
      ctx.fill();

      // Rock highlights & cracks
      ctx.strokeStyle = feat.secondaryColor;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-w * 0.6, -h);
      ctx.lineTo(0, -h * 0.2);
      ctx.lineTo(w * 0.7, h * 0.8);
      ctx.stroke();

    } else if (feat.type === 'barrier') {
      // Tactical concrete or neon barricade
      const w = feat.width;
      const h = feat.height;
      ctx.fillStyle = feat.color;
      ctx.fillRect(-w / 2, -h / 2, w, h);

      // Bevel & border
      ctx.strokeStyle = feat.secondaryColor;
      ctx.lineWidth = 2;
      ctx.strokeRect(-w / 2, -h / 2, w, h);

      // Hazard diagonal chevrons
      ctx.fillStyle = feat.secondaryColor;
      const stripeWidth = 8;
      for (let x = -w / 2 + 4; x < w / 2 - 4; x += stripeWidth * 2) {
        ctx.beginPath();
        ctx.moveTo(x, -h / 2 + 2);
        ctx.lineTo(x + stripeWidth, -h / 2 + 2);
        ctx.lineTo(x + stripeWidth - 6, h / 2 - 2);
        ctx.lineTo(x - 6, h / 2 - 2);
        ctx.fill();
      }

    } else if (feat.type === 'structure') {
      // Cargo container or ancient monolith
      const w = feat.width;
      const h = feat.height;
      ctx.fillStyle = feat.color;
      ctx.fillRect(-w / 2, -h / 2, w, h);

      // Metal reinforced borders
      ctx.strokeStyle = feat.secondaryColor;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(-w / 2, -h / 2, w, h);

      // Center logo / rune
      ctx.fillStyle = feat.secondaryColor;
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();

    } else if (feat.type === 'foliage') {
      // Lush vegetation / alien fern cluster
      const sway = Math.sin(gameTime * 2 + feat.seed) * 0.08;
      ctx.rotate(sway);

      const leafCount = 5;
      ctx.fillStyle = feat.color;
      for (let l = 0; l < leafCount; l++) {
        const leafAngle = (l / leafCount) * Math.PI * 2;
        ctx.save();
        ctx.rotate(leafAngle);
        ctx.beginPath();
        ctx.ellipse(0, -feat.width * 0.35, 6, feat.width * 0.3, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Center bud
      ctx.fillStyle = feat.secondaryColor;
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();

    } else {
      // Conduit / Vent / Terminal node
      ctx.fillStyle = feat.color;
      ctx.beginPath();
      ctx.arc(0, 0, feat.width / 2, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = feat.secondaryColor;
      ctx.lineWidth = 2;
      ctx.stroke();

      // Pulsing center light
      const blink = 0.5 + Math.sin(gameTime * 4 + feat.seed) * 0.4;
      ctx.fillStyle = feat.secondaryColor;
      ctx.globalAlpha = blink;
      ctx.beginPath();
      ctx.arc(0, 0, feat.width * 0.25, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1.0;
    }

    ctx.restore();
  }

  private drawArenaPerimeter(ctx: CanvasRenderingContext2D, zone: Zone, gameTime: number) {
    const mapLimit = 1400;

    // High-tech perimeter energy fence
    ctx.save();
    ctx.strokeStyle = zone.hazardColor;
    ctx.lineWidth = 3;
    ctx.setLineDash([20, 10]);
    ctx.lineDashOffset = -gameTime * 25;
    ctx.strokeRect(-mapLimit, -mapLimit, mapLimit * 2, mapLimit * 2);
    ctx.setLineDash([]);

    // Perimeter boundary pylon towers at intervals
    const pylonInterval = 280;
    ctx.fillStyle = zone.wallColor;
    ctx.strokeStyle = zone.hazardColor;
    ctx.lineWidth = 2;

    const drawPylon = (px: number, py: number) => {
      ctx.fillRect(px - 10, py - 10, 20, 20);
      ctx.strokeRect(px - 10, py - 10, 20, 20);

      // Warning laser beacon
      const beaconGlow = 0.6 + Math.sin(gameTime * 6 + px + py) * 0.4;
      ctx.fillStyle = zone.hazardColor;
      ctx.globalAlpha = beaconGlow;
      ctx.beginPath();
      ctx.arc(px, py, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1.0;
    };

    // Top & bottom perimeter
    for (let x = -mapLimit; x <= mapLimit; x += pylonInterval) {
      drawPylon(x, -mapLimit);
      drawPylon(x, mapLimit);
    }
    // Left & right perimeter
    for (let y = -mapLimit + pylonInterval; y < mapLimit; y += pylonInterval) {
      drawPylon(-mapLimit, y);
      drawPylon(mapLimit, y);
    }

    ctx.restore();
  }
}
