import React, { useState } from 'react';
import { PlayerProfile } from '../types/game';
import { sound } from '../game/audio';
import { Award, Zap, Shield, Sparkles, Clock, ArrowUpCircle, CheckCircle, RefreshCcw, Flame } from 'lucide-react';

interface RebirthWorkshopProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => void;
}

export const RebirthWorkshop: React.FC<RebirthWorkshopProps> = ({
  profile,
  onUpdateProfile,
}) => {
  const [rebirthSuccess, setRebirthSuccess] = useState<boolean>(false);
  const [offlineClaimedMsg, setOfflineClaimedMsg] = useState<string | null>(null);

  const rebirthCount = profile.rebirthCount || 0;
  const valorMedals = profile.valorMedals || 0;
  const currentMultiplier = profile.rebirthMultiplier || 1.0;

  // Milestone requirement for rebirth: Need at least highestZone >= 2 or accountLevel >= 3
  const isEligibleForRebirth = profile.highestZone >= 2 || profile.accountLevel >= 3;
  const medalsToEarn = Math.max(1, (profile.highestZone - 1) * 2 + Math.floor(profile.totalKills / 30));

  const handlePerformRebirth = () => {
    if (!isEligibleForRebirth) return;

    sound.playRebirth();
    setRebirthSuccess(true);

    const nextRebirthCount = rebirthCount + 1;
    const nextMultiplier = parseFloat((1.0 + nextRebirthCount * 0.25).toFixed(2));
    const nextMedals = valorMedals + medalsToEarn;

    onUpdateProfile((prev) => ({
      ...prev,
      highestZone: 1,
      highestMission: 1,
      rebirthCount: nextRebirthCount,
      valorMedals: nextMedals,
      rebirthMultiplier: nextMultiplier,
      coins: prev.coins + 250,
      scrap: prev.scrap + 50,
    }));

    setTimeout(() => setRebirthSuccess(false), 5000);
  };

  // Offline Idle Rewards calculation
  const now = Date.now();
  const lastActive = profile.lastActiveTimestamp || now - 1000 * 60 * 30; // default 30 mins if first time
  const elapsedMinutes = Math.min(24 * 60, Math.max(5, Math.floor((now - lastActive) / 60000)));

  // 4 coins per minute + 1 scrap per 3 mins * multiplier
  const pendingIdleCoins = Math.round(elapsedMinutes * 4 * currentMultiplier);
  const pendingIdleScrap = Math.round((elapsedMinutes / 3) * currentMultiplier);

  const handleClaimIdleRewards = () => {
    sound.playPickup();
    onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins + pendingIdleCoins,
      scrap: prev.scrap + pendingIdleScrap,
      lastActiveTimestamp: Date.now(),
    }));

    setOfflineClaimedMsg(`KVITTERAT: +${pendingIdleCoins} KREDITER & +${pendingIdleScrap} VAPENDELAR TILL BASEN!`);
    setTimeout(() => setOfflineClaimedMsg(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-[#090e1c] border border-amber-500/30 tactical-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-tech text-amber-500 font-bold uppercase tracking-widest">
              KVANT-ÅTERFÖDELSE // REBIRTH SYSTEM
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-tech font-black bg-purple-500/20 text-purple-400 border border-purple-500/30">
              OÄNDLIG TILLVÄXT
            </span>
          </div>
          <h2 className="text-2xl font-black text-slate-100 font-display">
            Rebirth & Passiva Offlineresurser
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl font-tech leading-relaxed">
            Nå zonmilstolpar och återföds för permanenta stridsförstärkningar. Behåll alla dina upplåsta
            kattkrigare och vapen medan din trupps eldkraft multipliceras exponentiellt!
          </p>
        </div>

        {/* Global Multiplier Indicator */}
        <div className="bg-[#050914] border border-purple-500/40 rounded-xl p-4 flex items-center gap-4 shrink-0 shadow-lg font-tech">
          <div className="w-12 h-12 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 text-2xl">
            👑
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">
              Global Truppmultiplikator
            </div>
            <div className="text-2xl font-black text-purple-400 font-display">
              x{currentMultiplier.toFixed(2)}
            </div>
            <div className="text-[11px] text-slate-400">
              +{Math.round((currentMultiplier - 1.0) * 100)}% Permanent Skadeökning
            </div>
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {rebirthSuccess && (
        <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950 to-[#050914] border border-purple-500 flex items-center gap-3 text-purple-300 font-tech text-xs animate-bounce shadow-2xl">
          <Sparkles className="w-5 h-5 text-purple-400 shrink-0" />
          <span className="font-bold">
            KVANT-ÅTERFÖDELSE FULLBORDAD! DIN TRUPP HAR NU EN PERMANENT SKADEBOOST PÅ x{currentMultiplier.toFixed(2)}!
          </span>
        </div>
      )}

      {/* 2-Column Layout: Offline Patrol + Rebirth Chamber */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Offline Patrol Earnings (AFK Idle Rewards) */}
        <div className="bg-[#070c18] border border-slate-800 rounded-xl p-5 tactical-border-cyan flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-4">
              <h3 className="text-xs uppercase font-bold text-slate-200 font-display flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span>AFK Kattpatrull // Passiva 24/7 Belöningar</span>
              </h3>
              <span className="text-[10px] font-tech text-emerald-400 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                AKTIV 24/7
              </span>
            </div>

            <p className="text-xs text-slate-400 font-tech mb-4 leading-relaxed">
              Dina modiga kattkrigare patrullerar och säkrar övergivna bunkrar även när du inte spelar eller sover.
            </p>

            <div className="grid grid-cols-2 gap-3 mb-4 font-tech">
              <div className="p-3.5 bg-[#050914] rounded-lg border border-slate-800 flex items-center gap-3">
                <span className="text-2xl">🪙</span>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Insamlade Krediter</div>
                  <div className="text-lg font-bold text-amber-400">+{pendingIdleCoins}</div>
                </div>
              </div>

              <div className="p-3.5 bg-[#050914] rounded-lg border border-slate-800 flex items-center gap-3">
                <span className="text-2xl">⚙️</span>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Bärgade Vapendelar</div>
                  <div className="text-lg font-bold text-cyan-400">+{pendingIdleScrap}</div>
                </div>
              </div>
            </div>

            {offlineClaimedMsg && (
              <div className="p-2.5 mb-3 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 font-tech text-xs font-bold text-center">
                {offlineClaimedMsg}
              </div>
            )}
          </div>

          <button
            onClick={handleClaimIdleRewards}
            className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-tech font-bold uppercase tracking-wider rounded-lg text-xs transition-all shadow-lg shadow-cyan-500/20 active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-cyan-300" />
            <span>Hämta Patrullens Byte</span>
          </button>
        </div>

        {/* Rebirth Chamber */}
        <div className="bg-[#090e1c] border border-slate-800 rounded-xl p-5 tactical-border flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-4">
              <h3 className="text-xs uppercase font-bold text-slate-200 font-display flex items-center gap-2">
                <Award className="w-4 h-4 text-purple-400" />
                <span>Kvant-Återfödelsekammare</span>
              </h3>
              <span className="text-[10px] font-tech text-purple-400 font-bold">
                REBIRTH #{rebirthCount}
              </span>
            </div>

            <div className="space-y-3 font-tech text-xs mb-4">
              <div className="p-3 bg-[#050914] rounded-lg border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Krav för Kvant-Återfödelse:</span>
                <span className={isEligibleForRebirth ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {isEligibleForRebirth ? 'UPPFYLLT (Zon 2+ nådd)' : 'KRÄVER ZON 2 NÅDD'}
                </span>
              </div>

              <div className="p-3 bg-[#050914] rounded-lg border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Tapperhetsmedaljer vid Rebirth:</span>
                <span className="text-purple-400 font-bold flex items-center gap-1">
                  <span>🎖️</span>
                  <span>+{medalsToEarn} Medaljer</span>
                </span>
              </div>

              <div className="p-3 bg-[#050914] rounded-lg border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Ny Global Skademultiplikator:</span>
                <span className="text-amber-400 font-bold">
                  x{(currentMultiplier + 0.25).toFixed(2)} (+25% mer skada)
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 font-tech leading-relaxed mb-4">
              Alla dina upplåsta katter, vapen och smidda vapen behålls! Zonkarta 1 nollställs för
              att ge dig en ny spännande utmaning med överlägsen eldkraft.
            </p>
          </div>

          <button
            onClick={handlePerformRebirth}
            disabled={!isEligibleForRebirth}
            className={`w-full py-3 rounded-lg text-xs font-tech font-bold uppercase tracking-wider transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer ${
              isEligibleForRebirth
                ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white shadow-purple-500/25 active:scale-95'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <RefreshCcw className="w-4 h-4 text-purple-200" />
            <span>Genomför Kvant-Återfödelse (+{medalsToEarn} Medaljer)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
